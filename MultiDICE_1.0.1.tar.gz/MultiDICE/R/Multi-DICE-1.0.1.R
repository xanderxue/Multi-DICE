dice.read.numtaxa=function(num.taxa, num.partitions){

 numtaxacaution=0

 #convert user input num.taxa to vector, assign to object numtaxa
 if(typeof(num.taxa)!='list'){
  #protect against user misspecification in the case that there are less num.taxa than num.partitions but more num.taxa than 1, in which case, the first num.taxa is used for all partitions
  if(length(num.taxa)<num.partitions){
   if(length(num.taxa)>1){
    numtaxacaution=1
   }
   numtaxa=rep(as.integer(num.taxa[1]),num.partitions)
  } else {
   if(length(num.taxa)>num.partitions){
    numtaxacaution=1
   }
   numtaxa=as.integer(num.taxa)
  }
 } else {
  #iterating through the length of num.taxa protects against weird misspecifications, such as less list elements than num.partitions but multiple items in each list element so that the total length of numeric elements = num.partitions (or >=)
  numtaxa=NULL
  for(z in 1:length(num.taxa)){
   numtaxa=c(numtaxa,as.integer(num.taxa[[z]]))
  }
  if(length(numtaxa)>num.partitions){
   numtaxacaution=1
  }
  if(length(numtaxa)<num.partitions){
   if(length(numtaxa)>1){
    numtaxacaution=1
   }
   numtaxa=rep(numtaxa[1],num.partitions)
  }
 }

 if(sum(numtaxa<1)>0){
  return(-1)
 } else {
  return(list(numtaxa=numtaxa,numtaxacaution=numtaxacaution))
 }

}


dice.read.psiprior=function(tau.psi.prior, epsilon.psi.prior, NE.psi.prior){

 psiprior=NULL
 psicaution=0

 for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
  #if this psi is intended to be inferred
  if(z=='tau2'&&typeof(tau.psi.prior)=='list'&&length(tau.psi.prior)>1||z=='epsilon2'&&typeof(epsilon.psi.prior)=='list'&&length(epsilon.psi.prior)>1||substr(z, nchar(z), nchar(z))!='2'&&!is.null(eval(parse(text=paste(sub('2','',z),'.psi.prior',sep=''))))){
   #convert user input psi to sorted vector, assign to object psiprior; must be sorted for while loop below that determines all zeta combinations per psi, which assumes psi is in numeric order and thus allows gaps/holes and duplicates in psi distribution
   if(substr(z,nchar(z),nchar(z))=='2'){
    psiprior=append(psiprior,list(sort(as.integer(eval(parse(text=paste(sub('2','',z),'.psi.prior',sep='')))[[2]]))))
   } else {
    if(typeof(eval(parse(text=paste(z,'.psi.prior',sep=''))))=='list'){
     psiprior=append(psiprior,list(sort(as.integer(eval(parse(text=paste(z,'.psi.prior',sep='')))[[1]]))))
    } else {
     psiprior=append(psiprior,list(sort(as.integer(eval(parse(text=paste(z,'.psi.prior',sep='')))))))
    }
   }
   if(sum(psiprior[[length(psiprior)]]<0)>0){
    names(psiprior)[[length(psiprior)]]='psitest'
   } else {
    names(psiprior)[[length(psiprior)]]=z
   }
  }
  if(z=='NE'&&typeof('NE.psi.prior')=='list'&&length('NE.psi.prior')>1||substr(z,nchar(z),nchar(z))=='2'&&typeof(eval(parse(text=paste(sub('2','',z),'.psi.prior',sep=''))))=='list'&&length(eval(parse(text=paste(sub('2','',z),'.psi.prior',sep=''))))>2){
   psicaution=1
  }
 }
 
  return(append(psiprior,list(psicaution=psicaution)))

}


dice.read.minmax.per.pulse=function(numtaxa, psiprior, min.net.tau.zeta.per.pulse, min.net.tau2.zeta.per.pulse, min.net.epsilon.zeta.per.pulse, min.net.epsilon2.zeta.per.pulse, min.net.NE.zeta.per.pulse, max.net.tau.zeta.per.pulse, max.net.tau2.zeta.per.pulse, max.net.epsilon.zeta.per.pulse, max.net.epsilon2.zeta.per.pulse, max.net.NE.zeta.per.pulse){

 minmax.per.pulse=NULL
 minmaxcaution=0

 for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
  for(y in c('min','max')){
   #convert user input min/max.net.zeta.per.pulse to vector, assign to object minmax.per.pulse
   if(!is.null(eval(parse(text=paste(y,'.net.',z,'.zeta.per.pulse',sep=''))))){
    minmax.per.pulse=append(minmax.per.pulse,list(NULL))
    interim=eval(parse(text=paste(y,'.net.',z,'.zeta.per.pulse',sep='')))
    if(typeof(interim)!='list'){
     #protect against user misspecification in the case that there are less min/max.net.zeta.per.pulse than max(psiprior) but more min/max.net.zeta.per.pulse than 1, in which case, the first min/max.net.zeta.per.pulse is used for all pulses
     if(length(interim)<max(psiprior[[paste(z,sep='')]])){
      if(length(interim)>1){
       minmaxcaution=1
      }
      minmax.per.pulse[[length(minmax.per.pulse)]]=rep(as.integer((interim[1]*sum(numtaxa[['numtaxa']]))),max(psiprior[[paste(z,sep='')]]))
     } else {
      if(length(interim)>max(psiprior[[paste(z,sep='')]])){
       minmaxcaution=1
      }
      minmax.per.pulse[[length(minmax.per.pulse)]]=as.integer(interim*sum(numtaxa[['numtaxa']]))
     }
    } else {
     #iterating through the length of min/max.net.zeta.per.pulse protects against weird misspecifications, such as less list elements than max(psiprior) but multiple items in each list element so that the total length of numeric elements = max(psiprior) (or >=)
     for(x in 1:length(interim)){
      minmax.per.pulse[[length(minmax.per.pulse)]]=c(minmax.per.pulse[[length(minmax.per.pulse)]],as.integer(interim[[x]]*sum(numtaxa[['numtaxa']])))
     }
     if(length(minmax.per.pulse[[length(minmax.per.pulse)]])>max(psiprior[[paste(z,sep='')]])){
      minmaxcaution=1
     }
     if(length(minmax.per.pulse[[length(minmax.per.pulse)]])<max(psiprior[[paste(z,sep='')]])){
      if(length(minmax.per.pulse[[length(minmax.per.pulse)]])>1){
       minmaxcaution=1
      }
      minmax.per.pulse[[length(minmax.per.pulse)]]=rep(minmax.per.pulse[[length(minmax.per.pulse)]][1],max(psiprior[[paste(z,sep='')]]))
     }
    }
	if(sum(minmax.per.pulse[[length(minmax.per.pulse)]]<0)>0||sum(minmax.per.pulse[[length(minmax.per.pulse)]]>sum(numtaxa[['numtaxa']]))>0){
     names(minmax.per.pulse)[length(minmax.per.pulse)]='minmaxtest'
    } else {
     names(minmax.per.pulse)[length(minmax.per.pulse)]=paste(y,z,sep='.')
    }
   }
  }
 }

 if('minmaxtest'%in%names(minmax.per.pulse)){
  return(-1)
 } else {
  return(append(minmax.per.pulse,list(minmaxcaution=minmaxcaution)))
 }

}


dice.read.zetaprior=function(numtaxa, num.partitions, psiprior, tau.zeta.prior, tau2.zeta.prior, epsilon.zeta.prior, epsilon2.zeta.prior, NE.zeta.prior, idiosyncratic, min.net.tau.zeta.total, min.net.tau2.zeta.total, min.net.epsilon.zeta.total, min.net.epsilon2.zeta.total, min.net.NE.zeta.total, max.net.tau.zeta.total, max.net.tau2.zeta.total, max.net.epsilon.zeta.total, max.net.epsilon2.zeta.total, max.net.NE.zeta.total, minmax.per.pulse){

 zetaprior=NULL
 zetacaution=0

 for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
  #if this psi is intended to be inferred
  if(z%in%names(psiprior)){
   #convert user input zeta to list, assign to object zetaprior
   zetaprior=append(zetaprior,list(NULL))
   draws=NULL
   #add psi=0 if part of psi prior distribution
   for(y in 1:num.partitions){
    if(0 %in% psiprior[[paste(z,sep='')]]){
     draws=append(draws,list(matrix(rep(as.integer(0),2),nrow=1)))
    } else {
     draws=append(draws,list(NULL))
    }
   }
   if(max(psiprior[[paste(z,sep='')]])>0){
    if(idiosyncratic==F){
     if(!is.null(eval(parse(text=paste('min.net.',z,'.zeta.total',sep=''))))){
      if(eval(parse(text=paste('min.net.',z,'.zeta.total',sep='')))!=1){
       names(zetaprior)[length(zetaprior)]='zetaminmaxtest'
      }
     }
     if(!is.null(eval(parse(text=paste('max.net.',z,'.zeta.total',sep=''))))&&!'zetaminmaxtest'%in%names(zetaprior)){
      if(eval(parse(text=paste('max.net.',z,'.zeta.total',sep='')))!=1){
       names(zetaprior)[length(zetaprior)]='zetaminmaxtest'
      }
     }
    }
    if(!'zetaminmaxtest'%in%names(zetaprior)){
     zetapriortemp=eval(parse(text=paste(z,'.zeta.prior', sep='')))
     if(typeof(zetapriortemp)!='list'){
      zetapriortemp=list(zetapriortemp)
     }
     temporary=NULL
     for(y in 1:length(zetapriortemp)){
      temporary=c(temporary,zetapriortemp[[y]])
     }
     if(is.null(temporary)||sum(temporary>1)>0||sum(temporary<0)>0){
      names(zetaprior)[length(zetaprior)]='zetatest'
     } else {
      #protect against user misspecification in the case that there are more zeta distributions than appropriate (either 1 or num.partitions); stall duplication across all partitions of the first zeta distribution in the case of >1 & <num.partitions, since the zeta distribution undergoes this somewhat computationally expensive combinatorics process and it is more efficient to execute the process first and then duplicate rather than duplicate first and subsequently enact the identical intensive process as many times as there are num.partitions; similarly, misspecifications involving more zeta distributions than num.parititons will be cut down to the appropriate number of distributions prior to the cominbatorics process
      if(length(zetapriortemp)<num.partitions){
       if(length(zetapriortemp)>1){
        zetacaution=1
       }
       #convert units of zetaprior from proportion to absolute number of taxa
       zetapriortemp=list(as.integer(zetapriortemp[[1]]*sum(numtaxa[['numtaxa']])))
      } else {
       if(length(zetapriortemp)>num.partitions){
        zetacaution=1
        for(y in (num.partitions+1):length(zetapriortemp)){
         zetapriortemp[[y]]=NULL
        }
       }
       for(y in 1:num.partitions){
        #convert units of zetaprior from proportion to absolute number of taxa
        zetapriortemp[[y]]=as.integer(zetapriortemp[[y]]*sum(numtaxa[['numtaxa']]))
       }
      }
      #construct all zeta prior combinations across distinct distributions per each partition and according to each possible psi prior draw
      combos=NULL
      for(y in 1:length(zetapriortemp)){
       combos=append(combos,list(NULL))
       combinations=matrix(zetapriortemp[[y]],ncol=1)
       counter=1
       for(x in unique(psiprior[[paste(z,sep='')]][psiprior[[paste(z,sep='')]]>0])){
        while(counter<x){
         counter=counter+1
         combination=combinations
         combinations=NULL
         for(w in 1:nrow(combination)){
          for(v in zetapriortemp[[y]]){
           combinations=rbind(combinations,c(combination[w,],v))
          }
         }
        }
        if(!paste('pulse',x,sep='')%in%names(combos[[y]])){
         combos[[y]]=append(combos[[y]],list(combinations))
         names(combos[[y]])[length(combos[[y]])]=paste('pulse',x,sep='')
        }
       }
      }
      #duplicate single zeta distribution to all partitions
      if(num.partitions>length(combos)){
       for(y in 2:num.partitions){
        combos=append(combos,list(combos[[1]]))
       }
      }
      #assign combinations of zeta values across partitions, which must be of equivalent psi, that meet user specifications to object zeta.draws
      for(y in unique(psiprior[[paste(z,sep='')]][psiprior[[paste(z,sep='')]]>0])){
       draws.per.psi=NULL
       switch=0
       x=0
       while(x<num.partitions&&switch==0){
        x=x+1
        draws.per.psi=append(draws.per.psi,list(NULL))
        w=0
        while(w<nrow(combos[[x]][[paste('pulse',y,sep='')]])&&switch==0){
         w=w+1
         #combination of zeta values must be of appropriate number of taxa per partition, which is determined by the idiosyncratic logical value; by verifying every combination is of appropriate number of taxa per partition, automatically any combination of draws among partitions will be of appropriate number of total taxa
         if(idiosyncratic==T&&sum(combos[[x]][[paste('pulse',y,sep='')]][w,])<=numtaxa[['numtaxa']][x]||idiosyncratic==F&&sum(combos[[x]][[paste('pulse',y,sep='')]][w,])==numtaxa[['numtaxa']][x]){
          draws.per.psi[[x]]=c(draws.per.psi[[x]],w)
         }
        }
        if(is.null(draws.per.psi[[x]])){
         switch=1
        }
       }
       if(switch==0){
        draws.per.psi=as.matrix(expand.grid(draws.per.psi))
        #combination of zeta prior draws across partitions must be of appropriate min and max net zeta per pulse and in total
        if(!is.null(eval(parse(text=paste('min.net.',z,'.zeta.total',sep=''))))||!is.null(eval(parse(text=paste('max.net.',z,'.zeta.total',sep=''))))||paste('min',z,sep='.')%in%names(minmax.per.pulse)||paste('max',z,sep='.')%in%names(minmax.per.pulse)){
         for(x in 1:nrow(draws.per.psi)){
          flag=0
          if(!is.null(eval(parse(text=paste('min.net.',z,'.zeta.total',sep=''))))||!is.null(eval(parse(text=paste('max.net.',z,'.zeta.total',sep=''))))){
           temp.zeta.total=0
          }
          w=0
          while(w<y&&flag==0){
           w=w+1
           temp.pulse.zeta.total=0
           for(v in 1:num.partitions){
            temp.pulse.zeta.total=temp.pulse.zeta.total+combos[[v]][[paste('pulse',y,sep='')]][draws.per.psi[x,v],w]
           }
           if(!is.null(eval(parse(text=paste('min.net.',z,'.zeta.total',sep=''))))||!is.null(eval(parse(text=paste('max.net.',z,'.zeta.total',sep=''))))){
            temp.zeta.total=temp.zeta.total+temp.pulse.zeta.total
           }
           #combination of zeta values across partitions must be of appropriate min and max net zeta per pulse; previously, placed this process of combinations and filtering valid draws in the build.dice functions; then, the test of min/max zeta per pulse/total, which still had to be here so that a caution/stoppage could be issued, was trying to shortcut by seeing if the most extreme values would pass these thresholds, OR, for idiosyncratic==F, which was more complicated since the zeta total had to = num.taxa and thus could not simply look at the edge of distributions, both negative loops (continuing until failure; checking all pulses within a draw) and affirmative loops (cycling until a single possible draw satisfied the conditions), which thus alternated in how the flags operated, were utilized; this became increasingly difficult, considering unpredictable/unorthodox mixtures of combinations (e.g. not straightforward to calculate if the maximum zeta per pulse would be met across all pulses with a higher minimum psi value and a higher minimum zeta value i.e. forcing more even dispersion across multiple pulses), idiosyncratic==F, differential zeta distributions per partition, varying numbers of taxa per partition, possible misspecifications of zeta distributions, and incorporating more complexity (e.g. differential min/max zeta per pulse across pulses, differential min/max zeta per pulse/total across hyperparameters, uniform prior)
           if(paste('min',z,sep='.')%in%names(minmax.per.pulse)){
            if(temp.pulse.zeta.total<minmax.per.pulse[[paste('min',z,sep='.')]][w]){
             flag=1
            }
           }
           if(paste('max',z,sep='.')%in%names(minmax.per.pulse)&&flag==0){
            if(temp.pulse.zeta.total>minmax.per.pulse[[paste('max',z,sep='.')]][w]){
             flag=1
            }
           }
          }
          if(!is.null(eval(parse(text=paste('min.net.',z,'.zeta.total',sep=''))))&&flag==0){
           if(temp.zeta.total<as.integer(eval(parse(text=paste('min.net.',z,'.zeta.total',sep='')))*sum(numtaxa[['numtaxa']]))){
            flag=1
           }
          }
          if(!is.null(eval(parse(text=paste('max.net.',z,'.zeta.total',sep=''))))&&flag==0){
           if(temp.zeta.total>as.integer(eval(parse(text=paste('max.net.',z,'.zeta.total',sep='')))*sum(numtaxa[['numtaxa']]))){
            flag=1
           }
          }
          if(flag==0){
           for(w in 1:num.partitions){
            draws[[w]]=rbind(draws[[w]],c(y,draws.per.psi[x,w]))
           }
          }
         }
        } else {
         for(x in 1:nrow(draws.per.psi)){
          for(w in 1:num.partitions){
           draws[[w]]=rbind(draws[[w]],c(y,draws.per.psi[x,w]))
          }
         }
        }
       }
      }
      if(is.null(draws)){
       names(zetaprior)[length(zetaprior)]='zetaminmaxidiotest'
      } else {
       names(zetaprior)[length(zetaprior)]=z
       zetaprior[[paste(z,sep='')]]=list(draws=draws,combos=combos)
      }
     }
    }
   } else {
    names(zetaprior)[length(zetaprior)]=z
    zetaprior[[paste(z,sep='')]]=list(draws=draws,combos=NULL)
   }
  }
 }

 return(append(zetaprior,list(zetacaution=zetacaution)))

}



dice.read.sharedprior=function(psiprior, tau.shared.prior, tau2.shared.prior, epsilon.shared.prior, epsilon2.shared.prior, NE.shared.prior){

 sharedprior=NULL
 sharedcaution=0

 for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
  #if this psi is intended to be inferred
  if(z%in%names(psiprior)&&max(psiprior[[paste(z,sep='')]])>0){
   #convert user input shared to list, assign to object sharedprior
   sharedprior=append(sharedprior,list(NULL))
   temp=eval(parse(text=paste(z,'.shared.prior',sep='')))
   if(typeof(temp)!='list'){
    temp=list(temp)
   }
   temporary=NULL
   for(y in 1:length(temp)){
    temporary=c(temporary,temp[[y]])
   }
   if(is.null(temporary)||sum(temporary<=0)>0){
    names(sharedprior)[[length(sharedprior)]]='sharedtest'
   } else {
    if(length(temp)>1){
     y=0
     while(y<(length(temp)-1)&&!'sharedtest'%in%names(sharedprior)){
      y=y+1
      if(min(temp[[(y+1)]])<=min(temp[[y]])||max(temp[[(y+1)]])<=max(temp[[y]])){
       names(sharedprior)[[length(sharedprior)]]='sharedtest'
      }
     }
    }
    if(!'sharedtest'%in%names(sharedprior)){
     names(sharedprior)[[length(sharedprior)]]=z
     #protect against user misspecification in the case that there are less shared distributions than max psi value but more shared distributions than 1, in which case, the first shared distribution is used for all partitions
     #cannot allow user option of adding another list element to shared prior object indicating a separate idiosyncratic distribution in the case of a single shared distribution used for all pulses with max psi value > 1; potential for indistinguishability in the case of max psi value = 2, where indicating 2 different shared distributions for each pulse with no idiosyncratic distribution and indiciating 1 shared distribution for all pulses with 1 idiosyncratic distribution will both result in a list of 2 distributions in the sharedprior object; thus, to utilize a separate idiosyncratic distribution, the idiosyncratic prior specification must be used (Multi-DICE will look for this first), or can add as another list element when the number of shared distributions = max psi value, such that with an additional list element to shared prior object indicating a separate idiosyncratic distribution, length of shared prior object = max psi value + 1 (or at least >=; in cases of >, additional distributions are ignored, unless additional distributions >= num.partitions, in which case, each additional distribution will be the assigned idio distribution for its respective partition) (Multi-DICE will look for this second), or otherwise Multi-DICE defaults to use the first shared prior distribution
     if(length(temp)<max(psiprior[[paste(z,sep='')]])){
      if(length(temp)>1){
       sharedcaution=1
      }
      if(substr(z,1,7)=='epsilon'){
       sharedprior[[paste(z,sep='')]]=list(temp[[1]])
      } else {
       sharedprior[[paste(z,sep='')]]=list(as.integer(temp[[1]]))
      }
     } else {
      for(y in 1:max(psiprior[[paste(z,sep='')]])){
       if(substr(z,1,7)=='epsilon'){
        sharedprior[[paste(z,sep='')]]=append(sharedprior[[paste(z,sep='')]],list(temp[[y]]))
       } else {
        sharedprior[[paste(z,sep='')]]=append(sharedprior[[paste(z,sep='')]],list(as.integer(temp[[y]])))
       }
      }
      #no sharedcaution here since sharedpriors can appropriately be larger if including idiosyncratic distributions
     }
    }
   }
  }
 }

 return(append(sharedprior,list(sharedcaution=sharedcaution)))

}


dice.read.buff=function(psiprior, tau.buffer, tau2.buffer, epsilon.buffer, epsilon2.buffer, NE.buffer){

 buff=NULL

 for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
  #if this psi is intended to be inferred
  if(z%in%names(psiprior)){
   #convert user input buffer to list, assign to object buff
   if(typeof(eval(parse(text=paste(z,'buffer',sep='.'))))=='double'||typeof(eval(parse(text=paste(z,'buffer',sep='.'))))=='integer'||typeof(eval(parse(text=paste(z,'buffer',sep='.'))))=='closure'){
    if(typeof(eval(parse(text=paste(z,'buffer',sep='.'))))=='closure'){
     buff=append(buff,list('function'))
     names(buff)[[length(buff)]]=z
    } else {
     if(eval(parse(text=paste(z,'buffer',sep='.')))>=0){
      if(substr(z,1,7)=='epsilon'){
       buff=append(buff,list(eval(parse(text=paste(z,'buffer',sep='.')))))
      } else {
       buff=append(buff,list(as.integer(eval(parse(text=paste(z,'buffer',sep='.'))))))
      }
      names(buff)[[length(buff)]]=z
     } else {
      buff=append(buff,list(-1))
      names(buff)[[length(buff)]]='bufftest'
     }
    }
   } else {
    buff=append(buff,list(-1))
    names(buff)[[length(buff)]]='bufftest'
   }
  }
 }

 return(buff)

}



dice.read.numchanges=function(num.partitions, num.changes){

 numchangescaution=0

 #convert user input num.changes to vector, assign to object numchanges
 if(typeof(num.changes)!='list'){
  #protect against user misspecification in the case that there are less num.changes than num.partitions but more num.changes than 1, in which case, the first num.changes is used for all partitions
  if(length(num.changes)<num.partitions){
   if(length(num.changes)>1){
    numchangescaution=1
   }
   numchanges=rep(as.integer(num.changes[1]),num.partitions)
  } else {
   if(length(num.changes)>num.partitions){
    numchangescaution=1
   }
   numchanges=as.integer(num.changes)
  }
 } else {
  #iterating through the length of num.changes protects against weird misspecifications, such as less list elements than num.partitions but multiple items in each list element so that the total length of numeric elements = num.partitions (or >=)
  numchanges=NULL
  for(z in 1:length(num.changes)){
   numchanges=c(numchanges,as.integer(num.changes[[z]]))
  }
  if(length(numchanges)>num.partitions){
   numchangescaution=1
  }
  if(length(numchanges)<num.partitions){
   if(length(numchanges)>1){
    numchangescaution=1
   }
   numchanges=rep(numchanges[1],num.partitions)
  }
 }
 if(sum(numchanges>2)>0){
  numchangescaution=1
  numchanges[numchanges>2]=2
 }

 if(sum(numchanges<1)>0){
  return(-1)
 } else {
  return(list(numchanges=numchanges,numchangescaution=numchangescaution))
 }

}


dice.read.idioprior=function(num.partitions, psiprior, tau.shared.prior, tau2.shared.prior, epsilon.shared.prior, epsilon2.shared.prior, NE.shared.prior, tau.idio.prior, tau2.idio.prior, epsilon.idio.prior, epsilon2.idio.prior, NE.idio.prior, anchor.prior, change.prior, idiosyncratic, numchanges){

 idioprior=NULL
 idiocaution=0

 for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
  #if hyperparameter is being inferred and taxa are allowed to act idiosyncratically (for tau2, change.prior must also be NOT specified by user, and thus for an inferred 2nd event with idiosyncratic taxa, change.prior has 1st priority, idio.prior has 2nd priority, and then shared.prior has 3rd and last priority; anchor.prior doesn't make sense here, since anchor.prior is practically a substitute for an inferred 2nd event and cannot act as a coinciding model just for the idiosyncratic taxa as it is pulse-based for the 1st event), OR hyperparamter is not being inferred but parameter is being simulated as a nuisance (for tau2, anchor.prior and change.prior must also both be NOT specified by user, and thus for a nuisance 2nd event, anchor.prior has 1st priority, change.prior has 2nd priority, idio.prior has 3rd priority, and then shared.prior has 4th and last priority), then idio.prior (or a substituted shared.prior if idio.prior is not specified by user) is used for all taxa that are either idiosyncratic or nuisance for this parameter
  if(z%in%names(psiprior)&&idiosyncratic==T&&z!='tau2'||z%in%names(psiprior)&&idiosyncratic==T&&is.null(change.prior)||!z%in%names(psiprior)&&substr(z,nchar(z),nchar(z))!='2'||!z%in%names(psiprior)&&2%in%numchanges[['numchanges']]&&z=='epsilon2'||!z%in%names(psiprior)&&2%in%numchanges[['numchanges']]&&is.null(anchor.prior)&&is.null(change.prior)){
   #convert user input idio (or shared) to list, assign to object idioprior
   idioprior=append(idioprior,list(NULL))
   if(!is.null(eval(parse(text=paste(z,'.idio.prior',sep=''))))){
    #user input idio.prior
    temp=eval(parse(text=paste(z,'.idio.prior',sep='')))
   } else {
    #user input shared.prior
    temp=eval(parse(text=paste(z,'.shared.prior',sep='')))
    #if additional idio prior distributions are specified after true shared prior distributions in shared.prior, then taking out the true shared prior distributions; must do it here because after this if else loop, it will be impossible to distinguish between distributions from idio.prior vs. shared.prior, and thus in cases of length(idioprior) > num.partitions, whether this is due to misspecification of idio.prior (in which case, if discarding the first max(psivalue) distributions, then the latter idio.prior distributions would be used, which is not the desired default against misspecification) or additional specification of idio prior distributions in shared.prior
    if(z%in%names(psiprior)&&max(psiprior[[paste(z,sep='')]])>0){
     if(typeof(temp)=='list'&&length(temp)>max(psiprior[[paste(z,sep='')]])){
      temporary=NULL
      for(y in (max(psiprior[[paste(z,sep='')]])+1):length(temp)){
       temporary=append(temporary,list(temp[[y]]))
      }
      temp=temporary
     } else {
      #if no additional distributions specified after true shared prior distributions in shared.prior, then assure that only the first shared.prior distribution is used for idio prior distributions
	  if(typeof(temp)=='list'&&length(temp)>1){
      temp=temp[[1]]
      }
     }
    }
   }
   if(typeof(temp)!='list'){
    temp=list(temp)
   }
   temporary=NULL
   for(y in 1:length(temp)){
    temporary=c(temporary,temp[[y]])
   }
   if(is.null(temporary)||sum(temporary<=0)>0){
    names(idioprior)[[length(idioprior)]]='idiotest'
   } else {
    names(idioprior)[[length(idioprior)]]=z
    #protect against user misspecification in the case that there are less idio distributions than num.partitions but more idio distributions than 1, in which case, the first idio distribution is used for all partitions
    if(length(temp)<num.partitions){
     if(length(temp)>1){
      idiocaution=1
     }
     #not duplicating prior according to the number of partitions since this makes draws with idiosyncratic buffering unnecessarily more difficult
     if(substr(z,1,7)=='epsilon'){
      idioprior[[paste(z,sep='')]]=append(idioprior[[paste(z,sep='')]],list(temp[[1]]))
     } else {
      idioprior[[paste(z,sep='')]]=append(idioprior[[paste(z,sep='')]],list(as.integer(temp[[1]])))
     }
    } else {
     if(length(temp)>num.partitions){
      idiocaution=1
     }
     for(y in 1:num.partitions){
      if(substr(z,1,7)=='epsilon'){
       idioprior[[paste(z,sep='')]]=append(idioprior[[paste(z,sep='')]],list(temp[[y]]))
      } else {
       idioprior[[paste(z,sep='')]]=append(idioprior[[paste(z,sep='')]],list(as.integer(temp[[y]])))
      }
     }
    }
   }
  }
 }

 return(append(idioprior,list(idiocaution=idiocaution)))

}


dice.read.linking=function(linked.param, attached.hyper, linked.param.partition, attached.hyper.pulse, linked.param.prior, linked.param.fixed){

 linking=NULL

 #convert user inputs linked.param and attached.hyper to vector, assign to object linking
 for(z in c('linked.param','attached.hyper','linked.param.partition','attached.hyper.pulse','linked.param.prior','linked.param.fixed')){
  if(typeof(eval(parse(text=z)))!='list'){
   linking=append(linking,list(eval(parse(text=z))))
   if(z=='linked.param.partition'||z=='attached.hyper.pulse'||z=='linked.param.prior'){
    linking[[length(linking)]]=list(linking[[length(linking)]])
    if(length(linking[[1]])>1){
     for(y in 2:length(linking[[1]])){
      linking[[length(linking)]]=append(linking[[length(linking)]],list(linking[[length(linking)]][[1]]))
     }
    }
   }
   if(z=='linked.param.fixed'&&length(linking[[1]])>1){
    linking[[6]]=rep(linking[[6]],length(linking[[1]]))
   }
  } else {
   linking=append(linking,list(NULL))
   if(z=='linked.param'||z=='attached.hyper'||z=='linked.param.fixed'){
    #iterating through the length of linked.param and attached.hyper protects against weird misspecifications, such as multiple items in each list element
    for(y in 1:length(eval(parse(text=z)))){
     linking[[length(linking)]]=c(linking[[length(linking)]],eval(parse(text=z))[[y]])
    }
   } else {
    for(y in 1:length(eval(parse(text=z)))){
     linking[[length(linking)]]=append(linking[[length(linking)]],list(eval(parse(text=z))[[y]]))
    }
   }
  }
 }
 for(z in 1:length(linking[[1]])){
  if(substr(linking[[1]][z],1,7)!='epsilon'){
   linking[[5]][[z]]=as.integer(linking[[5]][[z]])
  }
 }

 if(sum(c(sum(linking[[1]]=='tau'), sum(linking[[1]]=='tau2'), sum(linking[[1]]=='epsilon'), sum(linking[[1]]=='epsilon2'), sum(linking[[1]]=='NE'))) != length(linking[[1]]) || sum(c(sum(linking[[2]]=='tau'), sum(linking[[2]]=='tau2'), sum(linking[[2]]=='epsilon'), sum(linking[[2]]=='epsilon2'), sum(linking[[2]]=='NE'))) != length(linking[[2]]) || length(linking[[1]])!=length(linking[[2]]) || length(linking[[1]])!=length(linking[[3]]) || length(linking[[1]])!=length(linking[[4]]) || length(linking[[1]])!=length(linking[[5]]) || length(linking[[1]])!=length(linking[[6]])){
  return(-1)
 } else {
  return(linking)
 }

}


dice.read.flipvector=function(num.partitions, flip){

 flipvectorcaution=0

 #convert user input flip to vector, assign to object flipvector
 if(typeof(flip)!='list'){
  #protect against user misspecification in the case that there are less flip than num.partitions but more flip than 1, in which case, the first flip is used for all partitions
  if(length(flip)<num.partitions){
   if(length(flip)>1){
    flipvectorcaution=1
   }
   flipvector=rep(flip[1],num.partitions)
  } else {
   if(length(flip)>num.partitions){
    flipvectorcaution=1
   }
   flipvector=flip
  }
 } else {
  #iterating through the length of flip protects against weird misspecifications, such as less list elements than num.partitions but multiple items in each list element so that the total length of numeric elements = num.partitions (or >=)
  flipvector=NULL
  for(z in 1:length(flip)){
   flipvector=c(flipvector,flip[[z]])
  }
  if(length(flipvector)>num.partitions){
   flipvectorcaution=1
  }
  if(length(flipvector)<num.partitions){
   if(length(flipvector)>1){
    flipvectorcaution=1
   }
   flipvector=rep(flipvector[1],num.partitions)
  }
 }

 return(list(flipvector=flipvector,flipvectorcaution=flipvectorcaution))

}


#if a 2 event model is used for at least one partition, tau2 is not being inferred, and anchor.prior is specified by user, then the 'anchor' model is used, where ALL taxa will experience a 2 event model, and the timing of the older event is anchored by a set time delta; this anchor is the same across all taxa within the same pulse; each pulse thus draws from an anchor prior; the value of this anchor per pulse will be inferred; each pulse may have a different distribution defined; idiosyncratic taxa may draw from yet another distribution, though all idiosyncratic taxa will have independent draws from each other from the same distribution (in this idiosyncratic case, it acts identically as the change.prior)
dice.read.anchorprior=function(num.partitions, psipriortau, anchor.prior){

 anchorprior=NULL
 anchorcaution=0

 #convert user input anchor to list, assign to object anchorprior
 temp=anchor.prior
 if(typeof(temp)!='list'){
  temp=list(temp)
 }
 temporary=NULL
 for(y in 1:length(temp)){
  temporary=c(temporary,temp[[y]])
 }
 if(sum(temporary<1)>0){
  anchorprior=list(anchorprior)
  names(anchorprior)='anchortest'
 } else {
  #protect against user misspecification in the case that there are less anchor distributions than max(psivalue) but more anchor distributions than 1, in which case, the first anchor distribution is used for all pulses
  if(max(psipriortau)>0){
   if(length(temp)<max(psipriortau)){
    if(length(temp)>1){
     anchorcaution=1
    }
    for(y in 1:(max(psipriortau))){
     anchorprior=append(anchorprior,list(as.integer(temp[[1]])))
    }
   } else {
    if(length(temp)!=max(psipriortau)&&length(temp)!=(max(psipriortau)+1)&&length(temp)!=(max(psipriortau)+num.partitions)){
     anchorcaution=1
    }
    for(y in 1:(max(psipriortau))){
     anchorprior=append(anchorprior,list(as.integer(temp[[y]])))
    }
   }
  }
  #if an extra distribution is specified for anchor prior (i.e. length(anchorpriortemp)>=max(psivalue)+1), then the next distribution(s) following the max(psivalue) distribution will be used for idiosyncratic taxa; thus, to specify idiosyncratic taxa differently, must specify as many anchor distributions as max(psipriortau); otherwise, the first distribution will be used for idiosyncratic taxa
  if(length(temp)>=(max(psipriortau)+1)){
   if(length(temp)<(max(psipriortau)+num.partitions)){
    if(length(temp)>(max(psipriortau)+1)){
     anchorcaution=1
    }
    for(y in 1:num.partitions){
     anchorprior=append(anchorprior,list(as.integer(temp[[(max(psipriortau)+1)]])))
    }
   } else {
    if(length(temp)>(max(psipriortau)+num.partitions)){
     anchorcaution=1
    }
    for(y in (max(psipriortau)+1):(max(psipriortau)+num.partitions)){
     anchorprior=append(anchorprior,list(as.integer(temp[[y]])))
    }
   }
  } else {
   for(y in 1:num.partitions){
    anchorprior=append(anchorprior,list(as.integer(temp[[1]])))
   }
  }
 }

 return(list(anchorprior=anchorprior,anchorcaution=anchorcaution))

}


#if a 2 event model is used for at least one partition, tau2 is not being inferred, anchor.prior is NOT specified by user, and change.prior is specified by user (thus for a nuisance 2nd event, anchor.prior has 1st priority, then change.prior has 2nd priority), OR tau2 IS being inferred, taxa are allowed to act idiosyncratically, and change.prior is specified by user (thus for an inferred 2nd event with idiosyncratic taxa, change.prior has 1st priority; anchor.prior doesn't make sense here, since anchor.prior is practically a substitute for an inferred 2nd event and cannot act as a coinciding model just for the idiosyncratic taxa as it is pulse-based for the 1st event), then the "change" model is used, where all taxa that are in a partition experiencing a 2 event model and are either nuisance or idiosyncratic in the 2nd event will independently draw from a prior a value that indicates the time delta between the 1st and 2nd event
dice.read.changeprior=function(num.partitions, change.prior){

 changeprior=NULL
 changecaution=0

 #convert user input change to list, assign to object changeprior
 temp=change.prior
 if(typeof(temp)!='list'){
  temp=list(temp)
 }
 temporary=NULL
 for(y in 1:length(temp)){
  temporary=c(temporary,temp[[y]])
 }
 if(sum(temporary<1)>0){
  changeprior=list(changeprior)
  names(changeprior)='changetest'
 } else {
  #protect against user misspecification in the case that there are less change distributions than num.partitions but more change distributions than 1, in which case, the first change distribution is used for all partitions
  if(length(temp)<num.partitions){
   if(length(temp)>1){
    changecaution=1
   }
   for(y in 1:num.partitions){
    changeprior=append(changeprior,list(as.integer(temp[[1]])))
   }
  } else {
   if(length(temp)>num.partitions){
    changecaution=1
   }
   for(y in 1:num.partitions){
    changeprior=append(changeprior,list(as.integer(temp[[y]])))
   }
  }
 }

 return(list(changeprior=changeprior,changecaution=changecaution))

}


dice.read.exp.grow=function(num.partitions, exponential.growth.rate.prior, exponential.growth.rate.prior2){

 exp.grow=NULL
 exp.growcaution=0

 exp.dists=NULL
 if(!is.null(exponential.growth.rate.prior)){
  exp.dists=c(exp.dists,1)
 }
 if(!is.null(exponential.growth.rate.prior2)){
  exp.dists=c(exp.dists,2)
 }
 exp.names=c('exponential.growth.rate.prior','exponential.growth.rate.prior2')

 #convert user input(s) exponential.growth.rate(2) to list, assign to object exp.grow
 for(z in exp.dists){
  exp.grow=append(exp.grow,list(NULL))
  names(exp.grow)[[length(exp.grow)]]=exp.names[z]
  temp=eval(parse(text=exp.names[z]))
  if(typeof(temp)!='list'){
   temp=list(temp)
  }
  #protect against user misspecification in the case that there are less exponential.growth.rate distributions than num.partitions but more exponential.growth.rate distributions than 1, in which case, the first exponential.growth.rate distribution is used for all partitions
  if(length(temp)<num.partitions){
   if(length(temp)>1){
    exp.growcaution=1
   }
   for(y in 1:num.partitions){
    exp.grow[[exp.names[z]]]=append(exp.grow[[exp.names[z]]],list(temp[[1]]))
   }
  } else {
   if(length(temp)>num.partitions){
    exp.growcaution=1
   }
   for(y in 1:num.partitions){
    exp.grow[[exp.names[z]]]=append(exp.grow[[exp.names[z]]],list(temp[[y]]))
   }
  }
 }

 return(append(exp.grow,list(exp.growcaution=exp.growcaution)))

}



dice.read.numhaps=function(num.partitions, num.haploid.samples){

 numhapscaution=0

 #convert user input num.haploid.samples to vector, assign to object numhaps
 if(typeof(num.haploid.samples)!='list'){
  #protect against user misspecification in the case that there are less numsites than num.partitions but more numsites than 1, in which case, the first numsites is used for all partitions
  if(length(num.haploid.samples)<num.partitions){
   if(length(num.haploid.samples)>1){
    numhapscaution=1
   }
   numhaps=rep(num.haploid.samples[1],num.partitions)
  } else {
   if(length(num.haploid.samples)>num.partitions){
    numhapscaution=1
   }
   numhaps=num.haploid.samples
  }
 } else {
  #iterating through the length of num.haploid.samples protects against weird misspecifications, such as less list elements than num.partitions but multiple items in each list element so that the total length of numeric elements = num.partitions (or >=)
  numhaps=NULL
  for(z in 1:length(num.haploid.samples)){
   numhaps=c(numhaps,num.haploid.samples[[z]])
  }
  if(length(numhaps)>num.partitions){
   numhapscaution=1
  }
  if(length(numhaps)<num.partitions){
   if(length(numhaps)>1){
    numhapscaution=1
   }
   numhaps=rep(numhaps[1],num.partitions)
  }
 }

 if(sum(numhaps<1)>0){
  return(-1)
 } else {
  return(list(numhaps=numhaps,numhapscaution=numhapscaution))
 }

}


dice.read.numsites=function(num.partitions, num.ind.sites, num.SNPs, length.seq){

 numsitescaution=0

 #convert user input num.ind.sites, num.SNPs, or length.seq to vector, assign to object numsites; since numsites is being defined first here before reformatting, this is why the caution assessed before manipulating numsites into the proper format
 numsites=NULL
 if(!is.null(num.ind.sites)){
  numsites=num.ind.sites
 } else {
  if(!is.null(num.SNPs)){
   numsites=num.SNPs
  } else {
   if(!is.null(length.seq)){
    numsites=length.seq
   }
  }
 }
 if(typeof(numsites)!='list'){
  #protect against user misspecification in the case that there are less numsites than num.partitions but more numsites than 1, in which case, the first numsites is used for all partitions
  if(length(numsites)<num.partitions){
   if(length(numsites)>1){
    numsitescaution=1
   }
   numsites=rep(numsites[1],num.partitions)
  } else {
   if(length(numsites)>num.partitions){
    numsitescaution=1
   }
  }
 } else {
  #iterating through the length of numsites protects against weird misspecifications, such as less list elements than num.partitions but multiple items in each list element so that the total length of numeric elements = num.partitions (or >=)
  temp=NULL
  for(z in 1:length(numsites)){
   temp=c(temp,numsites[[z]])
  }
  numsites=temp
  if(length(numsites)>num.partitions){
   numsitescaution=1
  }
  if(length(numsites)<num.partitions){
   if(length(numsites)>1){
    numsitescaution=1
   }
   numsites=rep(numsites[1],num.partitions)
  }
 }

 if(sum(numsites<1)>0||is.null(numsites)){
  return(-1)
 } else {
  return(list(numsites=numsites,numsitescaution=numsitescaution))
 }

}


dice.read.fold=function(num.partitions, folded){

 foldcaution=0

 #convert user input folded to vector, assign to object fold
 if(typeof(folded)!='list'){
  #protect against user misspecification in the case that there are less folded than num.partitions but more folded than 1, in which case, the first folded is used for all partitions
  if(length(folded)<num.partitions){
   if(length(folded)>1){
    foldcaution=1
   }
   fold=rep(folded[1],num.partitions)
  } else {
   if(length(folded)>num.partitions){
    foldcaution=1
   }
   fold=folded
  }
 } else {
  #iterating through the length of folded protects against weird misspecifications, such as less list elements than num.partitions but multiple items in each list element so that the total length of numeric elements = num.partitions (or >=)
  fold=NULL
  for(z in 1:length(folded)){
   fold=c(fold,folded[[z]])
  }
  if(length(fold)>num.partitions){
   foldcaution=1
  }
  if(length(fold)<num.partitions){
   if(length(fold)>1){
   foldcaution=1
   }
   fold=rep(fold[1],num.partitions)
  }
 }

 return(list(fold=fold,foldcaution=foldcaution))

}


dice.read.samtimes=function(num.partitions, sampling.times){

 samtimescaution=0

 #convert user input sampling.times to vector, assign to object samtimes
 if(typeof(sampling.times)!='list'){
  #protect against user misspecification in the case that there are less numsites than num.partitions but more numsites than 1, in which case, the first numsites is used for all partitions
  if(length(sampling.times)<num.partitions){
   if(length(sampling.times)>1){
    samtimescaution=1
   }
   samtimes=rep(sampling.times[1],num.partitions)
  } else {
   if(length(sampling.times)>num.partitions){
    samtimescaution=1
   }
   samtimes=sampling.times
  }
 } else {
  #iterating through the length of num.haploid.samples protects against weird misspecifications, such as less list elements than num.partitions but multiple items in each list element so that the total length of numeric elements = num.partitions (or >=)
  samtimes=NULL
  for(z in 1:length(sampling.times)){
   samtimes=c(samtimes,sampling.times[[z]])
  }
  if(length(samtimes)>num.partitions){
   samtimescaution=1
  }
  if(length(samtimes)<num.partitions){
   if(length(samtimes)>1){
    samtimescaution=1
   }
   samtimes=rep(samtimes[1],num.partitions)
  }
 }

 if(sum(samtimes<0)>0){
  return(-1)
 } else {
  return(list(samtimes=samtimes,samtimescaution=samtimescaution))
 }

}


dice.read.gentimes=function(num.partitions, gen.times){

 gentimescaution=0

 #convert user input gen.times to vector, assign to object gentimes
 if(typeof(gen.times)!='list'){
  #user allowed to specify as many generation times as total number of taxa, in which case, ordering of generation times does not matter within partitions (since parameters values are randomly assigned and aSFS is order-independent) but does between partitions
  if(length(gen.times)>=sum(numtaxa[['numtaxa']])){
   if(length(gen.times)>sum(numtaxa[['numtaxa']])){
    gentimescaution=1
   }
   gentimes=gen.times
  } else {
   #user also allowed to specify as many generation times as number of partitions, in which case, all taxa within a partition will have the same generation time
   if(length(gen.times)>=num.partitions){
    if(length(gen.times)>num.partitions){
     gentimescaution=1
    }
    gentimes=NULL
    for(a in 1:num.partitions){
     gentimes=c(gentimes,rep(gen.times[a],numtaxa[['numtaxa']][a]))
    }
   #protect against user misspecification in the case that there are less gen.times than num.partitions or num.taxa but more gen.times than 1, in which case, the first gen.times is used for all partitions
   } else {
    if(length(gen.times)>1){
     gentimescaution=1
    }
    gentimes=rep(gen.times[1],sum(numtaxa[['numtaxa']]))
   }
  }
 } else {
  #iterating through the length of gen.times protects against weird misspecifications, such as less list elements than num.taxa/num.partitions but multiple items in each list element so that the total length of numeric elements = num.taxa/num.partitions (or >=)
  gentimes=NULL
  for(a in 1:length(gen.times)){
   gentimes=c(gentimes,gen.times[[a]])
  }
  if(length(gentimes)>sum(numtaxa[['numtaxa']])){
   gentimescaution=1
  }
  if(length(gentimes)>=num.partitions&&length(gentimes)<sum(numtaxa[['numtaxa']])){
   if(length(gentimes)>num.partitions){
    gentimescaution=1
   }
   temp=gentimes
   gentimes=NULL
   for(a in 1:num.partitions){
    gentimes=c(gentimes,rep(temp[a],numtaxa[['numtaxa']][a]))
   }
  }
  if(length(gentimes)>=1&&length(gentimes)<num.partitions){
   if(length(gentimes)>1){
    gentimescaution=1
   }
   gentimes=rep(gentimes[1],sum(numtaxa[['numtaxa']]))
  }
 }

 if(sum(gentimes<=0)>0){
  return(-1)
 } else {
  return(list(gentimes=gentimes,gentimescaution=gentimescaution))
 }

}


dice.read.mutrate=function(num.partitions, mut.rate.prior){

 mutrate=NULL
 mutratecaution=0

 #convert user input mut.rate to vector, assign to object mutrate
 temp=mut.rate.prior
 if(typeof(temp)!='list'){
  temp=list(temp)
 }
 temporary=NULL
 for(y in 1:length(temp)){
  temporary=c(temporary,temp[[y]])
 }
 if(sum(temporary<0)>0){
  return(-1)
 } else {
  #protect against user misspecification in the case that there are less mut.rate than num.partitions but more mut.rate than 1, in which case, the first mut.rate is used for all partitions
  if(length(temp)<num.partitions){
   if(length(temp)>1){
    mutratecaution=1
   }
   for(z in 1:num.partitions){
    mutrate=append(mutrate, list(temp[[1]]))
   }
  } else {
   if(length(temp)>num.partitions){
    mutratecaution=1
   }
   for(z in 1:num.partitions){
    mutrate=append(mutrate, list(temp[[z]]))
   }
  }
  return(append(mutrate,list(mutratecaution=mutratecaution)))
 }

}



dice.read.afc=function(num.partitions, remove.afclasses){

 afc=NULL
 afccaution=0

 #convert user input remove.afclasses to vector, assign to object afc
 temp=remove.afclasses
 if(typeof(temp)!='list'){
  temp=list(temp)
 }
 temporary=NULL
 for(y in 1:length(temp)){
  temporary=c(temporary,temp[[y]])
 }
 if(sum(temporary<0)>0){
  return(-1)
 } else {
  #protect against user misspecification in the case that there are less remove.afclasses than num.partitions but more remove.afclasses than 1, in which case, the first remove.afclasses is used for all partitions
  if(length(temp)<num.partitions){
   if(length(temp)>1){
    afccaution=1
   }
   for(z in 1:num.partitions){
    afc=append(afc, list(as.integer(temp[[1]])))
   }
  } else {
   if(length(temp)>num.partitions){
    afccaution=1
   }
   for(z in 1:num.partitions){
    afc=append(afc, list(as.integer(temp[[z]])))
   }
  }
  return(append(afc,list(afccaution=afccaution)))
 }

}


dice.read.inputdir=function(input.directory){

 #convert user input input.directory to vector, assign to object inputdir
 if(typeof(input.directory)!='list'){
  inputdir=input.directory
 } else {
  inputdir=NULL
  #iterating through the length of input.directory protects against weird misspecifications, such as multiple items in each list element
  for(z in 1:length(input.directory)){
   inputdir=c(temp,input.directory[[z]])
  }
 }

 for(z in 1:length(inputdir)){
  if(substr(inputdir[z],nchar(inputdir[z]),nchar(inputdir[z]))!='/'){
   inputdir[z]=paste(inputdir[z],'/',sep='')
  }
 }

 return(inputdir)

}


dice.read.inputs=function(numtaxa, input.base, input.files){

 inputscaution=0

 #convert user input input.base or input.files to vector, assign to object inputs
 if(!is.null(input.base)){
  if(typeof(input.base)!='list'){
   temp=input.base
  } else {
   temp=input.base[[1]][1]
  }
  inputs=NULL
  for(z in 1:sum(numtaxa[['numtaxa']])){
   inputs=c(inputs,paste(temp[1],z,sep=''))
  }
 } else {
  if(typeof(input.files)!='list'){
   inputs=input.files
  } else {
   inputs=NULL
   #iterating through the length of input.files protects against weird misspecifications, such as less list elements than numtaxa but multiple items in each list element so that the total length of numeric elements = numtaxa (or >=)
   for(z in 1:length(input.files)){
    inputs=c(inputs,input.files[[z]])
   }
  }
  #protect against user misspecification in the case that there are less input.files than numtaxa
  if(length(inputs)<sum(numtaxa[['numtaxa']])){
   inputs=-1
  }
  if(length(inputs)>sum(numtaxa[['numtaxa']])){
   inputscaution=1
   inputs=inputs[1:sum(numtaxa[['numtaxa']])]
  }
 }

 if(-1%in%inputs){
  return(-1)
 } else {
  return(list(inputs=inputs,inputscaution=inputscaution))
 }

}




if(!'schoolmath'%in%rownames(installed.packages())){
 install.packages('schoolmath')
}
library(schoolmath)
#' @importFrom schoolmath gcd scm
#' @export
build.dice=function(num.taxa, num.partitions=1, tau.psi.prior=NULL, epsilon.psi.prior=NULL, NE.psi.prior=NULL, tau.zeta.prior=NULL, tau2.zeta.prior=NULL, epsilon.zeta.prior=NULL, epsilon2.zeta.prior=NULL, NE.zeta.prior=NULL, tau.zeta.total.prior=NULL, tau2.zeta.total.prior=NULL, epsilon.zeta.total.prior=NULL, epsilon2.zeta.total.prior=NULL, NE.zeta.total.prior=NULL, dirichlet.process=F, idiosyncratic=T, min.net.tau.zeta.total=NULL, min.net.tau2.zeta.total=NULL, min.net.epsilon.zeta.total=NULL, min.net.epsilon2.zeta.total=NULL, min.net.NE.zeta.total=NULL, max.net.tau.zeta.total=NULL, max.net.tau2.zeta.total=NULL, max.net.epsilon.zeta.total=NULL, max.net.epsilon2.zeta.total=NULL, max.net.NE.zeta.total=NULL, min.net.tau.zeta.per.pulse=NULL, min.net.tau2.zeta.per.pulse=NULL, min.net.epsilon.zeta.per.pulse=NULL, min.net.epsilon2.zeta.per.pulse=NULL, min.net.NE.zeta.per.pulse=NULL, max.net.tau.zeta.per.pulse=NULL, max.net.tau2.zeta.per.pulse=NULL, max.net.epsilon.zeta.per.pulse=NULL, max.net.epsilon2.zeta.per.pulse=NULL, max.net.NE.zeta.per.pulse=NULL, num.sims, num.haploid.samples, num.ind.sites, num.SNPs, length.seq, folded, sampling.times, gen.times, remove.afclasses, convert.sequences, tau.shared.prior, tau2.shared.prior, epsilon.shared.prior, epsilon2.shared.prior, NE.shared.prior, tau.idio.prior, tau2.idio.prior, epsilon.idio.prior, epsilon2.idio.prior, NE.idio.prior, linked.param, attached.hyper, linked.param.partition, attached.hyper.pulse, linked.param.prior, linked.param.fixed, anchor.prior, change.prior, exponential.growth.rate.prior, exponential.growth.rate.prior2, mut.rate.prior, tau.buffer, tau2.buffer, epsilon.buffer, epsilon2.buffer, NE.buffer, tau.idiosyncratic.buffer, tau2.idiosyncratic.buffer, epsilon.idiosyncratic.buffer, epsilon2.idiosyncratic.buffer, NE.idiosyncratic.buffer, idiosyncratic.rule, num.changes, flip, net.zeta.total, net.zeta.per.pulse, mean.tau.shared, mean.tau2.shared, mean.epsilon.shared, mean.epsilon2.shared, mean.NE.shared, mean.tau, mean.tau2, mean.epsilon, mean.epsilon2, mean.NE, disp.index.tau.shared, disp.index.tau2.shared, disp.index.epsilon.shared, disp.index.epsilon2.shared, disp.index.NE.shared, disp.index.tau, disp.index.tau2, disp.index.epsilon, disp.index.epsilon2, disp.index.NE, fsc2path, messages.sims, output.directory, input.directory, input.base, input.files, append.sims, keep.taxa.draws, output.hyper.draws, output.taxa.draws, keep.fsc2.files, build.object, roll.object, play.object){

 output=NULL

 numtaxa=dice.read.numtaxa(num.taxa, num.partitions)
 if(-1%in%numtaxa){
  print("You have included a non-positive number in the 'num.taxa' object; Multi-DICE cannot continue")
 }

 psiprior=dice.read.psiprior(tau.psi.prior=tau.psi.prior, epsilon.psi.prior=epsilon.psi.prior, NE.psi.prior=NE.psi.prior)
 if(is.null(psiprior)){
  print("You have not specified a 'psi.prior' object; Multi-DICE cannot continue")
 }
 if('psitest'%in%names(psiprior)){
  print("You have included a negative number in a 'psi.prior' object; Multi-DICE cannot continue")
 }

 minmax.per.pulse=dice.read.minmax.per.pulse(numtaxa=numtaxa, psiprior=psiprior, min.net.tau.zeta.per.pulse=min.net.tau.zeta.per.pulse, min.net.tau2.zeta.per.pulse=min.net.tau2.zeta.per.pulse, min.net.epsilon.zeta.per.pulse=min.net.epsilon.zeta.per.pulse, min.net.epsilon2.zeta.per.pulse=min.net.epsilon2.zeta.per.pulse, min.net.NE.zeta.per.pulse=min.net.NE.zeta.per.pulse, max.net.tau.zeta.per.pulse=max.net.tau.zeta.per.pulse, max.net.tau2.zeta.per.pulse=max.net.tau2.zeta.per.pulse, max.net.epsilon.zeta.per.pulse=max.net.epsilon.zeta.per.pulse, max.net.epsilon2.zeta.per.pulse=max.net.epsilon2.zeta.per.pulse, max.net.NE.zeta.per.pulse=max.net.NE.zeta.per.pulse)
 if(-1%in%minmax.per.pulse){
  print("You have included a negative number or number above 1.0 in a 'min.net'/'max.net' 'zeta.per.pulse' object; Multi-DICE cannot continue")
 }

 zetaprior=dice.read.zetaprior(numtaxa, num.partitions, psiprior, tau.zeta.prior, tau2.zeta.prior, epsilon.zeta.prior, epsilon2.zeta.prior, NE.zeta.prior, idiosyncratic, min.net.tau.zeta.total, min.net.tau2.zeta.total, min.net.epsilon.zeta.total, min.net.epsilon2.zeta.total, min.net.NE.zeta.total, max.net.tau.zeta.total, max.net.tau2.zeta.total, max.net.epsilon.zeta.total, max.net.epsilon2.zeta.total, max.net.NE.zeta.total, minmax.per.pulse)
 if('zetaminmaxtest'%in%names(zetaprior)){
  print("You have included a number not equal to 1.0 in a 'min.net'/'max.net' 'zeta.total' object while specifying the 'idiosyncratic' setting to FALSE; Multi-DICE cannot continue")
 }
 if('zetatest'%in%names(zetaprior)){
  print("You have not specified a 'zeta.prior' object corresponding to a 'psi.prior' object that you have specified, or have included a negative number and/or number above 1.0 in a 'zeta.prior' object; Multi-DICE cannot continue")
 }
 if('zetaminmaxidiotest'%in%names(zetaprior)){
  print("You have specified a 'zeta.prior' object that does not allow for any valid draws given some combination of the following: number of taxa per partition, corresponding 'psi.prior' and 'zeta.prior' distributions, 'idiosyncratic' setting, and associated 'min.net'/'max.net' 'zeta.total'/'zeta.per.pulse' objects; Multi-DICE cannot continue")
 }

 done=0
 if(!is.null(tau.zeta.total.prior)||!is.null(tau2.zeta.total.prior)||!is.null(epsilon.zeta.total.prior)||!is.null(epsilon2.zeta.total.prior)||!is.null(NE.zeta.total.prior)){
  psipriortemp=NULL
  for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
   if(!is.null(eval(parse(text=paste(z,'.zeta.total.prior',sep=''))))&&z%in%names(psiprior)){
    psipriortemp=append(psipriortemp,list(1))
    names(psipriortemp)[length(psipriortemp)]=z
   }
  }
  if(!is.null(psipriortemp)){
   zetatotalprior=dice.read.zetaprior(list(numtaxa=sum(numtaxa[['numtaxa']])), num.partitions=1, psipriortemp, tau.zeta.total.prior, tau2.zeta.total.prior, epsilon.zeta.total.prior, epsilon2.zeta.total.prior, NE.zeta.total.prior, idiosyncratic, min.net.tau.zeta.total, min.net.tau2.zeta.total, min.net.epsilon.zeta.total, min.net.epsilon2.zeta.total, min.net.NE.zeta.total, max.net.tau.zeta.total, max.net.tau2.zeta.total, max.net.epsilon.zeta.total, max.net.epsilon2.zeta.total, max.net.NE.zeta.total, minmax.per.pulse=list(NULL))
   if('zetatest'%in%names(zetatotalprior)){
    print("You have included a negative number and/or number above 1.0 in a 'zeta.total.prior' object; Multi-DICE cannot continue")
    done=1
   }
   if('zetaminmaxidiotest'%in%names(zetatotalprior)){
    print("You have specified a 'zeta.total.prior' object that does not allow for any valid draws given some combination of the following: number of taxa, corresponding 'psi.prior', 'zeta.prior', and 'zeta.total.prior' distributions, 'idiosyncratic' setting, and associated 'min.net'/'max.net' 'zeta.total'/'zeta.per.pulse' objects; Multi-DICE cannot continue")
    done=1
   }
  }
 }

 if(!-1%in%numtaxa&&!is.null(psiprior)&&!'psitest'%in%names(psiprior)&&!-1%in%minmax.per.pulse&&!'zetaminmaxtest'%in%names(zetaprior)&&!'zetatest'%in%names(zetaprior)&&!'zetaminmaxidiotest'%in%names(zetaprior)&&done==0){

  if(numtaxa[['numtaxacaution']]==1){
   print("Caution: You have specified an inappropriate number of vector elements for the 'num.taxa' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'num.taxa' elements, with x = 'num.partitions', or if not applicable, with the first 'num.taxa' element used for all partitions")
  }
  if(psiprior[['psicaution']]==1){
   print("Caution: You have specified more than the allowable number of distributions for a 'psi.prior' object (1 for Ne and 2 for tau and epsilon); Multi-DICE will continue with only the first 'psi.prior' distributions up to the allowable amount")
  }
  if(minmax.per.pulse[['minmaxcaution']]==1){
   print("Caution: You have specified an inappropriate number of vector elements for a 'min.net'/'max.net' 'zeta.per.pulse' object; this should be of length = maximum value in the corresponding 'psi.prior' distribution or 1; Multi-DICE will continue with only the first x elements, with x = maximum value in the corresponding 'psi.prior' distribution, or if not applicable, with the first element used for all pulses")
  }
  if(zetaprior[['zetacaution']]==1){
   print("Caution: You have specified an inappropriate number of distributions for a 'zeta.prior' object; the number of distributions should be = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'zeta.prior' distributions, with x = 'num.partitions', or if not applicable, with the first 'zeta.prior' distribution used for all partitions")
  }
  if(!is.null(tau.zeta.total.prior)||!is.null(tau2.zeta.total.prior)||!is.null(epsilon.zeta.total.prior)||!is.null(epsilon2.zeta.total.prior)||!is.null(NE.zeta.total.prior)){
   if(zetatotalprior[['zetacaution']]==1){
    print("Caution: You have specified more than one distribution for a 'zeta.total.prior' object; Multi-DICE will continue with only the first 'zeta.total.prior' distribution")
   }
  }

  finished=0
  for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
   #if this psi is intended to be inferred
   if(z%in%names(psiprior)&&finished==0){
    #assign quantity of draws as determined by the combinatorics (if applicable) to object hyperprior, which then becomes the unmodified/uniform/dirichlet-process hyperprior distribution
    if(max(zetaprior[[paste(z,sep='')]]$draws[[1]][,1])==0){
     hyperprior=as.integer(1)
    } else {
     hyperprior=NULL
     temporary=NULL
     #zeta (total across all pulses) value of each possible draw, for uniform hyperprior
     if(!is.null(eval(parse(text=paste(z,'.zeta.total.prior',sep=''))))){
      for(y in 1:nrow(zetaprior[[paste(z,sep='')]]$draws[[1]])){
       if(zetaprior[[paste(z,sep='')]]$draws[[1]][y,1]==0){
        temporary=c(temporary,as.integer(0))
       } else {
        temp=0
        for(x in 1:num.partitions){
         temp=temp+sum(zetaprior[[paste(z,sep='')]]$combos[[x]][[paste('pulse',zetaprior[[paste(z,sep='')]]$draws[[x]][y,1],sep='')]][zetaprior[[paste(z,sep='')]]$draws[[x]][y,2],])
        }
        temporary=c(temporary,temp)
       }
      }
     }
     #number of possible combinations given zeta vector values and number of taxa per partition of each possible draw, for uniform and dirichlet-process hyperprior
     if(!is.null(eval(parse(text=paste(z,'.zeta.total.prior',sep=''))))||dirichlet.process==T){
      #save combination calculations in factorial.library for efficiency
      factorial.library=NULL
      #zetaprior is built from partition->psi->zeta combos, whereas factorial.library is built from psi->partition; also, the number of psi list elements = number of unique psi values in zetaprior$combos, whereas it is = 1:max(psiprior) in factorial.library (and similarly, the value in zetaprior$draws is the actual psi value, not referring to the number of unique psi values)
      for(y in 1:max(psiprior[[paste(z,sep='')]])){
       factorial.library=append(factorial.library,list(NULL))
       for(x in 1:num.partitions){
        factorial.library[[y]]=append(factorial.library[[y]],list(NULL))
       }
      }
      for(y in 1:nrow(zetaprior[[paste(z,sep='')]]$draws[[1]])){
       if(zetaprior[[paste(z,sep='')]]$draws[[1]][y,1]==0){
        temporary=c(temporary,1)
       } else {
        temp=NULL
        for(x in 1:num.partitions){
         if(zetaprior[[paste(z,sep='')]]$draws[[x]][y,2]%in%factorial.library[[zetaprior[[paste(z,sep='')]]$draws[[x]][y,1]]][[x]][,1]){
          temp=c(temp,factorial.library[[zetaprior[[paste(z,sep='')]]$draws[[x]][y,1]]][[x]][zetaprior[[paste(z,sep='')]]$draws[[x]][y,2]==factorial.library[[zetaprior[[paste(z,sep='')]]$draws[[x]][y,1]]][[x]][,1],2])
         } else {
          temp=c(temp,factorial(numtaxa[['numtaxa']][x]))
          for(w in 1:zetaprior[[paste(z,sep='')]]$draws[[x]][y,1]){
           temp[x]=temp[x]/(factorial(zetaprior[[paste(z,sep='')]]$combos[[x]][[paste('pulse',zetaprior[[paste(z,sep='')]]$draws[[x]][y,1],sep='')]][zetaprior[[paste(z,sep='')]]$draws[[x]][y,2],w]))
          }
          temp[x]=temp[x]/(factorial(numtaxa[['numtaxa']][x]-sum(zetaprior[[paste(z,sep='')]]$combos[[x]][[paste('pulse',zetaprior[[paste(z,sep='')]]$draws[[x]][y,1],sep='')]][zetaprior[[paste(z,sep='')]]$draws[[x]][y,2],])))
          factorial.library[[zetaprior[[paste(z,sep='')]]$draws[[x]][y,1]]][[x]]=rbind(factorial.library[[zetaprior[[paste(z,sep='')]]$draws[[x]][y,1]]][[x]],c(zetaprior[[paste(z,sep='')]]$draws[[x]][y,2],temp[x]))
         }
        }
        temporary=c(temporary,prod(temp))
       }
      }
     }
     if(!is.null(eval(parse(text=paste(z,'.zeta.total.prior',sep=''))))){
      temporary=cbind(temporary[1:(length(temporary)/2)],temporary[((length(temporary)/2)+1):length(temporary)])
      #if a draw in zetaprior is not specified in zetatotalprior
      for(y in unique(temporary[,1])){
       if(!y%in%zetatotalprior[[paste(z,sep='')]]$combos[[1]][[1]]){
        temp=which(temporary[,1]==y)
        if(y==0&&0%in%psiprior[[paste(z,sep='')]]){
         temp=temp[temp!=which(zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==0)]
        }
        if(length(temp)>0){
         temporary=temporary[-temp,]
         for(x in 1:num.partitions){
          zetaprior[[paste(z,sep='')]]$draws[[x]]=zetaprior[[paste(z,sep='')]]$draws[[x]][-temp,]
         }
        }
       }
      }
      #check if there are any valid draws according to zetatotalprior
      if(length(temporary)>0){
       #per psi value, all zeta (total across all pulses) values are uniform, across the different combinations making up each of those values
       for(y in unique(zetaprior[[paste(z,sep='')]]$draws[[1]][,1][zetaprior[[paste(z,sep='')]]$draws[[1]][,1]!=0])){
        if(sum(zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y)>1){
         first=0
         for(x in which(zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y)){
          if(first==0){
           first=1
           gcf=temporary[x,2]
          }
          gcf=capture.output(gcd(gcf,temporary[x,2]))
          gcf=gcf[length(gcf)]
          gcf=as.numeric(substr(gcf,5,nchar(gcf)))
         }
         temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,2]=temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,2]/gcf
        }
        temp=NULL
        for(x in zetatotalprior[[paste(z,sep='')]]$combos[[1]][[1]]){
         if(x%in%temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,1]){
          if(sum(zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y)==1){
           temp=c(temp,sum(temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,2]))
          } else {
           temp=c(temp,sum(temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,][temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,1]==x,2]))
          }
         }
        }
        if(length(temp)>1){
         lcm=temp[1]
         for(x in 2:length(temp)){
          lcm=capture.output(scm(lcm,temp[x]))
          lcm=lcm[length(lcm)]
          lcm=as.numeric(substr(lcm,5,nchar(lcm)))
         }
         temp=lcm/temp
         for(x in zetatotalprior[[paste(z,sep='')]]$combos[[1]][[1]]){
          if(x%in%temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,1]){
           for(w in which(zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y)){
            if(temporary[w,1]==x){
             temporary[w,2]=temporary[w,2]*temp[1]
            }
           }
           temp=temp[-1]
          }
         }
        }
        if(sum(zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y)>1){
         first=0
         for(x in which(zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y)){
          if(first==0){
           first=1
           gcf=temporary[x,2]
          }
          gcf=capture.output(gcd(gcf,temporary[x,2]))
          gcf=gcf[length(gcf)]
          gcf=as.numeric(substr(gcf,5,nchar(gcf)))
         }
         temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,2]=temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,2]/gcf
        }
       }
       #all psi values are uniform, across the different combinations making up each of those values
       if(length(unique(zetaprior[[paste(z,sep='')]]$draws[[1]][,1]))>1){
        temp=NULL
        for(y in unique(zetaprior[[paste(z,sep='')]]$draws[[1]][,1])){
         temp=c(temp,sum(temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,2]))
        }
        lcm=temp[1]
        for(y in 2:length(temp)){
         lcm=capture.output(scm(lcm,temp[y]))
         lcm=lcm[length(lcm)]
         lcm=as.numeric(substr(lcm,5,nchar(lcm)))
        }
        temp=lcm/temp
        for(y in unique(zetaprior[[paste(z,sep='')]]$draws[[1]][,1])){
         temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,2]=temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,2]*temp[1]
         temp=temp[-1]
        }
       }
       #correct for duplicated psi values in the psi prior, since duplicated psi values were not taken into consideration when building zetaprior (redundant zeta values were accounted for by iterating through each of the zetatotalprior combos; relatedly, redundant zeta values in the zetaprior are somewhat ignored since the uniform hyperprior is based on the zetatotalprior, though perhaps less so if values are redundant in one partition and not another)
       for(y in unique(zetaprior[[paste(z,sep='')]]$draws[[1]][,1])){
        if(sum(y==psiprior[[paste(z,sep='')]])>1){
         temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,2]=temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y,2]*sum(y==psiprior[[paste(z,sep='')]])
        }
       }
       if(nrow(temporary)>1){
        gcf=temporary[1,1]
        for(x in 2:nrow(temporary)){
         gcf=capture.output(gcd(gcf,temporary[x,2]))
         gcf=gcf[length(gcf)]
         gcf=as.numeric(substr(gcf,5,nchar(gcf)))
        }
        temporary[,2]=temporary[,2]/gcf
       }
       for(y in 1:nrow(temporary)){
        hyperprior=c(hyperprior,rep(as.integer(y),temporary[y,2]))
       }
      } else {
       finished=1
       print(paste("You have specified a '",z,".zeta.total.prior' object that does not allow for any valid draws given some combination of the following: number of taxa, corresponding 'psi.prior', 'zeta.prior', and 'zeta.total.prior' distributions, 'idiosyncratic' setting, and associated 'min.net'/'max.net' 'zeta.total'/'zeta.per.pulse' objects",sep=''))
      }
     }
     if(dirichlet.process==T&&is.null(eval(parse(text=paste(z,'.zeta.total.prior',sep=''))))){
      #correct for duplicated psi values in the psi prior, since duplicated psi values were not taken into consideration when building zetaprior (redundant zeta values were corrected for though when the zetaprior combos was constructed)
      for(y in unique(zetaprior[[paste(z,sep='')]]$draws[[1]][,1])){
       if(sum(y==psiprior[[paste(z,sep='')]])>1){
        temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y]=temporary[zetaprior[[paste(z,sep='')]]$draws[[1]][,1]==y]*sum(y==psiprior[[paste(z,sep='')]])
       }
      }
      if(length(temporary)>1){
       gcf=temporary[1]
       for(x in 2:length(temporary)){
        gcf=capture.output(gcd(gcf,temporary[x]))
        gcf=gcf[length(gcf)]
        gcf=as.numeric(substr(gcf,5,nchar(gcf)))
       }
       temporary=temporary/gcf
      }
      for(y in 1:length(temporary)){
       hyperprior=c(hyperprior,rep(as.integer(y),temporary[y]))
      }
     }
     if(is.null(temporary)){
      #correct for duplicated psi values in the psi prior, since duplicated psi values were not taken into consideration when building zetaprior (redundant zeta values were corrected for though when the zetaprior combos was constructed)
      for(y in 1:nrow(zetaprior[[paste(z,sep='')]]$draws[[1]])){
       hyperprior=c(hyperprior,rep(as.integer(y),sum(zetaprior[[paste(z,sep='')]]$draws[[1]][y,1]==psiprior[[paste(z,sep='')]])))
      }
     }
    }
    if(finished==0){
     #hyperprior: each element specifies a row number in the draws list of matrices; draws: list of matrices equal in quantity to num.partitions, with the row of each matrix containing the psi value and row number in the combos list of matrices; combos: list of list of matrices with zeta value(s), organized by partition (list elements), then psi (list elements within list elements), then combinations of zeta values (each row a different combination, each column a different pulse from most recent L to most ancient R)
     output=append(output,list(append(zetaprior[[paste(z,sep='')]],list(hyperprior=hyperprior))))
     names(output)[length(output)]=z
    }
   }
  }
  if(finished==0){
   return(output)
  } else {
   return(NULL)
  }
 } else {
  return(NULL)
 }

}



#' @export
roll.dice=function(num.sims, num.taxa, num.partitions=1, tau.psi.prior=NULL, epsilon.psi.prior=NULL, NE.psi.prior=NULL, tau.zeta.prior=NULL, tau2.zeta.prior=NULL, epsilon.zeta.prior=NULL, epsilon2.zeta.prior=NULL, NE.zeta.prior=NULL, tau.zeta.total.prior=NULL, tau2.zeta.total.prior=NULL, epsilon.zeta.total.prior=NULL, epsilon2.zeta.total.prior=NULL, NE.zeta.total.prior=NULL, tau.shared.prior=NULL, tau2.shared.prior=NULL, epsilon.shared.prior=NULL, epsilon2.shared.prior=NULL, NE.shared.prior=NULL, dirichlet.process=F, idiosyncratic=T, min.net.tau.zeta.total=NULL, min.net.tau2.zeta.total=NULL, min.net.epsilon.zeta.total=NULL, min.net.epsilon2.zeta.total=NULL, min.net.NE.zeta.total=NULL, max.net.tau.zeta.total=NULL, max.net.tau2.zeta.total=NULL, max.net.epsilon.zeta.total=NULL, max.net.epsilon2.zeta.total=NULL, max.net.NE.zeta.total=NULL, min.net.tau.zeta.per.pulse=NULL, min.net.tau2.zeta.per.pulse=NULL, min.net.epsilon.zeta.per.pulse=NULL, min.net.epsilon2.zeta.per.pulse=NULL, min.net.NE.zeta.per.pulse=NULL, max.net.tau.zeta.per.pulse=NULL, max.net.tau2.zeta.per.pulse=NULL, max.net.epsilon.zeta.per.pulse=NULL, max.net.epsilon2.zeta.per.pulse=NULL, max.net.NE.zeta.per.pulse=NULL, tau.buffer=0, tau2.buffer=0, epsilon.buffer=0, epsilon2.buffer=0, NE.buffer=0, build.object=NULL, num.haploid.samples, num.ind.sites, num.SNPs, length.seq, folded, sampling.times, gen.times, remove.afclasses, convert.sequences, tau.idio.prior, tau2.idio.prior, epsilon.idio.prior, epsilon2.idio.prior, NE.idio.prior, linked.param, attached.hyper, linked.param.partition, attached.hyper.pulse, linked.param.prior, linked.param.fixed, anchor.prior, change.prior, exponential.growth.rate.prior, exponential.growth.rate.prior2, mut.rate.prior, tau.idiosyncratic.buffer, tau2.idiosyncratic.buffer, epsilon.idiosyncratic.buffer, epsilon2.idiosyncratic.buffer, NE.idiosyncratic.buffer, idiosyncratic.rule, num.changes, flip, net.zeta.total, net.zeta.per.pulse, mean.tau.shared, mean.tau2.shared, mean.epsilon.shared, mean.epsilon2.shared, mean.NE.shared, mean.tau, mean.tau2, mean.epsilon, mean.epsilon2, mean.NE, disp.index.tau.shared, disp.index.tau2.shared, disp.index.epsilon.shared, disp.index.epsilon2.shared, disp.index.NE.shared, disp.index.tau, disp.index.tau2, disp.index.epsilon, disp.index.epsilon2, disp.index.NE, fsc2path, messages.sims, output.directory, input.directory, input.base, input.files, append.sims, keep.taxa.draws, output.hyper.draws, output.taxa.draws, keep.fsc2.files, roll.object, play.object){

 messages=0
 if(is.null(build.object)){
  build.object=build.dice(num.taxa=num.taxa, num.partitions=num.partitions, tau.psi.prior=tau.psi.prior, epsilon.psi.prior=epsilon.psi.prior, NE.psi.prior=NE.psi.prior, tau.zeta.prior=tau.zeta.prior, tau2.zeta.prior=tau2.zeta.prior, epsilon.zeta.prior=epsilon.zeta.prior, epsilon2.zeta.prior=epsilon2.zeta.prior, NE.zeta.prior=NE.zeta.prior, tau.zeta.total.prior=tau.zeta.total.prior, tau2.zeta.total.prior=tau2.zeta.total.prior, epsilon.zeta.total.prior=epsilon.zeta.total.prior, epsilon2.zeta.total.prior=epsilon2.zeta.total.prior, NE.zeta.total.prior=NE.zeta.total.prior, dirichlet.process=dirichlet.process, idiosyncratic=idiosyncratic, min.net.tau.zeta.total=min.net.tau.zeta.total, min.net.tau2.zeta.total=min.net.tau2.zeta.total, min.net.epsilon.zeta.total=min.net.epsilon.zeta.total, min.net.epsilon2.zeta.total=min.net.epsilon2.zeta.total, min.net.NE.zeta.total=min.net.NE.zeta.total, max.net.tau.zeta.total=max.net.tau.zeta.total, max.net.tau2.zeta.total=max.net.tau2.zeta.total, max.net.epsilon.zeta.total=max.net.epsilon.zeta.total, max.net.epsilon2.zeta.total=max.net.epsilon2.zeta.total, max.net.NE.zeta.total=max.net.NE.zeta.total, min.net.tau.zeta.per.pulse=min.net.tau.zeta.per.pulse, min.net.tau2.zeta.per.pulse=min.net.tau2.zeta.per.pulse, min.net.epsilon.zeta.per.pulse=min.net.epsilon.zeta.per.pulse, min.net.epsilon2.zeta.per.pulse=min.net.epsilon2.zeta.per.pulse, min.net.NE.zeta.per.pulse=min.net.NE.zeta.per.pulse, max.net.tau.zeta.per.pulse=max.net.tau.zeta.per.pulse, max.net.tau2.zeta.per.pulse=max.net.tau2.zeta.per.pulse, max.net.epsilon.zeta.per.pulse=max.net.epsilon.zeta.per.pulse, max.net.epsilon2.zeta.per.pulse=max.net.epsilon2.zeta.per.pulse, max.net.NE.zeta.per.pulse=max.net.NE.zeta.per.pulse)
  messages=1
 }

 if(!is.null(build.object)){

  psiprior=dice.read.psiprior(tau.psi.prior=tau.psi.prior, epsilon.psi.prior=epsilon.psi.prior, NE.psi.prior=NE.psi.prior)
  if(is.null(psiprior)){
   print("You have not specified a 'psi.prior' object; Multi-DICE cannot continue")
  }
  if('psitest'%in%names(psiprior)){
   print("You have included a negative number in a 'psi.prior' object; Multi-DICE cannot continue")
  }

  sharedprior=dice.read.sharedprior(psiprior=psiprior, tau.shared.prior=tau.shared.prior, tau2.shared.prior=tau2.shared.prior, epsilon.shared.prior=epsilon.shared.prior, epsilon2.shared.prior=epsilon2.shared.prior, NE.shared.prior=NE.shared.prior)
  if('sharedtest'%in%names(sharedprior)){
   print("You have not specified a 'shared.prior' object corresponding to a 'psi.prior' object that you have specified, or have specified a 'shared' prior of inappropriate range relative to a 'shared' prior from another pulse and/or have included a non-positive number in a 'shared.prior' object; Multi-DICE cannot continue")
  }

  buff=dice.read.buff(psiprior=psiprior, tau.buffer=tau.buffer, tau2.buffer=tau2.buffer, epsilon.buffer=epsilon.buffer, epsilon2.buffer=epsilon2.buffer, NE.buffer=NE.buffer)
  sign=0
  if('bufftest'%in%names(buff)){
   print("You have specified a 'buffer' object as the wrong type (i.e. not a numeric value or function), or have included a negative number in a 'buffer' object; Multi-DICE cannot continue")
  } else {
   for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
    if(z%in%names(psiprior)){
     if(max(build.object[[paste(z,sep='')]]$draws[[1]][,1])>1&&typeof(buff[[paste(z,sep='')]])=='double'||max(build.object[[paste(z,sep='')]]$draws[[1]][,1])>1&&typeof(buff[[paste(z,sep='')]])=='integer'){
      signage=0
      if(length(sharedprior[[paste(z,sep='')]])==1){
       if(((max(build.object[[paste(z,sep='')]]$draws[[1]][,1])-1)*((2*buff[[paste(z,sep='')]])+1))>=(max(unique(sharedprior[[paste(z,sep='')]][[1]]))-min(unique(sharedprior[[paste(z,sep='')]][[1]])))){
        signage=1
       }
      } else {
       temp=0
       y=0
       while(y<length(sharedprior[[paste(z,sep='')]])&&signage==0){
        y=y+1
        #temp represents upper limit of buffered out, non-applicable draws; all successive sharedpriors need to be of equal or higher range, both lower and upper bounds
        if(temp>=max(sharedprior[[paste(z,sep='')]][[y]])){
         signage=1
        } else {
         if(y<length(sharedprior[[paste(z,sep='')]])){
          if(min(sharedprior[[paste(z,sep='')]][[y]])>(temp+1)){
           temp=min(sharedprior[[paste(z,sep='')]][[y]])-1
          }
          temp=temp+(2*buff[[paste(z,sep='')]])+1
         }
        }
       }
      }
      if(signage==1){
       print(paste("You have specified a '",z,".shared.prior' object that is too restricted given the corresponding upper 'psi' boundary and 'buffer' object; Multi-DICE cannot continue",sep=''))
      }
      if(sign==0&&signage==1){
       sign=1
      }
     }
    }
   }
  }

  if(!is.null(psiprior)&&!'psitest'%in%names(psiprior)&&!'sharedtest'%in%names(sharedprior)&&!'bufftest'%in%names(buff)&&sign==0){

   if(messages==0){
    if(psiprior[['psicaution']]==1){
     print("Caution: You have specified more than the allowable number of distributions for a 'psi.prior' object (1 for Ne and 2 for tau and epsilon); Multi-DICE will continue with only the first 'psi.prior' distributions up to the allowable amount")
    }
   }
   if(sharedprior[['sharedcaution']]==1){
    print("Caution: You have specified an inappropriate number of distributions for a 'shared.prior' object; the number of distributions should be = maximum value in the corresponding 'psi.prior' distribution (may include more for idiosyncratic distributions, equal to num.partitions or 1) or 1; Multi-DICE will continue with only the first 'shared' distribution for all pulses")
   }

   draws.psi=NULL
   draws.zeta=NULL
   draws.pulse.values=NULL

   for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
    #if this hyperparameter is intended to be inferred
    if(z%in%names(build.object)){
     if(length(build.object[[paste(z,sep='')]]$hyperprior)==1){
      draws=rep(build.object[[paste(z,sep='')]]$hyperprior,num.sims)
     } else {
      draws=sample(build.object[[paste(z,sep='')]]$hyperprior,num.sims,replace=T)
     }
     draws=sort(draws)
     draws.psi=append(draws.psi,list(matrix(rep(as.integer(0),num.sims),ncol=1)))
     names(draws.psi)[[length(draws.psi)]]=z
     draws.zeta=append(draws.zeta,list(NULL))
     names(draws.zeta)[[length(draws.zeta)]]=z
     for(y in 1:num.partitions){
      if(max(build.object[[paste(z,sep='')]]$draws[[1]][,1])==0){
       draws.zeta[[paste(z,sep='')]]=append(draws.zeta[[paste(z,sep='')]],list(draws.psi[[paste(z,sep='')]]))
      } else {
       draws.zeta[[paste(z,sep='')]]=append(draws.zeta[[paste(z,sep='')]],list(matrix(rep(as.integer(0),(num.sims*max(build.object[[paste(z,sep='')]]$draws[[1]][,1]))),ncol=max(build.object[[paste(z,sep='')]]$draws[[1]][,1]))))
      }
     }
     draws.pulse.values=append(draws.pulse.values,list(draws.zeta[[paste(z,sep='')]][[1]]))
     names(draws.pulse.values)[[length(draws.pulse.values)]]=z
     for(y in unique(draws)){
      if(build.object[[paste(z,sep='')]]$draws[[1]][y,1]!=0){
       draws.psi[[paste(z,sep='')]][draws==y,]=build.object[[paste(z,sep='')]]$draws[[1]][y,1]
       for(x in 1:num.partitions){
        for(w in 1:build.object[[paste(z,sep='')]]$draws[[x]][y,1]){
         draws.zeta[[paste(z,sep='')]][[x]][draws==y,w]=build.object[[paste(z,sep='')]]$combos[[x]][[build.object[[paste(z,sep='')]]$draws[[x]][y,1]]][build.object[[paste(z,sep='')]]$draws[[x]][y,2],w]
        }
       }
      }
     }
     if(length(sharedprior[[paste(z,sep='')]])==1){
      y=0
      while(y<num.sims&&sign==0){
       y=y+1
       if(draws.psi[[paste(z,sep='')]][y,]!=0){
        temp1=NULL
        temp2=NULL
        x=0
        while(x<draws.psi[[paste(z,sep='')]][y,]&&sign==0){
         x=x+1
         if(length(sharedprior[[paste(z,sep='')]][[1]][!sharedprior[[paste(z,sep='')]][[1]]%in%temp2])==0){
          sign=1
          #explicitly 'buffer' function here because numerical values already checked for earlier
          print(paste("You have specified a '",z,".shared.prior' object that does not allow for any valid draws for a simulation given the corresponding 'psi.prior' and 'shared.prior' distributions and associated 'buffer' function; Multi-DICE cannot continue",sep=''))
         } else {
          if(length(sharedprior[[paste(z,sep='')]][[1]][!sharedprior[[paste(z,sep='')]][[1]]%in%temp2])==1){
           temp1=c(temp1,sharedprior[[paste(z,sep='')]][[1]][!sharedprior[[paste(z,sep='')]][[1]]%in%temp2])
          } else {
           temp1=c(temp1,sample(sharedprior[[paste(z,sep='')]][[1]][!sharedprior[[paste(z,sep='')]][[1]]%in%temp2],1,replace=T))
           if(buff[[paste(z,sep='')]]=='function'){
            temp2=unique(c(temp2,eval(parse(text=paste(z,'.buffer',sep='')))(temp1[x])))
           } else {
            if(substr(z,1,7)=='epsilon'){
             temp2=unique(c(temp2,sharedprior[[paste(z,sep='')]][[1]][sharedprior[[paste(z,sep='')]][[1]]>=(temp1[x]-buff[[paste(z,sep='')]])][sharedprior[[paste(z,sep='')]][[1]][sharedprior[[paste(z,sep='')]][[1]]>=(temp1[x]-buff[[paste(z,sep='')]])]<=(temp1[x]+buff[[paste(z,sep='')]])]))
            } else {
            temp2=unique(c(temp2,(temp1[x]-buff[[paste(z,sep='')]]):(temp1[x]+buff[[paste(z,sep='')]])))
            }
           }
          }
         }
         draws.pulse.values[[paste(z,sep='')]][y,1:draws.psi[[paste(z,sep='')]][y,]]=sort(temp1)
        }
       }
      }
     } else {
      #not buffering out former draws iteratively as done before since the draws are being done explicitly in the order of pulses, and blocking out buffered zones in this order may place a drawing bias; thus, taking the approach of taking random draws until the draws satisfy the requirements, which is less efficient but less biased
      for(y in 1:num.sims){
       if(draws.psi[[length(draws.psi)]][y,]!=0){
        option=0
        while(option==0){
         temp=NULL
         for(x in 1:draws.psi[[paste(z,sep='')]][y,]){
          if(length(sharedprior[[paste(z,sep='')]][[x]])==1){
           temp=c(temp,sharedprior[[paste(z,sep='')]][[x]])
          } else {
           temp=c(temp,sample(sharedprior[[paste(z,sep='')]][[x]],1,replace=T))
          }
         }
         #confirming draws are in chronological/ascending order
         if(sum(sort(temp)==temp)!=length(temp)){
          option=1
         }
         #confirming draws are outside of buffer zone
         if(length(temp)>1&&option==0){
          if(buff[[paste(z,sep='')]]=='function'){
           for(x in 1:(length(temp))){
            if(x>1){
             if(temp[x]%in%eval(parse(text=paste(z,'.buffer',sep='')))(temp1[(x-1)])){
              option=1
             }
            }
            if(x<length(temp)&&option==0){
             if(temp[x]%in%eval(parse(text=paste(z,'.buffer',sep='')))(temp1[(x+1)])){
              option=1
             }
            }
           }
          } else {
           for(x in 2:length(temp)){
            if((temp[x]-temp[(x-1)])<=buff[[paste(z,sep='')]]){
             option=1
            }
           }
          }
         }
         if(option==0){
          option=1
         } else {
          option=0
         }
        }
        draws.pulse.values[[paste(z,sep='')]][y,1:draws.psi[[paste(z,sep='')]][y,]]=temp
       }
      }
     }
    }
   }

   if(sign==0){
    output=list(draws.psi,draws.zeta,draws.pulse.values)
    names(output)=c('draws.psi','draws.zeta','draws.pulse.values')
    return(output)
   }

  }

 }

}



#' @export
play.dice=function(num.sims, num.taxa, num.partitions=1, tau.psi.prior=NULL, epsilon.psi.prior=NULL, NE.psi.prior=NULL, tau.zeta.prior=NULL, tau2.zeta.prior=NULL, epsilon.zeta.prior=NULL, epsilon2.zeta.prior=NULL, NE.zeta.prior=NULL, tau.zeta.total.prior=NULL, tau2.zeta.total.prior=NULL, epsilon.zeta.total.prior=NULL, epsilon2.zeta.total.prior=NULL, NE.zeta.total.prior=NULL, tau.shared.prior=NULL, tau2.shared.prior=NULL, epsilon.shared.prior=NULL, epsilon2.shared.prior=NULL, NE.shared.prior=NULL, tau.idio.prior=NULL, tau2.idio.prior=NULL, epsilon.idio.prior=NULL, epsilon2.idio.prior=NULL, NE.idio.prior=NULL, linked.param=NULL, attached.hyper=NULL, linked.param.partition=NULL, attached.hyper.pulse=NULL, linked.param.prior=NULL, linked.param.fixed=NULL, anchor.prior=NULL, change.prior=NULL, exponential.growth.rate.prior=NULL, exponential.growth.rate.prior2=NULL, dirichlet.process=F, idiosyncratic=T, min.net.tau.zeta.total=NULL, min.net.tau2.zeta.total=NULL, min.net.epsilon.zeta.total=NULL, min.net.epsilon2.zeta.total=NULL, min.net.NE.zeta.total=NULL, max.net.tau.zeta.total=NULL, max.net.tau2.zeta.total=NULL, max.net.epsilon.zeta.total=NULL, max.net.epsilon2.zeta.total=NULL, max.net.NE.zeta.total=NULL, min.net.tau.zeta.per.pulse=NULL, min.net.tau2.zeta.per.pulse=NULL, min.net.epsilon.zeta.per.pulse=NULL, min.net.epsilon2.zeta.per.pulse=NULL, min.net.NE.zeta.per.pulse=NULL, max.net.tau.zeta.per.pulse=NULL, max.net.tau2.zeta.per.pulse=NULL, max.net.epsilon.zeta.per.pulse=NULL, max.net.epsilon2.zeta.per.pulse=NULL, max.net.NE.zeta.per.pulse=NULL, tau.buffer=0, tau2.buffer=0, epsilon.buffer=0, epsilon2.buffer=0, NE.buffer=0, tau.idiosyncratic.buffer=NULL, tau2.idiosyncratic.buffer=NULL, epsilon.idiosyncratic.buffer=NULL, epsilon2.idiosyncratic.buffer=NULL, NE.idiosyncratic.buffer=NULL, idiosyncratic.rule='none', num.changes=1, flip=F, net.zeta.total=F, net.zeta.per.pulse=F, mean.tau.shared=F, mean.tau2.shared=F, mean.epsilon.shared=F, mean.epsilon2.shared=F, mean.NE.shared=F, mean.tau=F, mean.tau2=F, mean.epsilon=F, mean.epsilon2=F, mean.NE=F, disp.index.tau.shared=F, disp.index.tau2.shared=F, disp.index.epsilon.shared=F, disp.index.epsilon2.shared=F, disp.index.NE.shared=F, disp.index.tau=F, disp.index.tau2=F, disp.index.epsilon=F, disp.index.epsilon2=F, disp.index.NE=F, build.object=NULL, roll.object=NULL, num.haploid.samples, num.ind.sites, num.SNPs, length.seq, folded, sampling.times, gen.times, remove.afclasses, convert.sequences, mut.rate.prior, fsc2path, messages.sims, output.directory, input.directory, input.base, input.files, append.sims, keep.taxa.draws, output.hyper.draws, output.taxa.draws, keep.fsc2.files, play.object, skipper=NULL){

 messages=0
 if(is.null(roll.object)){
  roll.object=roll.dice(num.sims=num.sims, num.taxa=num.taxa, num.partitions=num.partitions, tau.psi.prior=tau.psi.prior, epsilon.psi.prior=epsilon.psi.prior, NE.psi.prior=NE.psi.prior, tau.zeta.prior=tau.zeta.prior, tau2.zeta.prior=tau2.zeta.prior, epsilon.zeta.prior=epsilon.zeta.prior, epsilon2.zeta.prior=epsilon2.zeta.prior, NE.zeta.prior=NE.zeta.prior, tau.zeta.total.prior=tau.zeta.total.prior, tau2.zeta.total.prior=tau2.zeta.total.prior, epsilon.zeta.total.prior=epsilon.zeta.total.prior, epsilon2.zeta.total.prior=epsilon2.zeta.total.prior, NE.zeta.total.prior=NE.zeta.total.prior, tau.shared.prior=tau.shared.prior, tau2.shared.prior=tau2.shared.prior, epsilon.shared.prior=epsilon.shared.prior, epsilon2.shared.prior=epsilon2.shared.prior, NE.shared.prior=NE.shared.prior, dirichlet.process=dirichlet.process, idiosyncratic=idiosyncratic, min.net.tau.zeta.total=min.net.tau.zeta.total, min.net.tau2.zeta.total=min.net.tau2.zeta.total, min.net.epsilon.zeta.total=min.net.epsilon.zeta.total, min.net.epsilon2.zeta.total=min.net.epsilon2.zeta.total, min.net.NE.zeta.total=min.net.NE.zeta.total, max.net.tau.zeta.total=max.net.tau.zeta.total, max.net.tau2.zeta.total=max.net.tau2.zeta.total, max.net.epsilon.zeta.total=max.net.epsilon.zeta.total, max.net.epsilon2.zeta.total=max.net.epsilon2.zeta.total, max.net.NE.zeta.total=max.net.NE.zeta.total, min.net.tau.zeta.per.pulse=min.net.tau.zeta.per.pulse, min.net.tau2.zeta.per.pulse=min.net.tau2.zeta.per.pulse, min.net.epsilon.zeta.per.pulse=min.net.epsilon.zeta.per.pulse, min.net.epsilon2.zeta.per.pulse=min.net.epsilon2.zeta.per.pulse, min.net.NE.zeta.per.pulse=min.net.NE.zeta.per.pulse, max.net.tau.zeta.per.pulse=max.net.tau.zeta.per.pulse, max.net.tau2.zeta.per.pulse=max.net.tau2.zeta.per.pulse, max.net.epsilon.zeta.per.pulse=max.net.epsilon.zeta.per.pulse, max.net.epsilon2.zeta.per.pulse=max.net.epsilon2.zeta.per.pulse, max.net.NE.zeta.per.pulse=max.net.NE.zeta.per.pulse, tau.buffer=tau.buffer, tau2.buffer=tau2.buffer, epsilon.buffer=epsilon.buffer, epsilon2.buffer=epsilon2.buffer, NE.buffer=NE.buffer, build.object=build.object)
  messages=1
 }

 if(!is.null(roll.object)){

  numtaxa=dice.read.numtaxa(num.taxa, num.partitions)
  if(-1%in%numtaxa){
   print("You have included a non-positive number in the 'num.taxa' object; Multi-DICE cannot continue")
  }

  psiprior=dice.read.psiprior(tau.psi.prior=tau.psi.prior, epsilon.psi.prior=epsilon.psi.prior, NE.psi.prior=NE.psi.prior)
  if(is.null(psiprior)){
   print("You have not specified a 'psi.prior' object; Multi-DICE cannot continue")
  }
  if('psitest'%in%names(psiprior)){
   print("You have included a negative number in a 'psi.prior' object; Multi-DICE cannot continue")
  }

  numchanges=dice.read.numchanges(num.partitions=num.partitions, num.changes=num.changes)
  if(-1%in%numchanges){
   print("You have included a non-positive number in the 'num.changes' object; Multi-DICE cannot continue")
  }

  halt=0
  twist=0
  plug=0
  if(idiosyncratic==F){
   for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
    if(z%in%names(psiprior)&&twist==0){
     if(0%in%psiprior[[paste(z,sep='')]]){
      twist=1
     }
    }
   }
  }
  #if idiosyncratic=T, then an idiosyncratic prior is needed; if 0 is in a psi prior, then an idiosyncratic prior is needed (this is not redundant with idiosyncratic=T, since it is possible to have idiosyncratic taxa when idiosycratic=F if psi=0); if any of the first event hyperparameters are not being inferred, or if any of the second event hyperparameters are not being inferred and a 2 event model is used for at least one partition, then an idiosyncratic prior is needed for these nuisance parameter draws (for tau2, anchor.prior and change.prior must also both be NOT specified by user)
  if(idiosyncratic==T||twist==1||!'tau'%in%names(psiprior)||!'epsilon'%in%names(psiprior)||!'NE'%in%names(psiprior)||2%in%numchanges[['numchanges']]&&!'tau2'%in%names(psiprior)&&is.null(anchor.prior)&&is.null(change.prior)||2%in%numchanges[['numchanges']]&&!'epsilon2'%in%names(psiprior)){
   plug=1
   idioprior=dice.read.idioprior(num.partitions, psiprior, tau.shared.prior, tau2.shared.prior, epsilon.shared.prior, epsilon2.shared.prior, NE.shared.prior, tau.idio.prior, tau2.idio.prior, epsilon.idio.prior, epsilon2.idio.prior, NE.idio.prior, anchor.prior, change.prior, idiosyncratic, numchanges)
   if('idiotest'%in%names(idioprior)){
    halt=1
    print("You have not specified an idiosyncratic/nuisance prior corresponding to a 'psi.prior' object that you have specified or a nuisance parameter, respectively, which would be contained in the appropriate 'idio.prior' or 'shared.prior' object, or have included a non-positive number in an idiosyncratic prior; Multi-DICE cannot continue")
   }
  }

  #nuisance draws are never buffered, and thus although an idiosyncratic prior is needed for nuisance draws, a buffer is not needed; similarly, if idiosyncratic=F but 0 is in psi prior, buffer is still not needed since there are no shared pulses to buffer from when psi=0
  if(idiosyncratic==T){
   buff=dice.read.buff(psiprior=psiprior, tau.buffer=tau.buffer, tau2.buffer=tau2.buffer, epsilon.buffer=epsilon.buffer, epsilon2.buffer=epsilon2.buffer, NE.buffer=NE.buffer)
   if('bufftest'%in%names(buff)){
    halt=1
    print("You have specified a 'buffer' object as the wrong type (i.e. not a numeric value or function), or have included a negative number in a 'buffer' object; Multi-DICE cannot continue")
   }
  }

  #idiosyncratic buffer can still be employed when idiosyncratic=F if psi prior includes 0
  if(idiosyncratic==T||twist==1){
   twist=0
   if(!is.null(tau.idiosyncratic.buffer)||!is.null(tau2.idiosyncratic.buffer)||!is.null(epsilon.idiosyncratic.buffer)||!is.null(epsilon2.idiosyncratic.buffer)||!is.null(NE.idiosyncratic.buffer)){
    idiobuffer=NULL
    psipriormod=psiprior
    for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
     if(z%in%names(psiprior)){
      #allows user to specify an idiosyncratic buffer for one inferred hyperparameter and not specify for another
      if(is.null(eval(parse(text=paste(z,'.idiosyncratic.buffer',sep=''))))){
       names(psipriormod)[names(psipriormod)==z]=paste('not',z,sep='')
       idiobuffer=append(idiobuffer,list(NULL))
      } else {
       idiobuffer=append(idiobuffer,list(eval(parse(text=paste(z,'.idiosyncratic.buffer',sep='')))))
      }
     } else {
      idiobuffer=append(idiobuffer,list(NULL))
     }
     names(idiobuffer)[length(idiobuffer)]=z
    }
    idiobuff=dice.read.buff(psiprior=psipriormod, tau.buffer=idiobuffer$tau, tau2.buffer=idiobuffer$tau2, epsilon.buffer=idiobuffer$epsilon, epsilon2.buffer=idiobuffer$epsilon2, NE.buffer=idiobuffer$NE)
    if('bufftest'%in%names(idiobuff)){
     halt=1
     print("You have specified an 'idiosyncratic.buffer' object as the wrong type (i.e. not a numeric value or function), or have included a negative number in an 'idiosyncratic.buffer' object; Multi-DICE cannot continue")
    } else {
     twist=1
    }
   }
  }

  if(!'tau'%in%names(psiprior)&&'tau'%in%linked.param||!'epsilon'%in%names(psiprior)&&'epsilon'%in%linked.param||!'NE'%in%names(psiprior)&&'NE'%in%linked.param||2%in%numchanges[['numchanges']]&&!'tau2'%in%names(psiprior)&&is.null(anchor.prior)&&is.null(change.prior)&&'tau2'%in%linked.param||2%in%numchanges[['numchanges']]&&!'epsilon2'%in%names(psiprior)&&'epsilon2'%in%linked.param){
   linking=dice.read.linking(linked.param=linked.param, attached.hyper=attached.hyper, linked.param.partition=linked.param.partition, attached.hyper.pulse=attached.hyper.pulse, linked.param.prior=linked.param.prior, linked.param.fixed=linked.param.fixed)
   if(-1%in%linking){
    halt=1
    print("You have specified the 'linked.param', 'attached.hyper', 'linked.param.partition', 'attached.hyper.pulse', 'linked.param.prior', and 'linked.param.fixed' objects as different lengths (if 'linked.param', 'attached.hyper', or 'linked.param.fixed' is a list object, then total of elements across all list elements are included; if 'linked.param.partition', 'attached.hyper.pulse', 'linked.param.prior', or 'linked.param.fixed' is a non-list vector object, then that object is applied across each parameter-hyperparameter linkage), and/or have included an element that is not a parameter name (i.e. 'tau', 'tau2', 'epsilon', 'epsilon2', 'NE') in the 'linked.param' and/or 'attached.hyper' object(s); Multi-DICE cannot continue")
   }
  } else {
   linking=list(NULL)
  }

  if(2%in%numchanges[['numchanges']]&&!'tau2'%in%names(psiprior)){
   if(is.null(anchor.prior)){
    flipvector=dice.read.flipvector(num.partitions, flip)
   } else {
    anchorprior=dice.read.anchorprior(psipriortau=psiprior$tau, anchor.prior=anchor.prior)
    if('anchortest'%in%names(anchorprior)){
     halt=1
     print("You have included a non-positive number in the 'anchor.prior' object; Multi-DICE cannot continue")
    }
   }
  }

  twister=0
  if(idiosyncratic==T){
   twister=1
  } else {
   if('tau2'%in%names(psiprior)){
    if(0%in%psiprior$tau2){
     twister=1
    }
   }
  }
  if(2%in%numchanges[['numchanges']]&&!'tau2'%in%names(psiprior)&&is.null(anchor.prior)&&!is.null(change.prior)||'tau2'%in%names(psiprior)&&!is.null(change.prior)&&twister==1){
   twister=1
   changeprior=dice.read.changeprior(num.partitions=num.partitions, change.prior=change.prior)
   if('changetest'%in%names(changeprior)){
    halt=1
    print("You have included a non-positive number in the 'change.prior' object; Multi-DICE cannot continue")
   }
  } else {
   twister=0
  }

  if(2%in%numchanges[['numchanges']]&&!'tau2'%in%names(psiprior)&&is.null(anchor.prior)&&is.null(change.prior)&&halt==0){
   z=0
   while(z<num.partitions&&halt==0){
    z=z+1
    if(flipvector[['flipvector']][z]==F&&max(idioprior$tau2[[z]])<=max(sim.specs$tau[,c((sum(numtaxa[['numtaxa']][0:(z-1)])+1):sum(numtaxa[['numtaxa']][1:z]))])||flipvector[['flipvector']][z]==T&&min(idioprior$tau2[[z]])>=min(sim.specs$tau[,c((sum(numtaxa[['numtaxa']][0:(z-1)])+1):sum(numtaxa[['numtaxa']][1:z]))])){
     halt=1
     print("You have specified a 'tau2' nuisance prior, contained in the 'tau2.idio.prior' or 'tau2.shared.prior' object, that entirely overlaps within 'tau' shared pulse draws; Multi-DICE cannot continue")
    }
    if(idiosyncratic==T||0%in%psiprior$tau){
     if(flipvector[['flipvector']][z]==F&&max(idioprior$tau2[[z]])<=max(idioprior$tau[[z]])||flipvector[['flipvector']][z]==T&&min(idioprior$tau2[[z]])>=min(idioprior$tau[[z]])){
      halt=1
      print("You have specified a 'tau2' nuisance prior, contained in the 'tau2.idio.prior' or 'tau2.shared.prior' object, that entirely overlaps within the 'tau.idio.prior' object; Multi-DICE cannot continue")
     }
    }
   }
  }

  #cannot buffer around the beginning and end exponential growth times unless this rate draw is during roll.dice, but it is preferable here since it is a nuisance parameter and thus is more fitting here; additionally, awkward to buffer around the entirety of the growth, especially since its temporal length varies depending on the rate and magnitude; instead, buffering occurs around the beginning time
  if(!is.null(exponential.growth.rate.prior)||!is.null(exponential.growth.rate.prior2)){
   exp.grow=dice.read.exp.grow(num.partitions=num.partitions, exponential.growth.rate.prior=exponential.growth.rate.prior, exponential.growth.rate.prior2=exponential.growth.rate.prior2)
  }

  if(!-1%in%numtaxa&&!is.null(psiprior)&&!'psitest'%in%names(psiprior)&&!-1%in%numchanges&&halt!=1){

   if(is.null(skipper)){
    if(messages==0){
     if(numtaxa[['numtaxacaution']]==1){
      print("Caution: You have specified an inappropriate number of vector elements for the 'num.taxa' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'num.taxa' elements, with x = 'num.partitions', or if not applicable, with the first 'num.taxa' element used for all partitions")
     }
     if(psiprior[['psicaution']]==1){
      print("Caution: You have specified more than the allowable number of distributions for a 'psi.prior' object (1 for Ne and 2 for tau and epsilon); Multi-DICE will continue with only the first 'psi.prior' distributions up to the allowable amount")
     }
    }
    if(numchanges[['numchangescaution']]==1){
     print("Caution: You have specified an inappropriate number of vector elements for the 'num.changes' object, and/or have included an inappropriate number in the 'num.changes' object; this should be of length = 'num.partitions' or 1, and include values of only 1 or 2 (i.e. Multi-DICE currently allows only up to two demographic events per taxon); Multi-DICE will continue with only the first x 'num.changes' elements, with x = 'num.partitions', or if not applicable, with the first 'num.changes' element used for all partitions, as well as any number >2 converted to 2")
    }
    if(plug==1){
     if(idioprior[['idiocaution']]==1){
      print("Caution: You have specified an inappropriate number of idiosyncratic/nuisance prior distributions for a 'psi.prior' object that you have specified or a nuisance parameter, respectively, which would be contained in the appropriate 'idio.prior' or 'shared.prior' object; the number of distributions should be = 'num.partitions' or 1; Multi-DICE will continue with only the first x distributions, with x = 'num.partitions', or if not applicable, with the first distribution used for all partitions")
     }
    }
    if(twist==1){
     if(is.null(idiobuffer)){
      print("Caution: You have not specified an 'idiosyncratic.buffer' that corresponds to a 'psi.prior' object that you have specified; Multi-DICE will continue without an 'idiosyncratic.buffer'")
     }
    }
    if(2%in%numchanges[['numchanges']]&&!'tau2'%in%names(psiprior)){
     if(is.null(anchor.prior)){
      if(flipvector[['flipvectorcaution']]==1){
       print("Caution: You have specified an inappropriate number of vector elements for the 'flip' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'flip' elements, with x = 'num.partitions', or if not applicable, with the first 'flip' element used for all partitions")
      }
     } else {
      if(anchorprior[['anchorcaution']]==1){
       print("Caution: You have specified an inappropriate number of distributions for the 'anchor.prior' object; the number of distributions should be = maximum value in the corresponding 'psi.prior' distribution (may include more for idiosyncratic distributions, equal to num.partitions or 1) or 1; Multi-DICE will continue with only the first x+num.partitions, x+1, or x 'anchor.prior' distributions, with x = maximum value in the corresponding 'psi.prior' distribution, or if not applicable, with the first 'anchor.prior' distribution used for all pulses and idiosyncratic taxa")
      }
     }
    }
    if(twister==1){
     if(changeprior[['changecaution']]==1){
      print("Caution: You have specified an inappropriate number of distributions for the 'change.prior' object; the number of distributions should be = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'change.prior' distributions, with x = 'num.partitions', or if not applicable, with the first 'change.prior' distribution used for all partitions")
     }
    }
    if(!is.null(exponential.growth.rate.prior)||!is.null(exponential.growth.rate.prior2)){
     if(exp.grow[['exp.growcaution']]==1){
      print("Caution: You have specified an inappropriate number of distributions for an 'exponential.growth.rate.prior' object; the number of distributions should be = 'num.partitions' or 1; Multi-DICE will continue with only the first x distributions, with x = 'num.partitions', or if not applicable, with the first distribution used for all partitions")
     }
    }
   }

   sim.specs=NULL

   if('tau2'%in%roll.object$draws.psi){
    if(is.null(build.object)){
     build.object.tau2=build.dice(num.taxa=num.taxa, num.partitions=num.partitions, tau.psi.prior=tau.psi.prior[[2]], epsilon.psi.prior=NULL, NE.psi.prior=NULL, tau.zeta.prior=tau2.zeta.prior, tau2.zeta.prior=NULL, epsilon.zeta.prior=NULL, epsilon2.zeta.prior=NULL, NE.zeta.prior=NULL, tau.zeta.total.prior=tau2.zeta.total.prior, tau2.zeta.total.prior=NULL, epsilon.zeta.total.prior=NULL, epsilon2.zeta.total.prior=NULL, NE.zeta.total.prior=NULL, dirichlet.process=dirichlet.process, idiosyncratic=idiosyncratic, min.net.tau.zeta.total=min.net.tau2.zeta.total, min.net.tau2.zeta.total=NULL, min.net.epsilon.zeta.total=NULL, min.net.epsilon2.zeta.total=NULL, min.net.NE.zeta.total=NULL, max.net.tau.zeta.total=max.net.tau2.zeta.total, max.net.tau2.zeta.total=NULL, max.net.epsilon.zeta.total=NULL, max.net.epsilon2.zeta.total=NULL, max.net.NE.zeta.total=NULL, min.net.tau.zeta.per.pulse=min.net.tau2.zeta.per.pulse, min.net.tau2.zeta.per.pulse=NULL, min.net.epsilon.zeta.per.pulse=NULL, min.net.epsilon2.zeta.per.pulse=NULL, min.net.NE.zeta.per.pulse=NULL, max.net.tau.zeta.per.pulse=max.net.tau2.zeta.per.pulse, max.net.tau2.zeta.per.pulse=NULL, max.net.epsilon.zeta.per.pulse=NULL, max.net.epsilon2.zeta.per.pulse=NULL, max.net.NE.zeta.per.pulse=NULL)
    } else {
     build.object.tau2=build.object
     for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
      if(z%in%names(build.object.tau2)){
       names(build.object.tau2)[names(build.object.tau2)==z]=paste('null',z,sep='')
      }
     }
     names(build.object.tau2)[names(build.object.tau2)=='tau2']='tau'
    }
   }

   #assign shared pulse values to individual taxa; can't assign idiosyncratic draws here since, for a 2-event model with hyperparameters of both times being inferred, the idiosyncratic taxa in the first event need to be unassigned when assigning shared pulse values to individual taxa for the second event (so as not to interfere timing order)
   for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
    #if this parameter will be simulated
    if(substr(z,nchar(z),nchar(z))!='2'||2%in%numchanges[['numchanges']]||'tau2'%in%names(psiprior)||'epsilon2'%in%names(psiprior)){
     sim.specs=append(sim.specs,list(matrix(rep(as.integer(0),(sum(numtaxa[['numtaxa']])*num.sims)),ncol=sum(numtaxa[['numtaxa']]))))
     names(sim.specs)[[length(sim.specs)]]=z
    }
    #if this psi is intended to be inferred
    if(z%in%names(psiprior)){
     #if mean of shared pulse values of this parameter is to be inferred
     if(eval(parse(text=paste('mean.',z,'.shared',sep='')))==T){
      roll.object=append(roll.object,list(matrix(rep(0,num.sims),ncol=1)))
      names(roll.object)[[length(roll.object)]]=paste('mean.',z,'.shared',sep='')
     }
     #if dispersion index of shared pulse values of this parameter is to be inferred
     if(eval(parse(text=paste('disp.index.',z,'.shared',sep='')))==T){
      roll.object=append(roll.object,list(matrix(rep(0,num.sims),ncol=1)))
      names(roll.object)[[length(roll.object)]]=paste('disp.index.',z,'.shared',sep='')
     }
     #if net.zeta.per.pulse is to be inferred
     if(net.zeta.per.pulse==T){
      roll.object=append(roll.object,list(matrix(rep(as.integer(0),(num.sims*ncol(roll.object$draws.zeta[[paste(z,sep='')]][[1]]))),ncol=ncol(roll.object$draws.zeta[[paste(z,'.1',sep='')]][[1]]))))
      names(roll.object)[[length(roll.object)]]=paste('net.zeta.per.pulse.',z,sep='')
     }
     #if net.zeta.total is to be inferred
     if(net.zeta.total==T){
      roll.object=append(roll.object,list(matrix(rep(as.integer(0),num.sims,ncol=1))))
      names(roll.object)[[length(roll.object)]]=paste('net.zeta.total.',z,sep='')
     }
     for(y in 1:num.sims){
      if(roll.object$draws.psi[[paste(z,sep='')]][y,]>0){
       #randomly select taxa assignment
       if(z!='tau2'){
        for(x in 1:num.partitions){
         for(w in 1:roll.object$draws.psi[[paste(z,sep='')]][y,]){
          if(roll.object$draws.zeta[[paste(z,sep='')]][[x]][y,w]>0){
           opentax=which(sim.specs[[paste(z,sep='')]][y,(sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x])]==0)+sum(numtaxa[['numtaxa']][0:(x-1)])
           if(length(opentax)==1){
            sim.specs[[paste(z,sep='')]][y,opentax]=roll.object$draws.pulse.values[[paste(z,sep='')]][y,w]
           } else {
            sim.specs[[paste(z,sep='')]][y,combn(opentax,roll.object$draws.zeta[[paste(z,sep='')]][[x]][y,w])[,sample(1:ncol(combn(opentax,roll.object$draws.zeta[[paste(z,sep='')]][[x]][y,w])),1,replace=T)]]=roll.object$draws.pulse.values[[paste(z,sep='')]][y,w]
           }
          }
         }
        }
       } else {
        detonator=0
        button=0
        #as soon as a partition shows to have no valid tau2 assignments that wouldn't interfere with tau1 draws, draw is invalidated via detonator and loop repeats with a new draw via roll.dice function (hence the button activated after the first pass, thus allowing new draws in every loop after the first has failed); since this is built to re-draw tau2 if incompatible with tau1, there is, so to speak, an unaffected tau1, while tau2 distributions/taxa assignments are influenced by tau1 draws
        while(detonator==0){
         #re-draw if last draw did not allow valid tau1 draws
         if(button==1){
          sim.specs$tau2[y,sim.specs$tau2[y,]!=0]=0
          #treat user specified tau2-related distributions as tau1 distributions for this particular use of the roll.dice function since the function is built so that if tau2-related hyperparameters are to be inferred, then so must too tau1-related hyperparameters, which is not of interest in this case, so just treat tau2 as tau1 since this does not affect the drawing procedure; NULL everything else
          new.draw=roll.dice(num.sims=1, num.taxa=num.taxa, num.partitions=num.partitions, tau.psi.prior=tau.psi.prior[[2]], epsilon.psi.prior=NULL, NE.psi.prior=NULL, tau.zeta.prior=tau2.zeta.prior, tau2.zeta.prior=NULL, epsilon.zeta.prior=NULL, epsilon2.zeta.prior=NULL, NE.zeta.prior=NULL, tau.zeta.total.prior=tau2.zeta.total.prior, tau2.zeta.total.prior=NULL, epsilon.zeta.total.prior=NULL, epsilon2.zeta.total.prior=NULL, NE.zeta.total.prior=NULL, tau.shared.prior=tau2.shared.prior, tau2.shared.prior=NULL, epsilon.shared.prior=NULL, epsilon2.shared.prior=NULL, NE.shared.prior=NULL, dirichlet.process=dirichlet.process, idiosyncratic=idiosyncratic, min.net.tau.zeta.total=min.net.tau2.zeta.total, min.net.tau2.zeta.total=NULL, min.net.epsilon.zeta.total=NULL, min.net.epsilon2.zeta.total=NULL, min.net.NE.zeta.total=NULL, max.net.tau.zeta.total=max.net.tau2.zeta.total, max.net.tau2.zeta.total=NULL, max.net.epsilon.zeta.total=NULL, max.net.epsilon2.zeta.total=NULL, max.net.NE.zeta.total=NULL, min.net.tau.zeta.per.pulse=min.net.tau2.zeta.per.pulse, min.net.tau2.zeta.per.pulse=NULL, min.net.epsilon.zeta.per.pulse=NULL, min.net.epsilon2.zeta.per.pulse=NULL, min.net.NE.zeta.per.pulse=NULL, max.net.tau.zeta.per.pulse=max.net.tau2.zeta.per.pulse, max.net.tau2.zeta.per.pulse=NULL, max.net.epsilon.zeta.per.pulse=NULL, max.net.epsilon2.zeta.per.pulse=NULL, max.net.NE.zeta.per.pulse=NULL, tau.buffer=tau2.buffer, tau2.buffer=NULL, epsilon.buffer=NULL, epsilon2.buffer=NULL, NE.buffer=NULL, build.object=build.object.tau2)
          roll.object$draws.psi$tau2[y,]=new.draw$draws.psi$tau
          for(x in 1:num.partitions){
           roll.object$draws.zeta$tau2[[x]][y,]=new.draw$draws.zeta$tau[[x]]
          }
          roll.object$draws.pulse.values$tau2[y,]=new.draw$draws.pulse.values$tau
         }
         button=1
         #must replicate if statement because of additional loops with redraws that might draw psi=0
         if(roll.object$draws.psi$tau2[y,]>0){
          x=0
          while(x<num.partitions&&detonator==0){
           x=x+1
           if(sum(roll.object$draws.zeta$tau2[[x]][y,])>0){
            #assign the lowest tau2 pulse allowed per taxon based on tau1 assignment (i.e. tau1 must be < tau2; if tau1 is 0 i.e. idiosyncratic, tau2 certainly > tau1)
            ind.allowed=rep((roll.object$draws.psi$tau2[y,]+1),numtaxa[['numtaxa']][x])
            for(w in roll.object$draws.psi$tau2[y,]:1){
             ind.allowed[c(1:numtaxa[['numtaxa']][x])[ind.allowed==(w+1)][sim.specs$tau[y,(which(ind.allowed==(w+1))+sum(numtaxa[['numtaxa']][0:(x-1)]))]<roll.object$draws.pulse.values$tau2[y,w]]]=w
            }
            #all combos of individuals that allow at least one tau2 assignment
            indi.combos=NULL
            for(w in 1:sum(roll.object$draws.zeta$tau2[[x]][y,])){
             indi.combos=append(indi.combos,list(c(1:length(ind.allowed))[ind.allowed<=w]))
            }
            indi.combos=expand.grid(indi.combos)
            #the pulse number of all tau2 pulse assignments to individuals
            pulse.directory=NULL
            for(w in 1:roll.object$draws.psi$tau2[y,]){
             pulse.directory=c(pulse.directory,rep(w,roll.object$draws.zeta$tau2[[x]][y,w]))
            }
            #randomly select tau2 pulse assignments to individuals, determine if valid according to tau1 draws
            while(nrow(indi.combos)>0){
             selected.combos=sample(1:nrow(indi.combos),1,replace=T)
             w=0
             while(w<ncol(indi.combos)){
              w=w+1
              if(pulse.directory[w]<ind.allowed[indi.combos[selected.combos,w]]){
               w=ncol(indi.combos)
               indi.combos=indi.combs[-selected.combos,]
               selected.combos=NULL
              }
             }
             if(!is.null(selected.combos)){
              indi.combos=indi.combos[-c(1:nrow(indi.combos)),]
              for(w in 1:roll.object$draws.psi$tau2[y,]){
               sim.specs$tau2[y,(sum(numtaxa[['numtaxa']][0:(x-1)])+indi.combos[selected.combos,(c(1:roll.object$draws.zeta$tau2[[x]][y,w])+sum(roll.object$draws.zeta$tau2[[x]][y,0:(w-1)]))])]=roll.object$draws.pulse.values$tau2[y,w]
              }
             }
            }
            if(is.null(selected.combos)){
             detonator=1
            }
           }
          }
         }
        }
       }
       if(roll.object[['draws.psi']][[paste(z,sep='')]][y,]>0&&sum(sim.specs[[paste(z,sep='')]][y,]!=0)>0){
        #mean of shared pulse values of this parameter
        if(eval(parse(text=paste('mean.',z,'.shared',sep='')))==T){
         roll.object[[paste('mean.',z,'.shared',sep='')]][y,]=mean(sim.specs[[paste(z,sep='')]][y,][sim.specs[[paste(z,sep='')]][y,]!=0])
        }
        #dispersion index of shared pulse values of this parameter
        if(eval(parse(text=paste('disp.index.',z,'.shared',sep='')))==T&&sum(sim.specs[[paste(z,sep='')]][y,]!=0)>1){
         roll.object[[paste('disp.index.',z,'.shared',sep='')]][y,]=var(sim.specs[[paste(z,sep='')]][y,][sim.specs[[paste(z,sep='')]][y,]!=0])/mean(sim.specs[[paste(z,sep='')]][y,][sim.specs[[paste(z,sep='')]][y,]!=0])
        }
        #net.zeta.per.pulse
        if(net.zeta.per.pulse==T){
         for(x in 1:roll.object$draws.psi[[paste(z,sep='')]][y,]){
          temp=0
          for(w in 1:num.partitions){
           temp=temp+roll.object$draws.zeta[[paste(z,sep='')]][[w]][y,x]
          }
          roll.object[[paste('net.zeta.per.pulse.',z,sep='')]][y,x]=temp
         }
        }
        #if net.zeta.total is to be inferred
        if(net.zeta.total==T){
        temp=0
         for(x in 1:num.partitions){
          temp=temp+sum(roll.object$draws.zeta[[paste(z,sep='')]][[x]][y,])
         }
         roll.object[[paste('net.zeta.total.',z,sep='')]][y,]=temp
        }
       }
      }
     }
    }
   }

   #assign idiosyncratic/nuisance values to individual taxa
   for(z in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
    #if mean of this parameter is to be inferred
    if(eval(parse(text=paste('mean.',z,sep='')))==T&&halt==0){
     roll.object=append(roll.object,list(matrix(rep(0,num.sims),ncol=1)))
     names(roll.object)[[length(roll.object)]]=paste('mean.',z,sep='')
    }
    #if dispersion index of this parameter is to be inferred
    if(eval(parse(text=paste('disp.index.',z,sep='')))==T&&halt==0){
     roll.object=append(roll.object,list(matrix(rep(0,num.sims),ncol=1)))
     names(roll.object)[[length(roll.object)]]=paste('disp.index.',z,sep='')
    }
    if(z%in%names(psiprior)&&halt==0){
     y=0
     while(y<num.sims&&halt==0){
      y=y+1
      #if this simulation has idiosyncratic taxa
      if(sum(sim.specs[[paste(z,sep='')]][y,]==0)>0){
       buffer=NULL
       if(roll.object$draws.psi[[paste(z,sep='')]][y,]>0){
        for(x in 1:roll.object$draws.psi[[paste(z,sep='')]][y,]){
         if(buff[[paste(z,sep='')]]=='function'){
          buffer=unique(c(buffer,eval(parse(text=paste(z,'.buffer',sep='')))(roll.object$draws.pulse.values[[paste(z,sep='')]][y,x])))
         } else {
          if(substr(z,1,7)=='epsilon'){
           for(w in 1:length(idioprior[[paste(z,sep='')]])){
            buffer=unique(c(buffer,idioprior[[paste(z,sep='')]][[w]][idioprior[[paste(z,sep='')]][[w]]>=(roll.object$draws.pulse.values[[paste(z,sep='')]][y,x]-buff[[paste(z,sep='')]])][idioprior[[paste(z,sep='')]][[w]][idioprior[[paste(z,sep='')]][[w]]>=(roll.object$draws.pulse.values[[paste(z,sep='')]][y,x]-buff[[paste(z,sep='')]])]<=(roll.object$draws.pulse.values[[paste(z,sep='')]][y,x]+buff[[paste(z,sep='')]])]))
           }
          } else {
           buffer=unique(c(buffer,(roll.object$draws.pulse.values[[paste(z,sep='')]][y,x]-buff[[paste(z,sep='')]]):(roll.object$draws.pulse.values[[paste(z,sep='')]][y,x]+buff[[paste(z,sep='')]])))
          }
         }
        }
       }
       idio.dist=NULL
       #change.prior outranks idio.prior for tau2
       if(z=='tau2'&&!is.null(change.prior)){
        for(x in 1:length(changeprior[[paste(z,sep='')]])){
         idio.dist=append(idio.dist,list(changeprior[[paste(z,sep='')]][[x]]))
        }
        changebuffer=NULL
       } else {
        for(x in 1:length(idioprior[[paste(z,sep='')]])){
         idio.dist=append(idio.dist,list(idioprior[[paste(z,sep='')]][[x]][!idioprior[[paste(z,sep='')]][[x]]%in%buffer]))
        }
        x=0
        while(x<length(idio.dist)&&halt==0){
         x=x+1
         if(idiosyncratic.rule=='recent'&&roll.object$draws.psi[[paste(z,sep='')]][y,]>0){
          idio.dist[[x]]=idio.dist[[x]][idio.dist[[x]]<roll.dice$draws.pulse.values[[paste(z,sep='')]][y,1]]
         }
         if(idiosyncratic.rule=='ancient'&&roll.object$draws.psi[[paste(z,sep='')]][y,]>0){
          idio.dist[[x]]=idio.dist[[x]][idio.dist[[x]]>roll.dice$draws.pulse.values[[paste(z,sep='')]][y,roll.dice$draws.psi[[paste(z,sep='')]][y,]]]
         }
         if(length(idio.dist[[x]])==0){
          halt=1
          print(paste("You have specified a '",z,"' idiosyncratic prior, contained in the appropriate 'idio.prior' or 'shared.prior' object, that does not allow for any valid draws for a simulation given some combination of the following: number of taxa per partition, corresponding 'psi.prior', 'zeta.prior', and 'shared.prior' distributions, associated 'buffer'/'idiosyncratic.buffer' objects, and 'idiosyncratic'/'idiosyncratic.rule' settings ('tau' and 'tau2' priors may also affect each other); Multi-DICE cannot continue",sep=''))
         }
        }
       }
       passed=0
       if(exists('idiobuff')&&halt==0){
        if(!z%in%names(idiobuff)){
         passed=1
        }
       } else {
        passed=1
       }
       while(sum(sim.specs[[paste(z,sep='')]][y,]==0)>0&&halt==0){
        if(sum(sim.specs[[paste(z,sep='')]][y,]==0)==1){
         idio.ind=which(sim.specs[[paste(z,sep='')]][y,]==0)
        } else {
         idio.ind=sample(which(sim.specs[[paste(z,sep='')]][y,]==0),1,replace=T)
        }
        if(length(idio.dist)==1){
         part.ind=1
        } else {
         buzzer=0
         part.ind=0
         while(part.ind<length(idio.dist)&&buzzer==0){
          part.ind=part.ind+1
          if(idio.ind<=sum(numtaxa[['numtaxa']][1:part.ind])){
           buzzer=1
          }
         }
        }
        idio.ind.dist=idio.dist[[part.ind]]
        #tau is bounded by tau2 shared pulse values
        if(z=='tau'&&'tau2'%in%names(sim.specs)){
         if(sim.specs$tau2[y,idio.ind]!=0){
          idio.ind.dist=idio.ind.dist[idio.ind.dist<sim.specs$tau2[y,idio.ind]]
         }
        }
        #tau2 is bounded by tau
        if(z=='tau2'){
         if(is.null(changeprior)){
          idio.ind.dist=idio.ind.dist[idio.ind.dist>sim.specs$tau[y,idio.ind]]
         } else {
          idio.ind.dist=idio.ind.dist+sim.specs$tau[y,idio.ind]
          idio.ind.dist=idio.ind.dist[!idio.ind.dist%in%buffer]
          if(idiosyncratic.rule=='recent'&&roll.object$draws.psi[[paste(z,sep='')]][y,]>0){
           idio.ind.dist=idio.ind.dist[idio.ind.dist<roll.dice$draws.pulse.values[[paste(z,sep='')]][y,1]]
          }
          if(idiosyncratic.rule=='ancient'&&roll.object$draws.psi[[paste(z,sep='')]][y,]>0){
           idio.ind.dist=idio.ind.dist[idio.ind.dist>roll.dice$draws.pulse.values[[paste(z,sep='')]][y,roll.dice$draws.psi[[paste(z,sep='')]][y,]]]
          }
          if(passed==0){
           idio.ind.dist=idio.ind.dist[!idio.ind.dist%in%changebuffer]
          }
          if(length(idio.ind.dist)==0){
           halt=1
           print("You have specified the 'change.prior' object such that it does not allow for any valid draws for a simulation given some combination of the following: number of taxa per partition, 'psi.prior', 'zeta.prior', and 'shared.prior' distributions for 'tau1' and 'tau2', associated 'buffer'/'idiosyncratic.buffer' objects, and 'idiosyncratic'/'idiosyncratic.rule' settings; Multi-DICE cannot continue")
          }
         }
        }
        if(length(idio.ind.dist)==0&&halt==0){
         halt=1
         print(paste("You have specified a '",z,"' idiosyncratic prior, contained in the appropriate 'idio.prior' or 'shared.prior' object, that does not allow for any valid draws for a simulation given some combination of the following: number of taxa per partition, corresponding 'psi.prior', 'zeta.prior', and 'shared.prior' distributions, associated 'buffer'/'idiosyncratic.buffer' objects, and 'idiosyncratic'/'idiosyncratic.rule' settings ('tau' and 'tau2' priors may also affect each other); Multi-DICE cannot continue",sep=''))
        } else {
         if(length(idio.ind.dist)==1){
          sim.specs[[paste(z,sep='')]][y,idio.ind]=idio.ind.dist[1]
         } else {
          sim.specs[[paste(z,sep='')]][y,idio.ind]=sample(idio.ind.dist,1,replace=T)
         }
         if(passed==0){
          if(idiobuff[[paste(z,sep='')]]!='function'){
           if(z=='tau2'&&!is.null(changeprior)){
            changebuffer=unique(c(changebuffer,c((sim.specs[[paste(z,sep='')]][y,idio.ind]-idiobuff[paste(z,sep='')]):(sim.specs[[paste(z,sep='')]][y,idio.ind]+idiobuff[paste(z,sep='')]))))
           } else {
            if(substr(z,1,7)=='epsilon'){
             for(x in 1:length(idio.dist)){
              idio.dist[[x]]=idio.dist[[x]][idio.dist[[x]]>=(sim.specs[[paste(z,sep='')]][y,idio.ind]-idiobuff[paste(z,sep='')])][idio.dist[[x]][idio.dist[[x]]>=(sim.specs[[paste(z,sep='')]][y,idio.ind]-idiobuff[paste(z,sep='')])]<=(sim.specs[[paste(z,sep='')]][y,idio.ind]+idiobuff[paste(z,sep='')])]
             }
            } else {
             for(x in 1:length(idio.dist)){
              idio.dist[[x]]=idio.dist[[x]][!idio.dist[[x]]%in%c((sim.specs[[paste(z,sep='')]][y,idio.ind]-idiobuff[paste(z,sep='')]):(sim.specs[[paste(z,sep='')]][y,idio.ind]+idiobuff[paste(z,sep='')]))]
             }
            }
           }
          } else {
           if(z=='tau2'&&!is.null(changeprior)){
            changebuffer=unique(c(changebuffer,eval(parse(text=paste(z,'idiosyncratic.buffer',sep='')))(sim.specs[[paste(z,sep='')]][y,idio.ind])))
           } else {
            for(x in 1:length(idio.dist)){
             idio.dist[[x]]=idio.dist[[x]][!idio.dist[[x]]%in%eval(parse(text=paste(z,'idiosyncratic.buffer',sep='')))(sim.specs[[paste(z,sep='')]][y,idio.ind])]
            }
           }
          }
         }
        }
       }
      }
     }

    #if this parameter has nuisance taxa
    } else {
     if(substr(z,nchar(z),nchar(z))!='2'||2%in%numchanges[['numchanges']]){
      if(z!='tau2'){
       for(y in 1:num.sims){
        if(z%in%linking[[1]]){
         for(x in which(linking[[1]]==z)){
          if(linking[[6]][x]==T){
           if(length(linking[[5]][[x]])==1){
            fixed.link=linking[[5]][[x]]
           } else {
            fixed.link=sample(linking[[5]][[x]],1,replace=T)
           }
           for(w in linking[[3]][[x]]){
            if(roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]%in%sim.specs[[linking[[2]][x]]][y,c((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]){
             sim.specs[[paste(z,sep='')]][y,(sum(numtaxa[['numtaxa']][0:(w-1)])+which(sim.specs[[linking[[2]][x]]][y,c((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]%in%roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]))]=fixed.link
            }
           }
          } else {
           for(w in linking[[3]][[x]]){
            if(roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]%in%sim.specs[[linking[[2]][x]]][y,c((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]){
             if(length(linking[[5]][[x]])==1){
              sim.specs[[paste(z,sep='')]][y,(sum(numtaxa[['numtaxa']][0:(w-1)])+which(sim.specs[[linking[[2]][x]]][y,c((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]%in%roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]))]=linking[[5]][[x]]
             } else {
              sim.specs[[paste(z,sep='')]][y,(sum(numtaxa[['numtaxa']][0:(w-1)])+which(sim.specs[[linking[[2]][x]]][y,c((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]%in%roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]))]=sample(linking[[5]][[x]],sum(sim.specs[[linking[[2]][x]]][y,c((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]%in%roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]),replace=T)
             }
            }
           }
          }
         }
        }
        for(x in 1:num.partitions){
         if(substr(z,nchar(z),nchar(z))!='2'||numchanges[['numchanges']][x]==2){
          if(sum(sim.specs[[paste(z,sep='')]][y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]==0)>0){
           if(length(idioprior[[paste(z,sep='')]])==1){
            if(length(idioprior[[paste(z,sep='')]][[1]])==1){
             sim.specs[[paste(z,sep='')]][y,(sum(numtaxa[['numtaxa']][0:(x-1)])+which(sim.specs[[paste(z,sep='')]][y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]==0))]=idioprior[[paste(z,sep='')]][[1]]
            } else {
             sim.specs[[paste(z,sep='')]][y,(sum(numtaxa[['numtaxa']][0:(x-1)])+which(sim.specs[[paste(z,sep='')]][y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]==0))]=sample(idioprior[[paste(z,sep='')]][[1]],sum(sim.specs[[paste(z,sep='')]][y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]==0),replace=T)
            }
           } else {
            if(length(idioprior[[paste(z,sep='')]][[x]])==1){
             sim.specs[[paste(z,sep='')]][y,(sum(numtaxa[['numtaxa']][0:(x-1)])+which(sim.specs[[paste(z,sep='')]][y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]==0))]=idioprior[[paste(z,sep='')]][[x]]
            } else {
             sim.specs[[paste(z,sep='')]][y,(sum(numtaxa[['numtaxa']][0:(x-1)])+which(sim.specs[[paste(z,sep='')]][y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]==0))]=sample(idioprior[[paste(z,sep='')]][[x]],sum(sim.specs[[paste(z,sep='')]][y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]==0),replace=T)
            }
           }
          }
         }
        }
       }
      } else {
       #cannot flip anchor because the anchor makes the timing of both events a function of each other, thus flipping would have no effect; should use change if user wants to flip some partitions and not others
       if(!is.null(anchor.prior)){
        roll.object=append(roll.object,list(matrix(rep(0,(num.sims*max(psiprior$tau))),ncol=max(psiprior$tau))))
        names(roll.object)[[length(roll.object)]]='draws.anchors'
        for(y in 1:num.sims){
         for(x in 1:max(psiprior$tau)){
          if(length(anchorprior[['anchorprior']][[x]])==1){
           roll.object$draws.anchors[y,x]=anchorprior[['anchorprior']][[x]]
          } else {
           roll.object$draws.anchors[y,x]=sample(anchorprior[['anchorprior']][[x]],1,replace=T)
          }
          sim.specs$tau2[y,c(1:sum(numtaxa[['numtaxa']]))[sim.specs$tau[y,]==roll.object$draws.pulse.values$tau[y,x]]]=as.integer(roll.object$draws.pulse.values$tau[y,x]+roll.object$draws.anchors[y,x])
         }
         for(x in 1:num.partitions){
          if(sum(sim.specs$tau2[y,((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][1:x]))]==0)){
           if(length(anchorprior[['anchorprior']][[(max(psiprior$tau)+x)]])==1){
            sim.specs$tau2[y,(sum(numtaxa[['numtaxa']][0:(x-1)])+which(sim.specs$tau2[y,((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][1:x]))]==0))]=as.integer(sim.specs$tau[y,(sum(numtaxa[['numtaxa']][0:(x-1)])+which(sim.specs$tau2[y,((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][1:x]))]==0))]+anchorprior[['anchorprior']][[(max(psiprior$tau)+x)]])
           } else {
            sim.specs$tau2[y,(sum(numtaxa[['numtaxa']][0:(x-1)])+which(sim.specs$tau2[y,((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][1:x]))]==0))]=as.integer(sim.specs$tau[y,(sum(numtaxa[['numtaxa']][0:(x-1)])+which(sim.specs$tau2[y,((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][1:x]))]==0))]+sample(anchorprior[['anchorprior']][[(max(psiprior$tau)+x)]],sum(sim.specs$tau2[y,((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][1:x]))]==0),replace=T))
           }
          }
         }
        }
       } else {
        if(!is.null(change.prior)){
         for(y in 1:num.sims){
          for(x in 1:num.partitions){
           if(numchanges[['numchanges']][x]==2){
            if(flipvector[['flipvector']][x]==F){
             if(length(changeprior[['changeprior']][[x]])==1){
              sim.specs$tau2[y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]=as.integer(sim.specs$tau[y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]+changeprior[['changeprior']][[x]])
             } else {
              sim.specs$tau2[y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]=as.integer(sim.specs$tau[y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]+sample(changeprior[['changeprior']][[x]],numtaxa[['numtaxa']][x],replace=T))
             }
            } else {
             if(length(changeprior[['changeprior']][[x]])==1){
              sim.specs$tau2[y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]=as.integer(sim.specs$tau[y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]-changeprior[['changeprior']][[x]])
             } else {
              sim.specs$tau2[y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]=as.integer(sim.specs$tau[y,c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))]-sample(changeprior[['changeprior']][[x]],numtaxa[['numtaxa']][x],replace=T))
             }
            }
           }
          }
         }
        } else {
         for(y in 1:num.sims){
          if(z%in%linking[[1]]){
           for(x in which(linking[[1]]==z)){
            if(linking[[6]][x]==T){
             fixed.link.limit=NULL
             for(w in linking[[3]][[x]]){
              if(is.null(fixed.link)||max(sim.specs$tau[y,(sum(numtaxa[['numtaxa']][0:(w-1)])+which(sim.specs[[linking[[2]][x]]][y,((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]%in%roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]))])>fixed.link.limit&&flipvector[['flipvector']][linking[[3]][[x]][1]]==F||min(sim.specs$tau[y,(sum(numtaxa[['numtaxa']][0:(w-1)])+which(sim.specs[[linking[[2]][x]]][y,((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]%in%roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]))])<fixed.link.limit&&flipvector[['flipvector']][linking[[3]][[x]][1]]==T){
               if(flipvector[['flipvector']][linking[[3]][[x]][1]]==F){
                fixed.link.limit=max(sim.specs$tau[y,(sum(numtaxa[['numtaxa']][0:(w-1)])+which(sim.specs[[linking[[2]][x]]][y,((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]==roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]))])
               } else {
                fixed.link.limit=min(sim.specs$tau[y,(sum(numtaxa[['numtaxa']][0:(w-1)])+which(sim.specs[[linking[[2]][x]]][y,((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]==roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]))])
               }
              }
             }
             if(flipvector[['flipvector']][linking[[3]][[x]][1]]==F&&sum(linking[[5]][[x]]>fixed.link.limit)==1||flipvector[['flipvector']][linking[[3]][[x]][1]]==T&&sum(linking[[5]][[x]]<fixed.link.limit)==1){
              if(flipvector[['flipvector']][linking[[3]][[x]][1]]==F){
               fixed.link=linking[[5]][[x]][linking[[5]][[x]]>fixed.link.limit]
              } else {
               fixed.link=linking[[5]][[x]][linking[[5]][[x]]<fixed.link.limit]
              }
             } else {
              if(flipvector[['flipvector']][linking[[3]][[x]][1]]==F){
               fixed.link=sample(linking[[5]][[x]][linking[[5]][[x]]>fixed.link.limit],1,replace=T)
              } else {
               fixed.link=sample(linking[[5]][[x]][linking[[5]][[x]]<fixed.link.limit],1,replace=T)
              }
             }
             for(w in linking[[3]][[x]]){
              if(roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]%in%sim.specs[[linking[[2]][x]]][y,c((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]){
               sim.specs$tau2[y,(sum(numtaxa[['numtaxa']][0:(w-1)])+which(sim.specs[[linking[[2]][x]]][y,c((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))]%in%roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]))]=fixed.link
              }
             }
            } else {
             for(w in linking[[3]][[x]]){
              for(v in c((sum(numtaxa[['numtaxa']][0:(w-1)])+1):sum(numtaxa[['numtaxa']][1:w]))){
               if(sim.specs[[linking[[2]][x]]][y,v]%in%roll.object$draws.pulse.values[[linking[[2]][x]]][y,linking[[4]][[x]]]){
                if(flipvector[['flipvector']][w]==F&&sum(linking[[5]][[x]]>sims.specs$tau[y,v])==1||flipvector[['flipvector']][w]==T&&sum(linking[[5]][[x]]<sims.specs$tau[y,v])==1){
                 if(flipvector[['flipvector']][w]==F){
                  sim.specs$tau2[y,v]=linking[[5]][[x]][linking[[5]][[x]]>sim.specs$tau[y,v]]
                 } else {
                  sim.specs$tau2[y,v]=linking[[5]][[x]][linking[[5]][[x]]<sim.specs$tau[y,v]]
                 }
                } else {
                 if(flipvector[['flipvector']][w]==F){
                  sim.specs$tau2[y,v]=sample(linking[[5]][[x]][linking[[5]][[x]]>sim.specs$tau[y,v]],1,replace=T)
                 } else {
                  sim.specs$tau2[y,v]=sample(linking[[5]][[x]][linking[[5]][[x]]<sim.specs$tau[y,v]],1,replace=T)
                 }
                }
               }
              }
             }
            }
           }
          }
          for(x in 1:num.partitions){
           if(numchanges[['numchanges']][x]==2){
            for(w in c((sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x]))){
             if(sim.specs$tau2[y,w]==0){
              if(length(idioprior$tau2)==1){
               idiopriortemp=idioprior$tau2[[1]]
              } else {
               idiopriortemp=idioprior$tau2[[x]]
              }
              if(flipvector[['flipvector']][x]==F&&sum(idiopriortemp>sim.specs$tau[y,w])==1||flipvector[['flipvector']][x]==T&&sum(idiopriortemp<sim.specs$tau[y,w])==1){
               if(flipvector[['flipvector']][x]==F){
                sim.specs$tau2[y,w]=idiopriortemp[idiopriortemp>sim.specs$tau[y,w]]
               } else {
                sim.specs$tau2[y,w]=idiopriortemp[idiopriortemp<sim.specs$tau[y,w]]
               }
              } else {
               if(flipvector[['flipvector']][x]==F){
                sim.specs$tau2[y,w]=sample(idiopriortemp[idiopriortemp>sim.specs$tau[y,w]],1,replace=T)
               } else {
                sim.specs$tau2[y,w]=sample(idiopriortemp[idiopriortemp<sim.specs$tau[y,w]],1,replace=T)
               }
              }
             }
            }
           }
          }
         }
        }
       }
      }
     }
    }
    #mean of this parameter
    if(eval(parse(text=paste('mean.',z,sep='')))==T&&halt==0){
     for(y in 1:num.sims){
      roll.object[[paste('mean.',z,sep='')]][y,]=mean(sim.specs[[paste(z,sep='')]][y,])
     }
    }
    #dispersion index of this parameter
    if(eval(parse(text=paste('disp.index.',z,sep='')))==T&&sum(numtaxa[['numtaxa']])>1&&halt==0){
     for(y in 1:num.sims){
      roll.object[[paste('disp.index.',z,sep='')]][y,]=var(sim.specs[[paste(z,sep='')]][y,])/mean(sim.specs[[paste(z,sep='')]][y,])
      if(is.na(roll.object[[paste('disp.index.',z,sep='')]][y,])){
       roll.object[[paste('disp.index.',z,sep='')]][y,]=0
      }
     }
    }
   }

   if(!is.null(exponential.growth.rate.prior)&&halt==0||!is.null(exponential.growth.rate.prior2)&&halt==0){
    for(z in c('exponential.growth.rate.prior','exponential.growth.rate.prior2')){
     if(z%in%names(exp.grow)){
      sim.specs=append(sim.specs,list(matrix(rep(0,(sum(numtaxa[['numtaxa']])*num.sims)),ncol=sum(numtaxa[['numtaxa']]))))
      names(sim.specs)[[length(sim.specs)]]=z
      for(y in 1:num.sims){
       for(x in 1:num.partitions){
        if(z=='exponential.growth.rate.prior'||numchanges[['numchanges']][x]==2){
         if(length(exp.grow[[paste(z,sep='')]][[x]])==1){
          sim.specs[[length(sim.specs)]][y,(sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x])]=rep(exp.grow[[paste(z,sep='')]][[x]],numtaxa[['numtaxa']][x])
         } else {
          sim.specs[[length(sim.specs)]][y,(sum(numtaxa[['numtaxa']][0:(x-1)])+1):sum(numtaxa[['numtaxa']][0:x])]=sample(exp.grow[[paste(z,sep='')]][[x]],numtaxa[['numtaxa']][x],replace=T)
         }
        }
       }
      }
     }
    }
   }

   if(halt==0){
    output=list(roll.object,sim.specs)
    for(z in names(output[['roll.object']][['draws.zeta']])){
     output[['roll.object']][['draws.zeta']][[paste(z,sep='')]]=output[['roll.object']][['draws.zeta']][[paste(z,sep='')]]/sum(numtaxa[['numtaxa']])
    }
    names(output)=c('roll.object','sim.specs')
    return(output)
   }

  }

 }

}



#' @export
dice.sims=function(num.sims, num.taxa, num.partitions=1, num.haploid.samples, num.ind.sites=NULL, num.SNPs=NULL, length.seq=NULL, folded=T, sampling.times=NULL, gen.times=NULL, tau.psi.prior=NULL, epsilon.psi.prior=NULL, NE.psi.prior=NULL, tau.zeta.prior=NULL, tau2.zeta.prior=NULL, epsilon.zeta.prior=NULL, epsilon2.zeta.prior=NULL, NE.zeta.prior=NULL, tau.zeta.total.prior=NULL, tau2.zeta.total.prior=NULL, epsilon.zeta.total.prior=NULL, epsilon2.zeta.total.prior=NULL, NE.zeta.total.prior=NULL, tau.shared.prior=NULL, tau2.shared.prior=NULL, epsilon.shared.prior=NULL, epsilon2.shared.prior=NULL, NE.shared.prior=NULL, tau.idio.prior=NULL, tau2.idio.prior=NULL, epsilon.idio.prior=NULL, epsilon2.idio.prior=NULL, NE.idio.prior=NULL, linked.param=NULL, attached.hyper=NULL, linked.param.partition=NULL, attached.hyper.pulse=NULL, linked.param.prior=NULL, linked.param.fixed=NULL, anchor.prior=NULL, change.prior=NULL, exponential.growth.rate.prior=NULL, exponential.growth.rate.prior2=NULL, mut.rate.prior=NULL, dirichlet.process=F, idiosyncratic=T, min.net.tau.zeta.total=NULL, min.net.tau2.zeta.total=NULL, min.net.epsilon.zeta.total=NULL, min.net.epsilon2.zeta.total=NULL, min.net.NE.zeta.total=NULL, max.net.tau.zeta.total=NULL, max.net.tau2.zeta.total=NULL, max.net.epsilon.zeta.total=NULL, max.net.epsilon2.zeta.total=NULL, max.net.NE.zeta.total=NULL, min.net.tau.zeta.per.pulse=NULL, min.net.tau2.zeta.per.pulse=NULL, min.net.epsilon.zeta.per.pulse=NULL, min.net.epsilon2.zeta.per.pulse=NULL, min.net.NE.zeta.per.pulse=NULL, max.net.tau.zeta.per.pulse=NULL, max.net.tau2.zeta.per.pulse=NULL, max.net.epsilon.zeta.per.pulse=NULL, max.net.epsilon2.zeta.per.pulse=NULL, max.net.NE.zeta.per.pulse=NULL, tau.buffer=0, tau2.buffer=0, epsilon.buffer=0, epsilon2.buffer=0, NE.buffer=0, tau.idiosyncratic.buffer=NULL, tau2.idiosyncratic.buffer=NULL, epsilon.idiosyncratic.buffer=NULL, epsilon2.idiosyncratic.buffer=NULL, NE.idiosyncratic.buffer=NULL, idiosyncratic.rule='none', num.changes=1, flip=F, net.zeta.total=F, net.zeta.per.pulse=F, mean.tau.shared=F, mean.tau2.shared=F, mean.epsilon.shared=F, mean.epsilon2.shared=F, mean.NE.shared=F, mean.tau=F, mean.tau2=F, mean.epsilon=F, mean.epsilon2=F, mean.NE=F, disp.index.tau.shared=F, disp.index.tau2.shared=F, disp.index.epsilon.shared=F, disp.index.epsilon2.shared=F, disp.index.NE.shared=F, disp.index.tau=F, disp.index.tau2=F, disp.index.epsilon=F, disp.index.epsilon2=F, disp.index.NE=F, fsc2path, messages.sims=NULL, output.directory, append.sims=F, keep.taxa.draws=F, output.hyper.draws=T, output.taxa.draws=F, keep.fsc2.files=F, build.object=NULL, roll.object=NULL, play.object=NULL, remove.afclasses, convert.sequences, input.directory, input.base, input.files){

 messages1=0
 if(is.null(roll.object)&&is.null(play.object)){
  roll.object=roll.dice(num.sims=num.sims, num.taxa=num.taxa, num.partitions=num.partitions, tau.psi.prior=tau.psi.prior, epsilon.psi.prior=epsilon.psi.prior, NE.psi.prior=NE.psi.prior, tau.zeta.prior=tau.zeta.prior, tau2.zeta.prior=tau2.zeta.prior, epsilon.zeta.prior=epsilon.zeta.prior, epsilon2.zeta.prior=epsilon2.zeta.prior, NE.zeta.prior=NE.zeta.prior, tau.zeta.total.prior=tau.zeta.total.prior, tau2.zeta.total.prior=tau2.zeta.total.prior, epsilon.zeta.total.prior=epsilon.zeta.total.prior, epsilon2.zeta.total.prior=epsilon2.zeta.total.prior, NE.zeta.total.prior=NE.zeta.total.prior, tau.shared.prior=tau.shared.prior, tau2.shared.prior=tau2.shared.prior, epsilon.shared.prior=epsilon.shared.prior, epsilon2.shared.prior=epsilon2.shared.prior, NE.shared.prior=NE.shared.prior, dirichlet.process=dirichlet.process, idiosyncratic=idiosyncratic, min.net.tau.zeta.total=min.net.tau.zeta.total, min.net.tau2.zeta.total=min.net.tau2.zeta.total, min.net.epsilon.zeta.total=min.net.epsilon.zeta.total, min.net.epsilon2.zeta.total=min.net.epsilon2.zeta.total, min.net.NE.zeta.total=min.net.NE.zeta.total, max.net.tau.zeta.total=max.net.tau.zeta.total, max.net.tau2.zeta.total=max.net.tau2.zeta.total, max.net.epsilon.zeta.total=max.net.epsilon.zeta.total, max.net.epsilon2.zeta.total=max.net.epsilon2.zeta.total, max.net.NE.zeta.total=max.net.NE.zeta.total, min.net.tau.zeta.per.pulse=min.net.tau.zeta.per.pulse, min.net.tau2.zeta.per.pulse=min.net.tau2.zeta.per.pulse, min.net.epsilon.zeta.per.pulse=min.net.epsilon.zeta.per.pulse, min.net.epsilon2.zeta.per.pulse=min.net.epsilon2.zeta.per.pulse, min.net.NE.zeta.per.pulse=min.net.NE.zeta.per.pulse, max.net.tau.zeta.per.pulse=max.net.tau.zeta.per.pulse, max.net.tau2.zeta.per.pulse=max.net.tau2.zeta.per.pulse, max.net.epsilon.zeta.per.pulse=max.net.epsilon.zeta.per.pulse, max.net.epsilon2.zeta.per.pulse=max.net.epsilon2.zeta.per.pulse, max.net.NE.zeta.per.pulse=max.net.NE.zeta.per.pulse, tau.buffer=tau.buffer, tau2.buffer=tau2.buffer, epsilon.buffer=epsilon.buffer, epsilon2.buffer=epsilon2.buffer, NE.buffer=NE.buffer, build.object=build.object)
  messages1=1
 }

 messages2=0
 if(!is.null(roll.object)&&is.null(play.object)){
  if(keep.taxa.draws==T){
   play.object=play.dice(num.sims=num.sims, num.taxa=num.taxa, num.partitions=num.partitions, tau.psi.prior=tau.psi.prior, epsilon.psi.prior=epsilon.psi.prior, NE.psi.prior=NE.psi.prior, tau.zeta.prior=tau.zeta.prior, tau2.zeta.prior=tau2.zeta.prior, epsilon.zeta.prior=epsilon.zeta.prior, epsilon2.zeta.prior=epsilon2.zeta.prior, NE.zeta.prior=NE.zeta.prior, tau.zeta.total.prior=tau.zeta.total.prior, tau2.zeta.total.prior=tau2.zeta.total.prior, epsilon.zeta.total.prior=epsilon.zeta.total.prior, epsilon2.zeta.total.prior=epsilon2.zeta.total.prior, NE.zeta.total.prior=NE.zeta.total.prior, tau.shared.prior=tau.shared.prior, tau2.shared.prior=tau2.shared.prior, epsilon.shared.prior=epsilon.shared.prior, epsilon2.shared.prior=epsilon2.shared.prior, NE.shared.prior=NE.shared.prior, tau.idio.prior=tau.idio.prior, tau2.idio.prior=tau2.idio.prior, epsilon.idio.prior=epsilon.idio.prior, epsilon2.idio.prior=epsilon2.idio.prior, NE.idio.prior=NE.idio.prior, linked.param=linked.param, attached.hyper=attached.hyper, linked.param.partition=linked.param.partition, attached.hyper.pulse=attached.hyper.pulse, linked.param.prior=linked.param.prior, linked.param.fixed=linked.param.fixed, anchor.prior=anchor.prior, change.prior=change.prior, exponential.growth.rate.prior=exponential.growth.rate.prior, exponential.growth.rate.prior2=exponential.growth.rate.prior2, dirichlet.process=dirichlet.process, idiosyncratic=idiosyncratic, min.net.tau.zeta.total=min.net.tau.zeta.total, min.net.tau2.zeta.total=min.net.tau2.zeta.total, min.net.epsilon.zeta.total=min.net.epsilon.zeta.total, min.net.epsilon2.zeta.total=min.net.epsilon2.zeta.total, min.net.NE.zeta.total=min.net.NE.zeta.total, max.net.tau.zeta.total=max.net.tau.zeta.total, max.net.tau2.zeta.total=max.net.tau2.zeta.total, max.net.epsilon.zeta.total=max.net.epsilon.zeta.total, max.net.epsilon2.zeta.total=max.net.epsilon2.zeta.total, max.net.NE.zeta.total=max.net.NE.zeta.total, min.net.tau.zeta.per.pulse=min.net.tau.zeta.per.pulse, min.net.tau2.zeta.per.pulse=min.net.tau2.zeta.per.pulse, min.net.epsilon.zeta.per.pulse=min.net.epsilon.zeta.per.pulse, min.net.epsilon2.zeta.per.pulse=min.net.epsilon2.zeta.per.pulse, min.net.NE.zeta.per.pulse=min.net.NE.zeta.per.pulse, max.net.tau.zeta.per.pulse=max.net.tau.zeta.per.pulse, max.net.tau2.zeta.per.pulse=max.net.tau2.zeta.per.pulse, max.net.epsilon.zeta.per.pulse=max.net.epsilon.zeta.per.pulse, max.net.epsilon2.zeta.per.pulse=max.net.epsilon2.zeta.per.pulse, max.net.NE.zeta.per.pulse=max.net.NE.zeta.per.pulse, tau.buffer=tau.buffer, tau2.buffer=tau2.buffer, epsilon.buffer=epsilon.buffer, epsilon2.buffer=epsilon2.buffer, NE.buffer=NE.buffer, tau.idiosyncratic.buffer=tau.idiosyncratic.buffer, tau2.idiosyncratic.buffer=tau2.idiosyncratic.buffer, epsilon.idiosyncratic.buffer=epsilon.idiosyncratic.buffer, epsilon2.idiosyncratic.buffer=epsilon2.idiosyncratic.buffer, NE.idiosyncratic.buffer=NE.idiosyncratic.buffer, idiosyncratic.rule=idiosyncratic.rule, num.changes=num.changes, flip=flip, net.zeta.total=net.zeta.total, net.zeta.per.pulse=net.zeta.per.pulse, mean.tau.shared=mean.tau.shared, mean.tau2.shared=mean.tau2.shared, mean.epsilon.shared=mean.epsilon.shared, mean.epsilon2.shared=mean.epsilon2.shared, mean.NE.shared=mean.NE.shared, mean.tau=mean.tau, mean.tau2=mean.tau2, mean.epsilon=mean.epsilon, mean.epsilon2=mean.epsilon2, mean.NE=mean.NE, disp.index.tau.shared=disp.index.tau.shared, disp.index.tau2.shared=disp.index.tau2.shared, disp.index.epsilon.shared=disp.index.epsilon.shared, disp.index.epsilon2.shared=disp.index.epsilon2.shared, disp.index.NE.shared=disp.index.NE.shared, disp.index.tau=disp.index.tau, disp.index.tau2=disp.index.tau2, disp.index.epsilon=disp.index.epsilon, disp.index.epsilon2=disp.index.epsilon2, disp.index.NE=disp.index.NE, build.object=build.object, roll.object=roll.object)
  } else {
   play.object='no.taxa.draws'
   names(play.object)='no.taxa.draws'
  }
  messages2=1
 }

 if(fsc2path=='example'){
  play.object=NULL
  print('By specifying the fsc2path argument as "example", a pre-simulated reference table following the first example command in the R documentation for dice.sims is being returned; returned value is a list, with the first 10 elements representing the per-taxon SFS simulations, the next element representing the according zeta draws, and the last element representing the according tau_s draws')
  return(list(rbind(c(0,0.387088,0.22185,0.17306,0.146998,0.0710035,0,0,0,0,0),c(0,0.391151,0.224297,0.169615,0.145453,0.0694835,0,0,0,0,0),c(0,0.401791,0.214463,0.168833,0.146216,0.068697,0,0,0,0,0),c(0,0.395263,0.214036,0.17249,0.148536,0.069675,0,0,0,0,0),c(0,0.392762,0.21822,0.171901,0.146043,0.0710742,0,0,0,0,0)),rbind(c(0,0.395983,0.217625,0.169046,0.146223,0.0711243,0,0,0,0,0),c(0,0.387133,0.227377,0.171225,0.139889,0.0743764,0,0,0,0,0),c(0,0.387936,0.231562,0.166242,0.14322,0.0710389,0,0,0,0,0),c(0,0.393435,0.218551,0.161469,0.149926,0.076618,0,0,0,0,0),c(0,0.390908,0.22703,0.173275,0.143271,0.0655156,0,0,0,0,0)),rbind(c(0,0.395849,0.218707,0.165218,0.146448,0.0737784,0,0,0,0,0),c(0,0.391106,0.216798,0.173436,0.148344,0.0703172,0,0,0,0,0),c(0,0.401645,0.222153,0.165167,0.145669,0.0653654,0,0,0,0,0),c(0,0.393179,0.221146,0.165576,0.147141,0.0729595,0,0,0,0,0),c(0,0.390238,0.228998,0.170885,0.138813,0.0710654,0,0,0,0,0)),rbind(c(0,0.391211,0.224372,0.1641,0.148047,0.0722702,0,0,0,0,0),c(0,0.387114,0.220998,0.178433,0.145015,0.0684407,0,0,0,0,0),c(0,0.392003,0.213711,0.172193,0.150468,0.0716251,0,0,0,0,0),c(0,0.391655,0.227274,0.161867,0.148519,0.0706854,0,0,0,0,0),c(0,0.388974,0.225772,0.166,0.152212,0.0670415,0,0,0,0,0)),rbind(c(0,0.384862,0.225068,0.169596,0.15079,0.0696838,0,0,0,0,0),c(0,0.399795,0.213909,0.169748,0.14748,0.0690682,0,0,0,0,0),c(0,0.398802,0.214334,0.167993,0.148512,0.0703584,0,0,0,0,0),c(0,0.393831,0.21729,0.165286,0.146174,0.0774193,0,0,0,0,0),c(0,0.398191,0.222219,0.167697,0.146792,0.0651003,0,0,0,0,0)),rbind(c(0,0.401531,0.217978,0.166686,0.145679,0.0681255,0,0,0,0,0),c(0,0.39393,0.214222,0.17315,0.141184,0.0775135,0,0,0,0,0),c(0,0.396005,0.221271,0.170624,0.148517,0.0635833,0,0,0,0,0),c(0,0.390534,0.222809,0.162841,0.154313,0.0695041,0,0,0,0,0),c(0,0.395174,0.217277,0.166734,0.1494,0.0714159,0,0,0,0,0)),rbind(c(0,0.392573,0.218483,0.167381,0.151072,0.070491,0,0,0,0,0),c(0,0.387027,0.213658,0.174193,0.150174,0.0749478,0,0,0,0,0),c(0,0.391006,0.223556,0.165893,0.151186,0.0683583,0,0,0,0,0),c(0,0.388328,0.228622,0.169245,0.142953,0.0708533,0,0,0,0,0),c(0,0.396815,0.216676,0.171466,0.143692,0.0713511,0,0,0,0,0)),rbind(c(0,0.393907,0.217571,0.178188,0.144374,0.0659604,0,0,0,0,0),c(0,0.389795,0.226235,0.168531,0.14303,0.0724086,0,0,0,0,0),c(0,0.388437,0.222392,0.16859,0.146675,0.073905,0,0,0,0,0),c(0,0.40185,0.214095,0.165966,0.146864,0.0712244,0,0,0,0,0),c(0,0.398091,0.21549,0.167314,0.147121,0.0719844,0,0,0,0,0)),rbind(c(0,0.39479,0.219605,0.164867,0.150573,0.070164,0,0,0,0,0),c(0,0.394062,0.220992,0.169473,0.147987,0.0674863,0,0,0,0,0),c(0,0.390357,0.219503,0.174343,0.149622,0.0661755,0,0,0,0,0),c(0,0.394316,0.22051,0.159554,0.151229,0.0743911,0,0,0,0,0),c(0,0.398253,0.220454,0.164777,0.147624,0.0688914,0,0,0,0,0)),rbind(c(0,0.398062,0.222556,0.167012,0.138076,0.0742939,0,0,0,0,0),c(0,0.394081,0.216813,0.168673,0.142604,0.0778287,0,0,0,0,0),c(0,0.394698,0.213292,0.170983,0.147428,0.0735987,0,0,0,0,0),c(0,0.392639,0.219002,0.165544,0.146633,0.0761821,0,0,0,0,0),c(0,0.396947,0.225602,0.165698,0.141919,0.0698341,0,0,0,0,0)),matrix(c(0.1,0.4,0.5,0.7,0.7),ncol=1),matrix(c(123583,998574,452996,798418,26559),ncol=1)))
 }

 if(!is.null(play.object)){

  if(substr(output.directory,nchar(output.directory),nchar(output.directory))=='/'){
   output=paste(output.directory,'dice.sims',sep='')
  } else {
   output=paste(output.directory,'/dice.sims',sep='')
  }

  numtaxa=dice.read.numtaxa(num.taxa, num.partitions)
  if(-1%in%numtaxa){
   print("You have included a non-positive number in the 'num.taxa' object; Multi-DICE cannot continue")
  }

  numchanges=dice.read.numchanges(num.partitions=num.partitions, num.changes=num.changes)
  if(-1%in%numchanges){
   print("You have included a non-positive number in the 'num.changes' object; Multi-DICE cannot continue")
  }

  if(2%in%numchanges[['numchanges']]){
   flipvector=dice.read.flipvector(num.partitions, flip)
  }

  numhaps=dice.read.numhaps(num.partitions, num.haploid.samples)
  if(-1%in%numhaps){
   print("You have included a non-positive number in the 'num.haploid.samples' object; Multi-DICE cannot continue")
  }

  numsites=dice.read.numsites(num.partitions, num.ind.sites, num.SNPs, length.seq)
  if(-1%in%numsites){
   print("You have not specified any of the 'num.ind.sites', 'num.SNPs', or 'length.seq' objects, or have included a non-positive number in the relevant object; Multi-DICE cannot continue")
  }
  if(is.null(num.ind.sites)&&!is.null(num.SNPs)&&!is.null(length.seq)&&!is.null(mut.rate.prior)&&!-1%in%numsites){
   lengthseq=dice.read.numsites(num.partitions, num.ind.sites=NULL, num.SNPs=NULL, length.seq)
   if(-1%in%lengthseq){
    trap=1
    print("You have included a non-positive number in the 'length.seq' object; Multi-DICE cannot continue")
   }
  }

  fold=dice.read.fold(num.partitions, folded)

  trap=0
  if(!is.null(sampling.times)){
   samtimes=dice.read.samtimes(num.partitions, sampling.times)
   if(-1%in%samtimes){
    trap=1
    print("You have included a negative number in the 'sampling.times' object; Multi-DICE cannot continue")
   }
  }

  if(!is.null(gen.times)){
   gentimes=dice.read.gentimes(num.partitions, gen.times)
   if(-1%in%gentimes){
    trap=1
    print("You have included a non-positive number in the 'gen.times' object; Multi-DICE cannot continue")
   }
  }

  if(is.null(num.ind.sites)&&is.null(num.SNPs)&&!is.null(length.seq)||is.null(num.ind.sites)&&!is.null(num.SNPs)&&!is.null(length.seq)&&!is.null(mut.rate.prior)){
   if(is.null(mut.rate.prior)){
    trap=1
    print("You have not specified the 'mut.rate.prior' object while specifying the single-locus sequence model; Multi-DICE cannot continue")
   } else {
    mutrate=dice.read.mutrate(num.partitions, mut.rate.prior)
    if(-1%in%mutrate){
     trap=1
     print("You have included a non-positive number in the 'mut.rate.prior' object; Multi-DICE cannot continue")
    }
   }
  }

  if(file.exists(paste(output,'.fsc2template',sep=''))){
   trap=1
   print("You have a file named 'dice.sims.fsc2template' in the output directory specified in the 'output.directory' object; Multi-DICE cannot continue")
  }
  if(append.sims==F){
   if(file.exists(paste(substr(output,1,(nchar(output)-9)),'seed.txt',sep=''))){
    trap=1
    print("You have a file named 'seed.txt' in the output directory specified in the 'output.directory' object; Multi-DICE cannot continue")
   }
   if(file.exists(paste(substr(output,1,(nchar(output)-9)),'MRCAs.txt',sep=''))){
    trap=1
    print("You have a file named 'MRCAs.txt' in the output directory specified in the 'output.directory' object; Multi-DICE cannot continue")
   }
   if(file.exists(paste(substr(output,1,(nchar(output)-9)),'dice.log',sep=''))){
    trap=1
    print("You have a file named 'dice.log' in the output directory specified in the 'output.directory' object; Multi-DICE cannot continue")
   }
   a=0
   while(a<sum(numtaxa[['numtaxa']])&&trap==0){
    a=a+1
    if(file.exists(paste(substr(output,1,(nchar(output)-1)),'ulations',a,sep=''))){
     trap=1
     print("You have a filename in the output directory specified in the 'output.directory' object that is the same as an output simulation file (to append to existing files, specify the option 'append.sims' to TRUE); Multi-DICE cannot continue")
    }
   }
   if(!file.exists(paste(output,'.fsc2template',sep=''))){
    system(paste('ls ',output.directory,'|grep dice.sims|wc -l|tr -d " " >',output,'.fsc2template',sep=''))
    if(as.numeric(read.table(paste(output,'.fsc2template',sep='')))[1]>1){
     trap=1
     print("You have a filename/directory in the output directory specified in the 'output.directory' object that begins with 'dice.sims' (to append to existing files, specify the option 'append.sims' to TRUE); Multi-DICE cannot continue")
    }
    system(paste('rm ',output,'.fsc2template',sep=''))
   }
  }

  work.dr=getwd()

  if(!file.exists(paste(output,'.fsc2template',sep=''))){
   if(substr(fsc2path,1,1)=='/'){
    system(paste(fsc2path,' 2>&1|wc -l|tr -d " "|cut -d " " -f 1 >',output,'.fsc2template',sep=''))
   } else {
    setwd(output.directory)
    system(paste('./',fsc2path,' 2>&1|wc -l|tr -d " "|cut -d " " -f 1 >dice.sims.fsc2template',sep=''))
    setwd(work.dr)
   }
   if(read.table(paste(output,'.fsc2template',sep=''))==0){
    trap=1
    print("You have not specified a valid fastsimcoal2 executable file path for the 'fsc2path' object (must include executable filename as well); Multi-DICE cannot continue")
   }
   system(paste('rm ',output,'.fsc2template',sep=''))
  }

  if(!-1%in%numtaxa&&!-1%in%numchanges&&!-1%in%numhaps&&!-1%in%numsites&&trap==0){

   if(messages1==0){
    if(numtaxa[['numtaxacaution']]==1){
     print("Caution: You have specified an inappropriate number of vector elements for the 'num.taxa' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'num.taxa' elements, with x = 'num.partitions', or if not applicable, with the first 'num.taxa' element used for all partitions")
    }
   }
   if(messages2==0){
    if(numchanges[['numchangescaution']]==1){
     print("Caution: You have specified an inappropriate number of vector elements for the 'num.changes' object, and/or have included an inappropriate number in the 'num.changes' object; this should be of length = 'num.partitions' or 1, and include values of only 1 or 2 (i.e. Multi-DICE currently allows only up to two demographic events per taxon); Multi-DICE will continue with only the first x 'num.changes' elements, with x = 'num.partitions', or if not applicable, with the first 'num.changes' element used for all partitions, as well as any number >2 converted to 2")
    }
   }
   if(2%in%numchanges[['numchanges']]){
    if(flipvector[['flipvectorcaution']]==1){
     print("Caution: You have specified an inappropriate number of vector elements for the 'flip' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'flip' elements, with x = 'num.partitions', or if not applicable, with the first 'flip' element used for all partitions")
    }
   }
   if(numhaps[['numhapscaution']]==1){
    print("Caution: You have specified an inappropriate number of vector elements for the 'num.haploid.samples' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'num.haploid.samples' elements, with x = 'num.partitions', or if not applicable, with the first 'num.haploid.samples' element used for all partitions")
   }
   if(numsites[['numsitescaution']]==1){
    print("Caution: You have specified an inappropriate number of vector elements for the 'num.ind.sites', 'num.SNPs', or 'length.seq' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'num.ind.sites', 'num.SNPs', or 'length.seq' elements, with x = 'num.partitions', or if not applicable, with the first 'num.ind.sites', 'num.SNPs', or 'length.seq' element used for all partitions")
   }
   if(fold[['foldcaution']]==1){
    print("Caution: You have specified an inappropriate number of vector elements for the 'folded' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'folded' elements, with x = 'num.partitions', or if not applicable, with the first 'folded' element used for all partitions")
   }
   if(!is.null(sampling.times)){
    if(samtimes[['samtimescaution']]==1){
     print("Caution: You have specified an inappropriate number of vector elements for the 'sampling.times' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'sampling.times' elements, with x = 'num.partitions', or if not applicable, with the first 'sampling.times' element used for all partitions")
    }
   }
   if(!is.null(gen.times)){
    if(gentimes[['gentimescaution']]==1){
     print("Caution: You have specified an inappropriate number of vector elements for the 'gen.times' object; this should be of length = total of 'num.taxa', 'num.partitions', or 1; Multi-DICE will continue with only the first x 'gen.times' elements, with x = total of 'num.taxa', 'num.partitions' (with each element used for a partition), or 1 (with the first element used for all taxa)")
    }
   }
   if(is.null(num.ind.sites)&&is.null(num.SNPs)&&!is.null(length.seq)){
    if(mutrate[['mutratecaution']]==1){
     print("Caution: You have specified an inappropriate number of distributions for your 'mut.rate.prior' object; the number of distributions should be = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'mut.rate.prior' distributions, with x = 'num.partitions', or if not applicable, with the first 'mut.rate.prior' distribution used for all partitions")
    }
   }

   if(output.hyper.draws==T&&!'no.taxa.draws'%in%play.object){
    for(a in names(play.object$roll.object)){
     if(substr(a,1,4)=='draw'){
      for(b in names(play.object$roll.object[[paste(a,sep='')]])){
       if(substr(a,7,10)=='zeta'){
        for(c in 1:num.partitions){
         write.table(play.object$roll.object[[paste(a,sep='')]][[paste(b,sep='')]][[c]]/sum(numtaxa[['numtaxa']]), paste(output,'hyper',a,b,c,'temp',sep='.'), row.names=F, col.names=F)
         system(paste('cat ',output,'.hyper.',a,'.',b,'.',c,'.temp >>',output,'.hyper.',a,'.',b,'.',c,sep=''))
         system(paste('rm ',output,'.hyper.',a,'.',b,'.',c,'.temp',sep=''))
        }
       } else {
        write.table(play.object$roll.object[[paste(a,sep='')]][[paste(b,sep='')]], paste(output,'hyper',a,b,'temp',sep='.'), row.names=F, col.names=F)
        system(paste('cat ',output,'.hyper.',a,'.',b,'.temp >>',output,'.hyper.',a,'.',b,sep=''))
        system(paste('rm ',output,'.hyper.',a,'.',b,'.temp',sep=''))
       }
      }
     } else {
      if(sub('zeta','',a)==a){
       write.table(play.object$roll.object[[paste(a,sep='')]], paste(output,'hyper.draws',a,'temp',sep='.'), row.names=F, col.names=F)
      } else {
       write.table(play.object$roll.object[[paste(a,sep='')]]/sum(numtaxa[['numtaxa']]), paste(output,'hyper.draws',a,'temp',sep='.'), row.names=F, col.names=F)
      }
      system(paste('cat ',output,'.hyper.draws.',a,'.temp >>',output,'.hyper.draws.',a,sep=''))
      system(paste('rm ',output,'.hyper.draws.',a,'.temp',sep=''))
     }
    }
   }

   if(output.taxa.draws==T&&!'no.taxa.draws'%in%play.object){
    for(a in names(play.object$sim.specs)){
     write.table(play.object$sim.specs[[paste(a,sep='')]], paste(output,'taxa.draws',a,'temp',sep='.'), row.names=F, col.names=F)
     system(paste('cat ',output,'.taxa.draws.',a,'.temp >>',output,'.taxa.draws.',a,sep=''))
     system(paste('rm ',output,'.taxa.draws.',a,'.temp',sep=''))
    }
   }

   messages=NULL
   if(!is.null(messages.sims)){
    if(messages.sims>0){
     for(a in 1:round(num.sims/messages.sims)){
      messages=c(messages,(a*messages.sims))
     }
     messages=messages[messages!=num.sims]
    }
   }

   system(paste('echo "//Number of population samples (demes)" >>',output,'.fsc2template',sep=''))
   system(paste('echo "1" >>',output,'.fsc2template',sep=''))
   system(paste('echo "//Population effective sizes (number of genes)" >>',output,'.fsc2template',sep=''))
   system(paste('echo "NPOP" >>',output,'.fsc2template',sep=''))
   system(paste('echo "//Sample sizes" >>',output,'.fsc2template',sep=''))
   system(paste('echo "num.haploid.samples" >>',output,'.fsc2template',sep=''))
   system(paste('echo "//Growth rates	: negative growth implies population expansion" >>',output,'.fsc2template',sep=''))
   system(paste('echo "0" >>',output,'.fsc2template',sep=''))
   system(paste('echo "//Number of migration matrices : 0 implies no migration between demes" >>',output,'.fsc2template',sep=''))
   system(paste('echo "0" >>',output,'.fsc2template',sep=''))
   system(paste('echo "//historical event: time, source, sink, migrants, new size, new growth rate, migr. matrix" >>',output,'.fsc2template',sep=''))
   system(paste('echo "1 historical event" >>',output,'.fsc2template',sep=''))
   system(paste('echo "tau 0 0 0 epsilon 0 0" >>',output,'.fsc2template',sep=''))
   system(paste('echo "//Number of independent loci [chromosome]" >>',output,'.fsc2template',sep=''))
   system(paste('echo "1 0" >>',output,'.fsc2template',sep=''))
   system(paste('echo "//Per chromosome: Number of linkage blocks" >>',output,'.fsc2template',sep=''))
   system(paste('echo "1" >>',output,'.fsc2template',sep=''))
   system(paste('echo "//per Block: data type, num loci, rec. rate and mut rate + optional parameters" >>',output,'.fsc2template',sep=''))
   system(paste('echo "FREQ 1 0 0 OUTEXP" >>',output,'.fsc2template',sep=''))

   setwd(output.directory)
   for(a in 1:num.partitions){
    for(b in (sum(numtaxa[['numtaxa']][0:(a-1)])+1):sum(numtaxa[['numtaxa']][0:a])){
     if(fold[['fold']][a]==T){
      freqtype1='m'
      freqtype2='M'
     } else {
      freqtype1='d'
      freqtype2='D'
     }
     system(paste('echo "//Number of population samples (demes)" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "1" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "//Population effective sizes (number of genes)" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "1000" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "//Sample sizes" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "',numhaps[['numhaps']][a],'" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "//Growth rates  : negative growth implies population expansion" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "0" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "//Number of migration matrices : 0 implies no migration between demes" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "0" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "//historical event: time, source, sink, migrants, new size, new growth rate, migr. matrix" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "1 historical event" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "100 0 0 0 .9 0 0" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "//Number of independent loci [chromosome]" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "1000 0" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "//Per chromosome: Number of linkage blocks" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "1" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "//per Block: data type, num loci, rec. rate and mut rate + optional parameters" >>','dice.sims',b,'.par',sep=''))
     system(paste('echo "SNP 1 0 0" >>','dice.sims',b,'.par',sep=''))
     if(substr(fsc2path,1,1)=='/'){
      system(paste(fsc2path,' -i dice.sims',b,'.par -n 1 -',freqtype1,' -c 0 >dice.log 2>&1',sep=''))
     } else {
      system(paste('./',fsc2path,' -i dice.sims',b,'.par -n 1 -',freqtype1,' -c 0 >dice.log 2>&1',sep=''))
     }
     system(paste('mv dice.sims',b,'/dice.sims',b,'_',freqtype2,'AFpop0.obs ./',sep=''))
    }
   }
   setwd(work.dr)

   for(a in 1:num.sims){
    if(a!=1&&(a-1)%in%messages){
     print(paste('Simulation #',(a-1),' has been completed',sep=''))
    }
    if(!'no.taxa.draws'%in%play.object){
     play.object.temp=NULL
     for(b in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE', 'exponential.growth.rate', 'exponential.growth.rate2')){
      if(b %in% names(play.object$sim.specs)){
       play.object.temp=append(play.object.temp,list(play.object$sim.specs[[paste(b,sep='')]][a,]))
       names(play.object.temp)[length(play.object.temp)]=b
      }
     }
    } else {
     roll.object.temp=NULL
     for(b in c('draws.psi', 'draws.pulse.values', 'draws.zeta')){
      roll.object.temp=append(roll.object.temp,list(NULL))
      names(roll.object.temp)[length(roll.object.temp)]=b
      for(c in c('tau', 'tau2', 'epsilon', 'epsilon2', 'NE')){
       if(c%in%names(roll.object[['draws.psi']])){
        if(b=='draws.zeta'){
         roll.object.temp[[paste(b,sep='')]]=append(roll.object.temp[[paste(b,sep='')]], list(NULL))
         names(roll.object.temp[[paste(b,sep='')]])[length(roll.object.temp[[paste(b,sep='')]])]=paste(c,sep='')
         for(d in 1:num.partitions){
          roll.object.temp[[paste(b,sep='')]][[paste(c,sep='')]]=append(roll.object.temp[[paste(b,sep='')]][[paste(c,sep='')]], list(matrix(roll.object[[paste(b,sep='')]][[paste(c,sep='')]][[d]][a,],nrow=1)))
         }
        } else {
         roll.object.temp[[paste(b,sep='')]]=append(roll.object.temp[[paste(b,sep='')]], list(matrix(roll.object[[paste(b,sep='')]][[paste(c,sep='')]][a,],nrow=1)))
         names(roll.object.temp[[paste(b,sep='')]])[length(roll.object.temp[[paste(b,sep='')]])]=c
        }
       }
      }
     }
     play.object.temp=play.dice(num.sims=1, num.taxa=num.taxa, num.partitions=num.partitions, tau.psi.prior=tau.psi.prior, epsilon.psi.prior=epsilon.psi.prior, NE.psi.prior=NE.psi.prior, tau.zeta.prior=tau.zeta.prior, tau2.zeta.prior=tau2.zeta.prior, epsilon.zeta.prior=epsilon.zeta.prior, epsilon2.zeta.prior=epsilon2.zeta.prior, NE.zeta.prior=NE.zeta.prior, tau.zeta.total.prior=tau.zeta.total.prior, tau2.zeta.total.prior=tau2.zeta.total.prior, epsilon.zeta.total.prior=epsilon.zeta.total.prior, epsilon2.zeta.total.prior=epsilon2.zeta.total.prior, NE.zeta.total.prior=NE.zeta.total.prior, tau.shared.prior=tau.shared.prior, tau2.shared.prior=tau2.shared.prior, epsilon.shared.prior=epsilon.shared.prior, epsilon2.shared.prior=epsilon2.shared.prior, NE.shared.prior=NE.shared.prior, tau.idio.prior=tau.idio.prior, tau2.idio.prior=tau2.idio.prior, epsilon.idio.prior=epsilon.idio.prior, epsilon2.idio.prior=epsilon2.idio.prior, NE.idio.prior=NE.idio.prior, linked.param=linked.param, attached.hyper=attached.hyper, linked.param.partition=linked.param.partition, attached.hyper.pulse=attached.hyper.pulse, linked.param.prior=linked.param.prior, linked.param.fixed=linked.param.fixed, anchor.prior=anchor.prior, change.prior=change.prior, exponential.growth.rate.prior=exponential.growth.rate.prior, exponential.growth.rate.prior2=exponential.growth.rate.prior2, dirichlet.process=dirichlet.process, idiosyncratic=idiosyncratic, min.net.tau.zeta.total=min.net.tau.zeta.total, min.net.tau2.zeta.total=min.net.tau2.zeta.total, min.net.epsilon.zeta.total=min.net.epsilon.zeta.total, min.net.epsilon2.zeta.total=min.net.epsilon2.zeta.total, min.net.NE.zeta.total=min.net.NE.zeta.total, max.net.tau.zeta.total=max.net.tau.zeta.total, max.net.tau2.zeta.total=max.net.tau2.zeta.total, max.net.epsilon.zeta.total=max.net.epsilon.zeta.total, max.net.epsilon2.zeta.total=max.net.epsilon2.zeta.total, max.net.NE.zeta.total=max.net.NE.zeta.total, min.net.tau.zeta.per.pulse=min.net.tau.zeta.per.pulse, min.net.tau2.zeta.per.pulse=min.net.tau2.zeta.per.pulse, min.net.epsilon.zeta.per.pulse=min.net.epsilon.zeta.per.pulse, min.net.epsilon2.zeta.per.pulse=min.net.epsilon2.zeta.per.pulse, min.net.NE.zeta.per.pulse=min.net.NE.zeta.per.pulse, max.net.tau.zeta.per.pulse=max.net.tau.zeta.per.pulse, max.net.tau2.zeta.per.pulse=max.net.tau2.zeta.per.pulse, max.net.epsilon.zeta.per.pulse=max.net.epsilon.zeta.per.pulse, max.net.epsilon2.zeta.per.pulse=max.net.epsilon2.zeta.per.pulse, max.net.NE.zeta.per.pulse=max.net.NE.zeta.per.pulse, tau.buffer=tau.buffer, tau2.buffer=tau2.buffer, epsilon.buffer=epsilon.buffer, epsilon2.buffer=epsilon2.buffer, NE.buffer=NE.buffer, tau.idiosyncratic.buffer=tau.idiosyncratic.buffer, tau2.idiosyncratic.buffer=tau2.idiosyncratic.buffer, epsilon.idiosyncratic.buffer=epsilon.idiosyncratic.buffer, epsilon2.idiosyncratic.buffer=epsilon2.idiosyncratic.buffer, NE.idiosyncratic.buffer=NE.idiosyncratic.buffer, idiosyncratic.rule=idiosyncratic.rule, num.changes=num.changes, flip=flip, net.zeta.total=net.zeta.total, net.zeta.per.pulse=net.zeta.per.pulse, mean.tau.shared=mean.tau.shared, mean.tau2.shared=mean.tau2.shared, mean.epsilon.shared=mean.epsilon.shared, mean.epsilon2.shared=mean.epsilon2.shared, mean.NE.shared=mean.NE.shared, mean.tau=mean.tau, mean.tau2=mean.tau2, mean.epsilon=mean.epsilon, mean.epsilon2=mean.epsilon2, mean.NE=mean.NE, disp.index.tau.shared=disp.index.tau.shared, disp.index.tau2.shared=disp.index.tau2.shared, disp.index.epsilon.shared=disp.index.epsilon.shared, disp.index.epsilon2.shared=disp.index.epsilon2.shared, disp.index.NE.shared=disp.index.NE.shared, disp.index.tau=disp.index.tau, disp.index.tau2=disp.index.tau2, disp.index.epsilon=disp.index.epsilon, disp.index.epsilon2=disp.index.epsilon2, disp.index.NE=disp.index.NE, build.object=build.object, roll.object=roll.object.temp, skipper=1)
     if(a==1){
      for(b in names(play.object.temp$roll.object)){
       if(substr(b,1,4)!='draw'){
        roll.object=append(roll.object,list(matrix(rep(0,(num.sims*length(play.object.temp$roll.object[[paste(b,sep='')]]))),ncol=length(play.object.temp$roll.object[[paste(b,sep='')]]))))
        names(roll.object)[[length(roll.object)]]=b
       }
      }
     }
     for(b in names(play.object.temp$roll.object)){
      if(substr(b,1,4)!='draw'){
       roll.object[[paste(b,sep='')]][a,]=play.object.temp$roll.object[[paste(b,sep='')]][1,]
      }
     }
     if(output.hyper.draws==T){
      for(b in names(play.object.temp$roll.object)){
       if(substr(b,1,4)=='draw'){
        for(c in names(play.object.temp$roll.object[[paste(b,sep='')]])){
         if(substr(b,7,10)=='zeta'){
          for(d in 1:num.partitions){
           write.table(play.object.temp$roll.object[[paste(b,sep='')]][[paste(c,sep='')]][[d]]/sum(numtaxa[['numtaxa']]), paste(output,'hyper',b,c,d,'temp',sep='.'), row.names=F, col.names=F)
           system(paste('cat ',output,'.hyper.',b,'.',c,'.',d,'.temp >>',output,'.hyper.',b,'.',c,'.',d,sep=''))
           system(paste('rm ',output,'.hyper.',b,'.',c,'.',d,'.temp',sep=''))
          }
         } else {
          write.table(play.object.temp$roll.object[[paste(b,sep='')]][[paste(c,sep='')]], paste(output,'hyper',b,c,'temp',sep='.'), row.names=F, col.names=F)
          system(paste('cat ',output,'.hyper.',b,'.',c,'.temp >>',output,'.hyper.',b,'.',c,sep=''))
          system(paste('rm ',output,'.hyper.',b,'.',c,'.temp',sep=''))
         }
        }
       } else {
        if(sub('zeta','',b)==b){
         write.table(play.object.temp$roll.object[[paste(b,sep='')]], paste(output,'hyper.draws',b,'temp',sep='.'), row.names=F, col.names=F)
        } else {
         write.table(play.object.temp$roll.object[[paste(b,sep='')]]/sum(numtaxa[['numtaxa']]), paste(output,'hyper.draws',b,'temp',sep='.'), row.names=F, col.names=F)
        }
        system(paste('cat ',output,'.hyper.draws.',b,'.temp >>',output,'.hyper.draws.',b,sep=''))
        system(paste('rm ',output,'.hyper.draws.',b,'.temp',sep=''))
       }
      }
     }
     if(output.taxa.draws==T){
      for(b in names(play.object.temp$sim.specs)){
       write.table(play.object.temp$sim.specs[[paste(b,sep='')]], paste(output,'taxa.draws',b,'temp',sep='.'), row.names=F, col.names=F)
       system(paste('cat ',output,'.taxa.draws.',b,'.temp >>',output,'.taxa.draws.',b,sep=''))
       system(paste('rm ',output,'.taxa.draws.',b,'.temp',sep=''))
      }
     }
     play.object.temp=play.object.temp$sim.specs
    }
    for(b in 1:num.partitions){
     if(is.null(num.ind.sites)&&is.null(num.SNPs)&&!is.null(length.seq)){
      asub1=0
      asub2=0
      for(c in 1:(numhaps[['numhaps']][b]-1)){
       asub1=asub1+(1/c)
       asub2=asub2+(1/(c^2))
      }
      bsub1=(numhaps[['numhaps']][b]+1)/(3*(numhaps[['numhaps']][b]-1))
      bsub2=(2*((numhaps[['numhaps']][b]^2)+numhaps[['numhaps']][b]+3))/((9*numhaps[['numhaps']][b])*(numhaps[['numhaps']][b]-1))
      csub1=bsub1-(1/asub1)
      csub2=bsub2-((numhaps[['numhaps']][b]+2)/(asub1*numhaps[['numhaps']][b]))+(asub2/(asub1^2))
      esub1=csub1/asub1
      esub2=csub2/((asub1^2)+asub2)
     }
     for(c in (sum(numtaxa[['numtaxa']][0:(b-1)])+1):sum(numtaxa[['numtaxa']][0:b])){
      system(paste('cp ',output,'.fsc2template ',output,c,'.par',sep=''))
      if(!is.null(sampling.times)){
       system(paste('cat ',output,c,'.par|awk "NR<6" >',output,c,'.par.top',sep=''))
       system(paste('cat ',output,c,'.par|awk "NR==6" >',output,c,'.par.mid0',sep=''))
       system(paste('echo "',samtimes[['samtimes']][b],'" >',output,c,'.par.mid1',sep=''))
       system(paste('paste -d " " ',output,c,'.par.mid0 ',output,c,'.par.mid1 >',output,c,'.par.mid',sep=''))
       system(paste('cat ',output,c,'.par|awk "NR>6" >',output,c,'.par.bot',sep=''))
       system(paste('cat ',output,c,'.par.top ',output,c,'.par.mid ',output,c,'.par.bot >',output,c,'.par',sep=''))
      }
      if(is.null(num.ind.sites)&&!is.null(num.SNPs)){
       system(paste('cat ',output,c,'.par|awk "NR<15" >',output,c,'.par.top',sep=''))
       system(paste('echo "',numsites[['numsites']][b],' 0" >',output,c,'.par.mid',sep=''))
       if(!is.null(length.seq)&&!is.null(mut.rate.prior)){
        if(length(mutrate[[b]])==1){
         system(paste('cat ',output,c,'.par|awk "NR>15"|sed -e "s/FREQ 1/SNP ',lengthseq[['numsites']][b],'/g" -e "s/0 OUTEXP/',mutrate[[b]],'/g" >',output,c,'.par.bot',sep=''))
        } else {
         system(paste('cat ',output,c,'.par|awk "NR>15"|sed -e "s/FREQ 1/SNP ',lengthseq[['numsites']][b],'/g" -e "s/0 OUTEXP/',sample(mutrate[[b]],1,replace=T),'/g" >',output,c,'.par.bot',sep=''))
        }
        if(output.taxa.draws==T||keep.taxa.draws==T){
         system(paste('cat ',output,c,'.par.bot|tail -n 1|cut -d " " -f 4 >>',output,c,'.mutrate',sep=''))
        }
       } else {
        system(paste('cat ',output,c,'.par|awk "NR>15"|sed -e "s/FREQ/SNP/g" -e "s/ OUTEXP//g" >',output,c,'.par.bot',sep=''))
       }
       system(paste('cat ',output,c,'.par.top ',output,c,'.par.mid ',output,c,'.par.bot >',output,c,'.par',sep=''))
      }
      if(is.null(num.ind.sites)&&is.null(num.SNPs)&&!is.null(length.seq)){
       if(length(mutrate[[b]])==1){
        system(paste('cat ',output,c,'.par|sed -e "s/FREQ 1/SNP ',numsites[['numsites']][b],'/g" -e "s/0 OUTEXP/',mutrate[[b]],'/g" >',output,c,'.par.temp',sep=''))
       } else {
        system(paste('cat ',output,c,'.par|sed -e "s/FREQ 1/SNP ',numsites[['numsites']][b],'/g" -e "s/0 OUTEXP/',sample(mutrate[[b]],1,replace=T),'/g" >',output,c,'.par.temp',sep=''))
       }
       system(paste('mv ',output,c,'.par.temp ',output,c,'.par',sep=''))
      }
      for(d in c('tau','epsilon','NE','num.haploid.samples')){
       if(d=='tau'&&!is.null(gen.times)){
        #all draws are randomly assigned to taxa, so keeping the user-specified order of the gentimes does not impose a bias here
        play.object.temp$tau[c]=play.object.temp$tau[c]/gentimes[['gentimes']][c]
        if(numchanges[['numchanges']][b]==2){
         play.object.temp$tau2[c]=play.object.temp$tau2[c]/gentimes[['gentimes']][c]
        }
       }
       if(d=='NE'){
        find='NPOP'
       } else {
        find=d
       }
       if(d=='epsilon'&&'exponential.growth.rate'%in%names(play.object.temp)){
        replace=1
        system(paste('cat ',output,c,'.par|awk "NR<12" >',output,c,'.par.top',sep=''))
        system(paste('cat ',output,c,'.par|awk "NR==12"|cut -d " " -f 1 >',output,c,'.par.mid0',sep=''))
        hist=read.table(paste(output,c,'.par.mid0',sep=''))+1
        system(paste('echo ',hist,' historical events >',output,c,'.par.mid1',sep=''))
        if(log(play.object.temp$epsilon[c])!=0){
         system(paste('echo "',(round(play.object.temp$tau[c]-abs(log(play.object.temp$epsilon[c])/play.object.temp$exponential.growth.rate[c]))),' 0 0 0 1 ',play.object.temp$exponential.growth.rate[c],' 0" >',output,c,'.par.mid2',sep=''))
        } else {
         system(paste('echo "',(play.object.temp$tau[c]-1),' 0 0 0 1 0 0" >',output,c,'.par.mid2',sep=''))
        }
        system(paste('cat ',output,c,'.par|awk "NR>12" >',output,c,'.par.bot',sep=''))
        system(paste('cat ',output,c,'.par.top ',output,c,'.par.mid1 ',output,c,'.par.mid2 ',output,c,'.par.bot >',output,c,'.par',sep=''))
       } else {
        if(d=='num.haploid.samples'){
         replace=numhaps[['numhaps']][b]
        } else {
         replace=play.object.temp[[paste(d,sep='')]][c]
        }
       }
       system(paste('cat ',output,c,'.par|sed -e "s/',find,'/',replace,'/g" >',output,c,'.temp; mv ',output,c,'.temp ',output,c,'.par',sep=''))
       if(d=='tau'&&numchanges[['numchanges']][b]==2){
        if('exponential.growth.rate2'%in%names(play.object.temp)){
         replace=1
         system(paste('cat ',output,c,'.par|awk "NR<14"|sed -e "s/1 historical event/3 historical events/g" >',output,c,'.par.top',sep=''))
         if(log(play.object.temp$epsilon2[c])!=0){
          system(paste('echo "',round((play.object.temp$tau2[c]-abs(log(play.object.temp$epsilon2[c])/play.object.temp$exponential.growth.rate2[c]))),' 0 0 0 1 ',play.object.temp$exponential.growth.rate2[c],' 0" >',output,c,'.par.mid0',sep=''))
         } else {
          system(paste('echo "',(play.object.temp$tau2[c]-1),' 0 0 0 1 0 0" >',output,c,'.par.mid0',sep=''))
         }
         system(paste('cat ',output,c,'.par.top ',output,c,'.par.mid0 >',output,c,'.par.mid; mv ',output,c,'.par.mid ',output,c,'.par.top',sep=''))
        } else {
         replace=play.object.temp$epsilon2[c]
         system(paste('cat ',output,c,'.par|awk "NR<14"|sed -e "s/1 historical event/2 historical events/g" >',output,c,'.par.top',sep=''))
        }
        system(paste('echo "',play.object.temp$tau2[c],' 0 0 0 ',replace,' 0 0" >',output,c,'.par.mid',sep=''))
        system(paste('cat ',output,c,'.par|awk "NR>13" >',output,c,'.par.bot',sep=''))
        system(paste('cat ',output,c,'.par.top ',output,c,'.par.mid ',output,c,'.par.bot >',output,c,'.par',sep=''))
       }
      }
      if(numchanges[['numchanges']][b]==2||'exponential.growth.rate'%in%names(play.object.temp)||'exponential.growth.rate2'%in%names(play.object.temp)){
       if(flipvector[['flipvector']][b]==T||'exponential.growth.rate'%in%names(play.object.temp)||'exponential.growth.rate2'%in%names(play.object.temp)){
        system(paste('cat ',output,c,'.par|grep -n "historical event"|cut -d ":" -f 1 >',output,c,'.par.temp',sep=''))
        line.num.hist=as.numeric(read.table(paste(output,c,'.par.temp')))
        system(paste('cat ',output,c,'.par|grep "historical event"|cut -d " " -f 1 >',output,c,'.par.temp',sep=''))
        num.hist=as.numeric(read.table(paste(output,c,'.par.temp')))
        system(paste('cat ',output,c,'.par|awk "NR<',(line.num.hist+num.hist+1),'"|awk "NR>',line.num.hist,'"|cut -d " " -f 1 >',output,c,'.par.temp',sep=''))
        new.lines.num.hist=order(as.matrix(read.table(paste(output,c,'.par.temp'))))+line.num.hist
        system(paste('cat ',output,c,'.par|awk "NR<',(line.num.hist+1),'" >',output,c,'.par.top',sep=''))
        system(paste('cat ',output,c,'.par|awk "NR>',(line.num.hist+num.hist),'" >',output,c,'.par.bot',sep=''))
        for(d in new.lines.num.hist){
         system(paste('cat ',output,c,'.par|awk "NR==',d,'" >',output,c,'.par.mid',which(new.lines.num.hist==d),sep=''))
        }
        new.lines.num.hist.files=NULL
        for(d in new.lines.num.hist){
         new.lines.num.hist.files=paste(new.lines.num.hist.files,' ',output,c,'.par.mid',num.hist,sep='')
        }
        system(paste('cat ',output,c,'.par.top ',new.lines.num.hist.files,' ',output,c,'.par.top >',output,c,'.par',sep=''))
        system(paste('rm ',output,c,'.par.top ',new.lines.num.hist.files,' ',output,c,'.par.top',sep=''))
       }
      }
      if(fold[['fold']][b]==T){
       freqtype1='m'
       freqtype2='M'
      } else {
       freqtype1='d'
       freqtype2='D'
      }
      setwd(output.directory)
      if(!is.null(num.ind.sites)){
       if(substr(fsc2path,1,1)=='/'){
        system(paste(fsc2path,' -i dice.sims',c,'.par -n ',numsites[['numsites']][b],' -',freqtype1,' -c 0 >dice.log 2>&1',sep=''))
       } else {
        system(paste('./',fsc2path,' -i dice.sims',c,'.par -n ',numsites[['numsites']][b],' -',freqtype1,' -c 0 >dice.log 2>&1',sep=''))
       }
       system(paste('cat dice.sims',c,'/dice.sims',c,'_',freqtype2,'AFpop0.txt|awk "NR==2" >>dice.simulations',c,sep=''))
      } else {
       if(!is.null(num.SNPs)){
        if(substr(fsc2path,1,1)=='/'){
         system(paste(fsc2path,' -i dice.sims',c,'.par -n 1 -',freqtype1,' -c 0 >dice.log 2>&1',sep=''))
        } else {
         system(paste('./',fsc2path,' -i dice.sims',c,'.par -n 1 -',freqtype1,' -c 0 >dice.log 2>&1',sep=''))
        }
        system(paste('cat dice.sims',c,'/dice.sims',c,'_',freqtype2,'AFpop0.obs|awk "NR==3" >dice.sims',c,'.par.top',sep=''))
        convert=read.table(paste('dice.sims',c,'.par.top',sep=''))
        convert=convert/sum(convert)
        write.table(convert,paste('dice.sims',c,'.sfs',sep=''),row.names=F,col.names=F)
        system(paste('cat dice.sims',c,'.sfs >>dice.simulations',c,sep=''))
       } else {
        if(!is.null(length.seq)){
         if(substr(fsc2path,1,1)=='/'){
          system(paste(fsc2path,' -i dice.sims',c,'.par -n 1 -c 0 >dice.log 2>&1',sep=''))
         } else {
          system(paste('./',fsc2path,' -i dice.sims',c,'.par -n 1 -c 0 >dice.log 2>&1',sep=''))
         }
         system(paste('cat dice.sims',c,'/dice.sims',c,'_1_1.arp|awk "NR>23"|awk "NR<',(numhaps[['numhaps']][b]+1),'"|cut -f 3|tr -d " "|sed -e "s/0/0 /g" -e "s/1/1 /g" >dice.sims',c,'.hap',sep=''))
         haplotypes=c(read.table(paste('dice.sims',c,'.hap',sep=''))[[1]])
         sumstats=length(unique(haplotypes))
         hapdiv=0
         for(d in unique(haplotypes)){
          hapdiv=hapdiv+((sum(haplotypes==d)/length(haplotypes))^2)
         }
         sumstats=c(sumstats,((length(haplotypes)/(length(haplotypes)-1))*(1-hapdiv)))
         system(paste("cat dice.sims",c,".hap|sed -e 's/\\(.\\)/\\1 /g' >dice.sims",c,".seq",sep=""))
         sequences=as.matrix(read.table(paste('dice.sims',c,'.seq',sep='')))
         if(length(unique(haplotypes))>1){
          pair.combos=combn(1:length(unique(haplotypes)),2)
          nucdiv=0
          for(d in 1:ncol(pair.combos)){
           nucdiv=nucdiv+((sum(haplotypes==unique(haplotypes)[pair.combos[1,d]])/length(haplotypes))*(sum(haplotypes==unique(haplotypes)[pair.combos[2,d]])/length(haplotypes))*(sum(sequences[which(haplotypes==unique(haplotypes)[pair.combos[1,d]])[1],]!=sequences[which(haplotypes==unique(haplotypes)[pair.combos[2,d]])[1],])/numsites[['numsites']][b]))
          }
          sumstats=c(sumstats,(2*nucdiv))
         } else {
          sumstats=c(sumstats,0)
         }
         pwd=0
         if(length(haplotypes>1)){
          pair.combos=combn(1:length(haplotypes),2)
          for(d in 1:ncol(pair.combos)){
           pwd=pwd+sum(sequences[pair.combos[1,d],]!=sequences[pair.combos[2,d],])
          }
          pwd=pwd/ncol(pair.combos)
         }
         ess=0
         for(d in 1:ncol(sequences)){
          if((max(sequences[,d])-min(sequences[,d]))>0){
           ess=ess+1
          }
         }
         sumstats=c(sumstats,((pwd-(ess/asub1))/(((esub1*ess)+(esub2*ess*(ess-1)))^.5)))
         write.table(matrix(sumstats,nrow=1), sep='\t', paste('dice.sims',c,'.ss',sep=''), row.names=F, col.names=F)
         system(paste('cat dice.sims',c,'.ss >>dice.simulations',c,sep=''))
        }
       }
      }
      if(keep.fsc2.files==T){
       system(paste('cat seed.txt|sed -e "s/ :/:/g"|tr ":" "\n" >>dice.sims',c,'.seed',sep=''))
       if(!is.null(num.ind.sites)||!is.null(num.SNPs)){
        system(paste('paste dice.sims',c,'/dice.sims',c,'.lhoods dice.sims',c,'.seed >>dice.sims',c,'.fsc2',sep=''))
       }
      }
      setwd(work.dr)
     }
    }
   }
   print(paste('Simulation #',num.sims,' has been completed',sep=''))
   if(is.null(num.ind.sites)&&!is.null(length.seq)&&!is.null(mut.rate.prior)&&output.taxa.draws==T||is.null(num.ind.sites)&&!is.null(length.seq)&&!is.null(mut.rate.prior)&&keep.taxa.draws==T){
    mut.rate.names=NULL
    for(a in 1:sum(numtaxa[['numtaxa']])){
     mut.rate.names=paste(mut.rate.names,' ',output,a,'.mutrate',sep='')
    }
    system(paste('paste -d " " ',mut.rate.names,' >',output,'.taxa.draws.mut.rate',sep=''))
    system(paste('rm ',mut.rate.names,sep=''))
    if(keep.taxa.draws==T){
     play.object$sim.specs=append(play.object$sim.specs,list(mut.rate=as.matrix(read.big.matrix(paste(output,'.taxa.draws.mut.rate',sep='')))))
    }
    if(output.taxa.draws==F){
     system(paste('rm ',output,'.taxa.draws.mut.rate',sep=''))
    }
   }
   system(paste('rm ',output,'.fsc2template',sep=''))
   if(substr(output.directory,nchar(output.directory),nchar(output.directory))=='/'){
    system(paste('rm ',output.directory,'seed.txt ',output.directory,'MRCAs.txt ',output.directory,'dice.log 2>/dev/null',sep=''))
   } else {
    system(paste('rm ',output.directory,'/seed.txt ',output.directory,'/MRCAs.txt ',output.directory,'/dice.log 2>/dev/null',sep=''))
   }
   for(a in 1:sum(numtaxa[['numtaxa']])){
    system(paste('rm -r ',output,a,'*',sep=''))
   }
   if(keep.taxa.draws==T){
    return(play.object)
   } else {
    if('no.taxa.draws'%in%play.object){
     for(z in names(roll.object[['draws.zeta']])){
      for(y in 1:num.partitions){
       roll.object[['draws.zeta']][[paste(z,sep='')]][[y]]=roll.object[['draws.zeta']][[paste(z,sep='')]][[y]]/sum(numtaxa[['numtaxa']])
      }
     }
     return(list(roll.object=roll.object))
    } else {
     return(list(roll.object=play.object$roll.object))
    }
   }

  }

 }

}



if(!'bigmemory'%in%rownames(installed.packages())){
 install.packages('bigmemory')
}
library(bigmemory)
#' @importFrom bigmemory read.big.matrix
#' @export
dice.aSFS=function(num.sims, num.taxa, num.partitions=1, num.haploid.samples, folded=T, remove.afclasses=NULL, output.directory='.', input.directory=NULL, input.base=NULL, input.files=NULL, num.ind.sites, num.SNPs, length.seq, sampling.times, gen.times, convert.sequences, tau.psi.prior, epsilon.psi.prior, NE.psi.prior, tau.zeta.prior, tau2.zeta.prior, epsilon.zeta.prior, epsilon2.zeta.prior, NE.zeta.prior, tau.zeta.total.prior, tau2.zeta.total.prior, epsilon.zeta.total.prior, epsilon2.zeta.total.prior, NE.zeta.total.prior, tau.shared.prior, tau2.shared.prior, epsilon.shared.prior, epsilon2.shared.prior, NE.shared.prior, tau.idio.prior, tau2.idio.prior, epsilon.idio.prior, epsilon2.idio.prior, NE.idio.prior, linked.param, attached.hyper, linked.param.partition, attached.hyper.pulse, linked.param.prior, linked.param.fixed, anchor.prior, change.prior, exponential.growth.rate.prior, exponential.growth.rate.prior2, mut.rate.prior, dirichlet.process, idiosyncratic, min.net.tau.zeta.total, min.net.tau2.zeta.total, min.net.epsilon.zeta.total, min.net.epsilon2.zeta.total, min.net.NE.zeta.total, max.net.tau.zeta.total, max.net.tau2.zeta.total, max.net.epsilon.zeta.total, max.net.epsilon2.zeta.total, max.net.NE.zeta.total, min.net.tau.zeta.per.pulse, min.net.tau2.zeta.per.pulse, min.net.epsilon.zeta.per.pulse, min.net.epsilon2.zeta.per.pulse, min.net.NE.zeta.per.pulse, max.net.tau.zeta.per.pulse, max.net.tau2.zeta.per.pulse, max.net.epsilon.zeta.per.pulse, max.net.epsilon2.zeta.per.pulse, max.net.NE.zeta.per.pulse, tau.buffer, tau2.buffer, epsilon.buffer, epsilon2.buffer, NE.buffer, tau.idiosyncratic.buffer, tau2.idiosyncratic.buffer, epsilon.idiosyncratic.buffer, epsilon2.idiosyncratic.buffer, NE.idiosyncratic.buffer, idiosyncratic.rule, num.changes, flip, net.zeta.total, net.zeta.per.pulse, mean.tau.shared, mean.tau2.shared, mean.epsilon.shared, mean.epsilon2.shared, mean.NE.shared, mean.tau, mean.tau2, mean.epsilon, mean.epsilon2, mean.NE, disp.index.tau.shared, disp.index.tau2.shared, disp.index.epsilon.shared, disp.index.epsilon2.shared, disp.index.NE.shared, disp.index.tau, disp.index.tau2, disp.index.epsilon, disp.index.epsilon2, disp.index.NE, fsc2path, messages.sims, append.sims, keep.taxa.draws, output.hyper.draws, output.taxa.draws, keep.fsc2.files, build.object, roll.object, play.object){

 numtaxa=dice.read.numtaxa(num.taxa, num.partitions)
 if(-1%in%numtaxa){
  print("You have included a non-positive number in the 'num.taxa' object; Multi-DICE cannot continue")
 }

 numhaps=dice.read.numhaps(num.partitions, num.haploid.samples)
 if(-1%in%numhaps){
  print("You have included a non-positive number in the 'num.haploid.samples' object; Multi-DICE cannot continue")
 }

 fold=dice.read.fold(num.partitions, folded)

 if(!is.null(remove.afclasses)){
  afc=dice.read.afc(num.partitions, remove.afclasses)
 } else {
  afc=NULL
  for(a in 1:num.partitions){
   afc=append(afc,list(0))
  }
  afc=append(afc,list(afccaution=0))
 }
 if(-1%in%afc){
  print("You have included a negative number in the 'remove.afclasses' object; Multi-DICE cannot continue")
 } else {
  afclength=NULL
  for(a in 1:num.partitions){
   if(fold$fold[a]==T){
    afclength=c(afclength,sum(unique(afc[[a]])<=round(numhaps[['numhaps']][a])/2))
   } else {
    afclength=c(afclength,sum(unique(afc[[a]])<=(numhaps[['numhaps']][a]-1)))
   }
  }
 }

 onoff=0
 if(!is.null(input.directory)){
  inputdir=dice.read.inputdir(input.directory)
  if(!is.null(input.base)||!is.null(input.files)){
   inputs=dice.read.inputs(numtaxa, input.base, input.files)
   if(-1%in%inputs){
    onoff=1
    print("You have specified less vector elements than the total of the 'num.taxa' object for the 'input.files' object; Multi-DICE cannot continue")
   }
  } else {
   inputs=NULL
   for(a in 1:sum(numtaxa[['numtaxa']])){
    inputs=c(inputs,paste('dice.simulations',a,sep=''))
   }
   inputs=list(inputs=inputs,inputscaution=0)
  }
 }

 if(output.directory=='example'){
  onoff=1
  print('By specifying the output.directory argument as "example", a pre-simulated reference table following the first example command in the R documentation for dice.sims is being used as input, and the returned value is a matrix with the per-taxon SFS simulations converted to aSFS simulations')
  return(rbind(c(0.4015312,0.3980620,0.3959825,0.3958488,0.3947904,0.3939068,0.3925730,0.3912109,0.3870882,0.3848621,0.2250680,0.2243720,0.2225560,0.2218501,0.2196052,0.2187069,0.2184830,0.2179781,0.2176247,0.2175709,0.1781879,0.1730601,0.1695960,0.1690458,0.1673810,0.1670120,0.1666861,0.1652179,0.1648672,0.1641000,0.1510720,0.1507900,0.1505732,0.1480470,0.1469981,0.1464479,0.1462228,0.1456791,0.1443739,0.1380760,0.07429391,0.07377837,0.07227019,0.07112421,0.07100354,0.07049100,0.07016407,0.06968381,0.06812553,0.06596037),c(0.3997949,0.3940811,0.3940619,0.3939302,0.3911512,0.3911055,0.3897952,0.3871328,0.3871137,0.3870271,0.2273769,0.2262351,0.2242971,0.2209978,0.2209919,0.2168131,0.2167977,0.2142221,0.2139090,0.2136580,0.1784329,0.1741930,0.1734358,0.1731501,0.1712249,0.1697480,0.1696151,0.1694729,0.1686731,0.1685311,0.1501740,0.1483438,0.1479870,0.1474800,0.1454531,0.1450149,0.1430301,0.1426040,0.1411841,0.1398889,0.07782872,0.07751354,0.07494781,0.07437637,0.07240863,0.07031712,0.06948353,0.06906819,0.06844065,0.06748628),c(0.4017910,0.4016452,0.3988022,0.3960049,0.3946981,0.3920030,0.3910063,0.3903568,0.3884374,0.3879364,0.2315623,0.2235562,0.2223922,0.2221531,0.2212709,0.2195029,0.2144630,0.2143341,0.2137110,0.2132921,0.1743429,0.1721930,0.1709831,0.1706239,0.1688330,0.1685902,0.1679931,0.1662422,0.1658931,0.1651671,0.1511861,0.1504680,0.1496219,0.1485170,0.1485121,0.1474280,0.1466751,0.1462160,0.1456691,0.1432202,0.07390507,0.07359872,0.07162509,0.07103898,0.07035844,0.06869700,0.06835835,0.06617547,0.06536544,0.06358328),c(0.4018502,0.3952630,0.3943160,0.3938309,0.3934354,0.3931784,0.3926390,0.3916548,0.3905336,0.3883275,0.2286217,0.2272739,0.2228088,0.2211457,0.2205100,0.2190020,0.2185512,0.2172899,0.2140951,0.2140360,0.1724900,0.1692448,0.1659661,0.1655758,0.1655440,0.1652860,0.1628408,0.1618669,0.1614692,0.1595540,0.1543128,0.1512290,0.1499261,0.1485360,0.1485189,0.1471408,0.1468641,0.1466330,0.1461740,0.1429528,0.07741928,0.07661808,0.07618209,0.07439109,0.07295939,0.07122444,0.07085321,0.07068537,0.06967500,0.06950402),c(0.3982532,0.3981913,0.3980908,0.3969470,0.3968150,0.3951736,0.3927619,0.3909082,0.3902382,0.3889742,0.2289981,0.2270301,0.2257721,0.2256020,0.2222192,0.2204541,0.2182200,0.2172768,0.2166760,0.2154899,0.1732751,0.1719010,0.1714660,0.1708851,0.1676971,0.1673139,0.1667338,0.1660001,0.1656980,0.1647771,0.1522121,0.1493999,0.1476241,0.1471209,0.1467921,0.1460430,0.1436920,0.1432711,0.1419190,0.1388131,0.07198437,0.07141584,0.07135109,0.07107419,0.07106544,0.06983409,0.06889144,0.06704153,0.06551563,0.06510035)))
 }

 if(!-1%in%numtaxa&&!-1%in%numhaps&&!-1%in%afc&&onoff==0){

  if(numtaxa[['numtaxacaution']]==1){
   print("Caution: You have specified an inappropriate number of vector elements for the 'num.taxa' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'num.taxa' elements, with x = 'num.partitions', or if not applicable, with the first 'num.taxa' element used for all partitions")
  }
  if(numhaps[['numhapscaution']]==1){
   print("Caution: You have specified an inappropriate number of vector elements for the 'num.haploid.samples' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'num.haploid.samples' elements, with x = 'num.partitions', or if not applicable, with the first 'num.haploid.samples' element used for all partitions")
  }
  if(fold[['foldcaution']]==1){
   print("Caution: You have specified an inappropriate number of vector elements for the 'folded' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'folded' elements, with x = 'num.partitions', or if not applicable, with the first 'folded' element used for all partitions")
  }
  if(afc[['afccaution']]==1){
     print("Caution: You have specified an inappropriate number of list elements for the 'remove.afclasses' object; this should be of length = 'num.partitions' or 1 (a non-list vector object is treated as a list of length = 1); Multi-DICE will continue with only the first x 'remove.afclasses' elements, with x = 'num.partitions', or if not applicable, with the first 'remove.afclasses' element used for all partitions")
  }
  if(!is.null(input.directory)){
   if(inputs[['inputscaution']]==1){
    print("Caution: You have specified more vector elements than the total of the 'num.taxa' object for the 'input.files' object; Multi-DICE will continue with only the first x 'input.files' elements, with x = total of 'num.taxa'")
   }
  }

  SFSs=NULL
  if(!is.null(input.directory)){
   for(a in inputs$inputs){
    SFSs=append(SFSs,list(NULL))
    for(b in inputdir){
     SFSs[[length(SFSs)]]=rbind(SFSs[[length(SFSs)]],read.big.matrix(paste(b,a,sep=''), sep='\t', type='double')[])
    }
   }
  } else {
   for(a in 1:sum(numtaxa[['numtaxa']])){
    SFSs=append(SFSs,list(NULL))
    if(substr(output.directory,nchar(output.directory),nchar(output.directory))=='/'){
     SFSs[[a]]=rbind(SFSs[[a]],read.big.matrix(paste(output.directory,'dice.simulations',a,sep=''), sep='\t', type='double')[])
    } else {
     SFSs[[a]]=rbind(SFSs[[a]],read.big.matrix(paste(output.directory,'/dice.simulations',a,sep=''), sep='\t', type='double')[])
    }
   }
  }
  for(a in 1:num.partitions){
   for(b in (sum(numtaxa[['numtaxa']][0:(a-1)])+1):sum(numtaxa[['numtaxa']][0:a])){
    if(fold[['fold']][a]==T){
     SFSs[[b]]=matrix(SFSs[[b]][,1:(round(numhaps[['numhaps']][a]/2)+1)],ncol=(round(numhaps[['numhaps']][a]/2)+1))
    } else {
     SFSs[[b]]=matrix(SFSs[[b]][,1:numhaps[['numhaps']][a]],ncol=numhaps[['numhaps']][a])
    }
    SFSs[[b]]=matrix(SFSs[[b]][,-(unique(afc[[a]])+1)],ncol=(ncol(SFSs[[b]])-afclength[a]))
   }
  }
  bins=NULL
  for(a in 1:num.partitions){
   bins=c(bins,(numtaxa[['numtaxa']][a]*ncol(SFSs[[sum(numtaxa[['numtaxa']][1:a])]])))
  }
  aSFSs=matrix(rep(0,(sum(bins)*num.sims)),ncol=sum(bins))
  for(a in 1:num.sims){
   for(b in 1:num.partitions){
    SFS=NULL
    for(c in (sum(numtaxa[['numtaxa']][0:(b-1)])+1):sum(numtaxa[['numtaxa']][0:b])){
     SFS=rbind(SFS,SFSs[[c]][a,]/sum(SFSs[[c]][a,]))
    }
    aSFS=NULL
    for(c in 1:ncol(SFS)){
     aSFS=c(aSFS, sort(SFS[,c], decreasing=T))
    }
    aSFSs[a,(sum(bins[0:(b-1)])+1):sum(bins[0:b])]=aSFS
   }
  }

  return(aSFSs)

 }

}



if(!'fBasics'%in%rownames(installed.packages())){
 install.packages('fBasics')
}
library(fBasics)
#' @export
dice.sumstats=function(num.sims, num.taxa, num.partitions=1, num.haploid.samples, convert.sequences=F, output.directory='.', input.directory=NULL, input.base=NULL, input.files=NULL, num.ind.sites, num.SNPs, length.seq, folded, sampling.times, gen.times, remove.afclasses, tau.psi.prior, epsilon.psi.prior, NE.psi.prior, tau.zeta.prior, tau2.zeta.prior, epsilon.zeta.prior, epsilon2.zeta.prior, NE.zeta.prior, tau.zeta.total.prior, tau2.zeta.total.prior, epsilon.zeta.total.prior, epsilon2.zeta.total.prior, NE.zeta.total.prior, tau.shared.prior, tau2.shared.prior, epsilon.shared.prior, epsilon2.shared.prior, NE.shared.prior, tau.idio.prior, tau2.idio.prior, epsilon.idio.prior, epsilon2.idio.prior, NE.idio.prior, linked.param, attached.hyper, linked.param.partition, attached.hyper.pulse, linked.param.prior, linked.param.fixed, anchor.prior, change.prior, exponential.growth.rate.prior, exponential.growth.rate.prior2, mut.rate.prior, dirichlet.process, idiosyncratic, min.net.tau.zeta.total, min.net.tau2.zeta.total, min.net.epsilon.zeta.total, min.net.epsilon2.zeta.total, min.net.NE.zeta.total, max.net.tau.zeta.total, max.net.tau2.zeta.total, max.net.epsilon.zeta.total, max.net.epsilon2.zeta.total, max.net.NE.zeta.total, min.net.tau.zeta.per.pulse, min.net.tau2.zeta.per.pulse, min.net.epsilon.zeta.per.pulse, min.net.epsilon2.zeta.per.pulse, min.net.NE.zeta.per.pulse, max.net.tau.zeta.per.pulse, max.net.tau2.zeta.per.pulse, max.net.epsilon.zeta.per.pulse, max.net.epsilon2.zeta.per.pulse, max.net.NE.zeta.per.pulse, tau.buffer, tau2.buffer, epsilon.buffer, epsilon2.buffer, NE.buffer, tau.idiosyncratic.buffer, tau2.idiosyncratic.buffer, epsilon.idiosyncratic.buffer, epsilon2.idiosyncratic.buffer, NE.idiosyncratic.buffer, idiosyncratic.rule, num.changes, flip, net.zeta.total, net.zeta.per.pulse, mean.tau.shared, mean.tau2.shared, mean.epsilon.shared, mean.epsilon2.shared, mean.NE.shared, mean.tau, mean.tau2, mean.epsilon, mean.epsilon2, mean.NE, disp.index.tau.shared, disp.index.tau2.shared, disp.index.epsilon.shared, disp.index.epsilon2.shared, disp.index.NE.shared, disp.index.tau, disp.index.tau2, disp.index.epsilon, disp.index.epsilon2, disp.index.NE, fsc2path, messages.sims, append.sims, keep.taxa.draws, output.hyper.draws, output.taxa.draws, keep.fsc2.files, build.object, roll.object, play.object){

 numtaxa=dice.read.numtaxa(num.taxa, num.partitions)
 if(-1%in%numtaxa){
  print("You have included a non-positive number in the 'num.taxa' object; Multi-DICE cannot continue")
 }

 onoff=0
 if(convert.sequences==T){
  numhaps=dice.read.numhaps(num.partitions, num.haploid.samples)
  if(-1%in%numhaps){
   onoff=1
   print("You have included a non-positive number in the 'num.haploid.samples' object; Multi-DICE cannot continue")
  }
 }

 if(!is.null(input.directory)){
  inputdir=dice.read.inputdir(input.directory)
  if(!is.null(input.base)||!is.null(input.files)){
   inputs=dice.read.inputs(numtaxa, input.base, input.files)
   if(-1%in%inputs){
    onoff=1
    print("You have specified less vector elements than the total of the 'num.taxa' object for the 'input.files' object; Multi-DICE cannot continue")
   }
  } else {
   inputs=NULL
   for(a in 1:sum(numtaxa[['numtaxa']])){
    inputs=c(inputs,paste('dice.simulations',a,sep=''))
   }
   inputs=list(inputs=inputs,inputscaution=0)
  }
  if(convert.sequences==T){
   for(a in inputdir){
    if(file.exists(paste(a,'dice.sims.fsc2template',sep=''))){
     trap=1
     print("You have a file named 'dice.sims.fsc2template' in an input directory specified in the 'input.directory' object; Multi-DICE cannot continue")
    }
   }
  }
 } else {
  if(convert.sequences==T){
   inputdir=1
   if(substr(output.directory,nchar(output.directory),nchar(output.directory))=='/'){
    if(file.exists(paste(output.directory,'dice.sims.fsc2template',sep=''))){
     trap=1
     print("You have a file named 'dice.sims.fsc2template' in the output directory specified in the 'output.directory' object; Multi-DICE cannot continue")
    }
   } else {
    if(file.exists(paste(output.directory,'/dice.sims.fsc2template',sep=''))){
     trap=1
     print("You have a file named 'dice.sims.fsc2template' in the output directory specified in the 'output.directory' object; Multi-DICE cannot continue")
    }
   }
  }
 }

 if(output.directory=='example'){
  onoff=1
  print('By specifying the output.directory argument as "example", a pre-simulated reference table following the first example command in the R documentation for dice.sims (except num.ind.sites=2000 changed to length.seq=2000 and mut.rate.prior=c(1:100)/100000000000) is being used as input; the returned value is a list, with the first 10 elements representing the per-taxon single-sequence summary statistic simulations, the next element representing the according zeta draws, the next element representing the according tau_s draws, and the last element a matrix with the per-taxon simulations converted to multi-taxa single-sequence summary statistic vector simulations, which is the typical returned value for this function')
  return(list(rbind(c(2,0.355555555555555,0.27504,-0.266532303034304),c(2,0.466666666666667,0.16128,-0.186985432639928),c(2,0.355555555555555,0.22848,0.649045861961289),c(2,0.533333333333333,0.306,0.650466341789759),c(2,0.466666666666667,0.22008,0.587176073876773)),rbind(c(2,0.2,0.10881,0.325334292161951),c(2,0.533333333333333,0.32712,0.872534688307394),c(2,0.355555555555555,0.15888,-0.020789292708819),c(2,0.355555555555555,0.17776,-0.381275506956351),c(2,0.466666666666667,0.31206,0.973546587220889)),rbind(c(2,0.2,0.09216,-0.00263871712280063),c(2,0.2,0.02529,-1.64108328371809),c(2,0.355555555555555,0.20048,-0.216026353577557),c(2,0.355555555555555,0.14256,-0.346552666704838),c(2,0.2,0.0252,-0.0354675842696865)),rbind(c(2,0.466666666666667,0.23037,-0.32303583398904),c(2,0.355555555555555,0.2184,-0.241437159397983),c(2,0.533333333333333,0.40296,1.61765527388647),c(2,0.533333333333333,0.14448,1.17572821613993),c(2,0.2,0.1233,-1.6489748383207)),rbind(c(2,0.466666666666667,0.21483,0.531619529474351),c(2,0.466666666666667,0.21357,-0.753283390923704),c(2,0.2,0.10584,-1.63982063498167),c(2,0.2,0.0135,0.998168237581052),c(2,0.355555555555555,0.1088,-0.341659902851215)),rbind(c(2,0.466666666666667,0.15813,-0.197086622531277),c(2,0.355555555555555,0.1616,-0.715403928831144),c(2,0.533333333333333,0.25824,0.315548764454706),c(2,0.355555555555555,0.02,-1.97158159047567),c(2,0.355555555555555,0.14352,-0.568147519946316)),rbind(c(2,0.2,0.00954,-1.00044688107766),c(2,0.555555555555556,0.23825,-0.639013680277814),c(2,0.2,0.0108,0.026875697090986),c(2,0.355555555555555,0.27488,-0.365808059935222),c(2,0.2,0.06282,-0.543683700678204)),rbind(c(2,0.2,0.01854,-0.316880421398998),c(2,0.2,0.11502,-1.239718816629),c(2,0.2,0.05697,-1.40496797000779),c(2,0.2,0.13581,-1.72583858015019),c(2,0.2,0.06498,-0.870236230134484)),rbind(c(2,0.355555555555555,0.13408,-0.0574061060649607),c(2,0.2,0.09873,-1.29006693499369),c(2,0.555555555555556,0.37975,1.45572057344077),c(2,0.533333333333333,0.36888,1.36039059384116),c(2,0.2,0.08505,-0.145633686522216)),rbind(c(2,0.2,0.05409,-0.584719784611811),c(2,0.466666666666667,0.13902,0.0634925104471277),c(2,0.355555555555555,0.208,0.445601584305829),c(2,0.2,0.10557,0.402671527267594),c(2,0.2,0.13131,-0.238280537556936)),matrix(c(0.1,0.3,0.3,0.6,1),ncol=1),matrix(c(666441,755413,467398,697260,76950),ncol=1),rbind(c(2,0,0,0,0.3111111,0.01536351,0.24203379,1.070357,0.129559,0.008187780,0.1564067,1.489786,-0.18917928,0.1879239,-0.09978741,2.264714),c(2,0,0,0,0.3800000,0.01947325,-0.24128379,1.271566,0.169828,0.007081658,0.1402997,2.223694,-0.57709654,0.5455674,0.38219729,2.134886),c(2,0,0,0,0.3644444,0.01944582,0.12063020,1.363244,0.201040,0.016063381,0.1638183,1.751532,0.12288435,1.1127874,-0.27194529,1.885978),c(2,0,0,0,0.3622222,0.01855144,0.08792094,1.350955,0.168944,0.013646088,0.2742807,1.702820,-0.02036315,1.3417091,-0.43333427,1.665945),c(2,0,0,0,0.2844444,0.01325652,0.60325515,1.457519,0.127712,0.007070115,0.9041615,2.750487,-0.28313613,0.5312997,-0.03348760,2.367178))))
 }

 if(!-1%in%numtaxa&&onoff==0){

  if(numtaxa[['numtaxacaution']]==1){
   print("Caution: You have specified an inappropriate number of vector elements for the 'num.taxa' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'num.taxa' elements, with x = 'num.partitions', or if not applicable, with the first 'num.taxa' element used for all partitions")
  }
  if(convert.sequences==T){
   if(numhaps[['numhapscaution']]==1){
    print("Caution: You have specified an inappropriate number of vector elements for the 'num.haploid.samples' object; this should be of length = 'num.partitions' or 1; Multi-DICE will continue with only the first x 'num.haploid.samples' elements, with x = 'num.partitions', or if not applicable, with the first 'num.haploid.samples' element used for all partitions")
   }
  }
  if(!is.null(input.directory)){
   if(inputs[['inputscaution']]==1){
    print("Caution: You have specified more vector elements than the total of the 'num.taxa' object for the 'input.files' object; Multi-DICE will continue with only the first x 'input.files' elements, with x = total of 'num.taxa'")
   }
  }

  sumstats=NULL
  for(a in 1:sum(numtaxa[['numtaxa']])){
   sumstats=append(sumstats,list(NULL))
  }
  if(convert.sequences==T){
   if(!is.null(input.directory)){
    system(paste('cat ',inputdir[1],inputs$inputs[1],'|awk "NR==1"|cut -c 1 >',inputdir[1],'dice.sims.fsc2template',sep=''))
    if(!is.numeric(as.matrix(read.table(paste(inputdir[1],'dice.sims.fsc2template',sep=''))))){
     system(paste('cat ',inputdir[1],inputs$inputs[1],'|wc -l|tr -d " " >',inputdir[1],'dice.sims.fsc2template',sep=''))
     if(read.table(paste(inputdir[1],'dice.sims.fsc2template',sep=''))[1]==(numhaps[['numhaps']][1]/2)){
      con.seq.process=1
     } else {
      con.seq.process=2
     }
    } else {
     con.seq.process=3
    }
   } else {
    if(substr(output.directory,nchar(output.directory),nchar(output.directory))=='/'){
     system(paste('cat ',output.directory,'dice.simulations1|awk "NR==1"|cut -c 1 >',output.directory,'dice.sims.fsc2template',sep=''))
     if(!is.numeric(as.matrix(read.table(paste(output.directory,'dice.sims.fsc2template',sep=''))))){
      system(paste('cat ',output.directory,'dice.simulations1|wc -l|tr -d " " >',output.directory,'dice.sims.fsc2template',sep=''))
      if(read.table(paste(output.directory,'dice.sims.fsc2template',sep=''))[1]==(numhaps[['numhaps']][1]/2)){
       con.seq.process=1
      } else {
       con.seq.process=2
      }
     } else {
      con.seq.process=3
     }
    } else {
     system(paste('cat ',output.directory,'/dice.simulations1|awk "NR==1"|cut -c 1 >',output.directory,'/dice.sims.fsc2template',sep=''))
     if(!is.numeric(as.matrix(read.table(paste(output.directory,'/dice.sims.fsc2template',sep=''))))){
      system(paste('cat ',output.directory,'/dice.simulations1|wc -l|tr -d " " >',output.directory,'/dice.sims.fsc2template',sep=''))
      if(read.table(paste(output.directory,'/dice.sims.fsc2template',sep=''))[1]==(numhaps[['numhaps']][1]/2)){
       con.seq.process=1
      } else {
       con.seq.process=2
      }
     } else {
      con.seq.process=3
     }
    }
   }
   for(a in 1:num.partitions){
    asub1=0
    asub2=0
    for(b in 1:(numhaps[['numhaps']][a]-1)){
     asub1=asub1+(1/b)
     asub2=asub2+(1/(b^2))
    }
    bsub1=(numhaps[['numhaps']][a]+1)/(3*(numhaps[['numhaps']][a]-1))
    bsub2=(2*((numhaps[['numhaps']][a]^2)+numhaps[['numhaps']][a]+3))/((9*numhaps[['numhaps']][a])*(numhaps[['numhaps']][a]-1))
    csub1=bsub1-(1/asub1)
    csub2=bsub2-((numhaps[['numhaps']][a]+2)/(asub1*numhaps[['numhaps']][a]))+(asub2/(asub1^2))
    esub1=csub1/asub1
    esub2=csub2/((asub1^2)+asub2)
    for(b in ((sum(numtaxa[['numtaxa']][0:(a-1)])+1):sum(numtaxa[['numtaxa']][1:a]))){
     for(c in inputdir){
      if(con.seq.process==1){
       if(!is.null(input.directory)){
        system(paste('cat ',c,inputs$inputs[b],'|sed -e "s/A/1 /g" -e "s/T/2 /g" -e "s/G/3 /g" -e "s/C/4 /g" -e "s/N/9 /g" -e "s/-/9 /g" -e "s/R/1 /g" -e "s/Y/4 /g" -e "s/S/3 /g" -e "s/W/1 /g" -e "s/K/3 /g" -e "s/M/1 /g" >',c,'dice.sims.fsc2template',sep=''))
        con.seq.sumstats=read.big.matrix(paste(c,'dice.sims.fsc2template',sep=''), sep=' ', type='integer')
        system(paste('cat ',c,inputs$inputs[b],'|sed -e "s/A/1 /g" -e "s/T/2 /g" -e "s/G/3 /g" -e "s/C/4 /g" -e "s/N/9 /g" -e "s/-/9 /g" -e "s/R/3 /g" -e "s/Y/2 /g" -e "s/S/4 /g" -e "s/W/2 /g" -e "s/K/2 /g" -e "s/M/4 /g" >',c,'dice.sims.fsc2template',sep=''))
        con.seq.sumstats=rbind(con.seq.sumstats[],read.big.matrix(paste(c,'dice.sims.fsc2template',sep=''), sep=' ', type='integer')[])
       } else {
        if(substr(output.directory,nchar(output.directory),nchar(output.directory))=='/'){
         system(paste('cat ',output.directory,'dice.simulations',b,'|sed -e "s/A/1 /g" -e "s/T/2 /g" -e "s/G/3 /g" -e "s/C/4 /g" -e "s/N/9 /g" -e "s/-/9 /g" -e "s/R/1 /g" -e "s/Y/4 /g" -e "s/S/3 /g" -e "s/W/1 /g" -e "s/K/3 /g" -e "s/M/1 /g" >',output.directory,'dice.sims.fsc2template',sep=''))
         con.seq.sumstats=read.big.matrix(paste(output.directory,'dice.sims.fsc2template',sep=''), sep=' ', type='integer')
         system(paste('cat ',output.directory,'dice.simulations',b,'|sed -e "s/A/1 /g" -e "s/T/2 /g" -e "s/G/3 /g" -e "s/C/4 /g" -e "s/N/9 /g" -e "s/-/9 /g" -e "s/R/3 /g" -e "s/Y/2 /g" -e "s/S/4 /g" -e "s/W/2 /g" -e "s/K/2 /g" -e "s/M/4 /g" >',output.directory,'dice.sims.fsc2template',sep=''))
         con.seq.sumstats=rbind(con.seq.sumstats[],read.big.matrix(paste(output.directory,'dice.sims.fsc2template',sep=''), sep=' ', type='integer')[])
        } else {
         system(paste('cat ',output.directory,'/dice.simulations',b,'|sed -e "s/A/1 /g" -e "s/T/2 /g" -e "s/G/3 /g" -e "s/C/4 /g" -e "s/N/9 /g" -e "s/-/9 /g" -e "s/R/1 /g" -e "s/Y/4 /g" -e "s/S/3 /g" -e "s/W/1 /g" -e "s/K/3 /g" -e "s/M/1 /g" >',output.directory,'/dice.sims.fsc2template',sep=''))
         con.seq.sumstats=read.big.matrix(paste(output.directory,'/dice.sims.fsc2template',sep=''), sep=' ', type='integer')
         system(paste('cat ',output.directory,'/dice.simulations',b,'|sed -e "s/A/1 /g" -e "s/T/2 /g" -e "s/G/3 /g" -e "s/C/4 /g" -e "s/N/9 /g" -e "s/-/9 /g" -e "s/R/3 /g" -e "s/Y/2 /g" -e "s/S/4 /g" -e "s/W/2 /g" -e "s/K/2 /g" -e "s/M/4 /g" >',output.directory,'/dice.sims.fsc2template',sep=''))
         con.seq.sumstats=rbind(con.seq.sumstats[],read.big.matrix(paste(output.directory,'/dice.sims.fsc2template',sep=''), sep=' ', type='integer')[])
        }
       }
      }
      if(con.seq.process==2){
       if(!is.null(input.directory)){
        system(paste('cat ',c,inputs$inputs[b],'|sed -e "s/A/1 /g" -e "s/T/2 /g" -e "s/G/3 /g" -e "s/C/4 /g" -e "s/N/9 /g" -e "s/-/9 /g" >',c,'dice.sims.fsc2template',sep=''))
        con.seq.sumstats=read.big.matrix(paste(c,'dice.sims.fsc2template',sep=''), sep=' ', type='integer')
       } else {
        if(substr(output.directory,nchar(output.directory),nchar(output.directory))=='/'){
         system(paste('cat ',output.directory,'dice.simulations',b,'|sed -e "s/A/1 /g" -e "s/T/2 /g" -e "s/G/3 /g" -e "s/C/4 /g" -e "s/N/9 /g" -e "s/-/9 /g" >',output.directory,'dice.sims.fsc2template',sep=''))
         con.seq.sumstats=read.big.matrix(paste(output.directory,'dice.sims.fsc2template',sep=''), sep=' ', type='integer')
        } else {
         system(paste('cat ',output.directory,'/dice.simulations',b,'|sed -e "s/A/1 /g" -e "s/T/2 /g" -e "s/G/3 /g" -e "s/C/4 /g" -e "s/N/9 /g" -e "s/-/9 /g" >',output.directory,'/dice.sims.fsc2template',sep=''))
         con.seq.sumstats=read.big.matrix(paste(output.directory,'/dice.sims.fsc2template',sep=''), sep=' ', type='integer')
        }
       }
      }
      if(con.seq.process==3){
       if(!is.null(input.directory)){
        system(paste('cat ',c,inputs$inputs[b],'|sed -e "s/1/1 /g" -e "s/0/0 /g" -e "s/9/9 /g" -e "s/N/9 /g" -e "s/-/9 /g" >',c,'dice.sims.fsc2template',sep=''))
        con.seq.sumstats=read.big.matrix(paste(c,'dice.sims.fsc2template',sep=''), sep=' ', type='integer')
       } else {
        if(substr(output.directory,nchar(output.directory),nchar(output.directory))=='/'){
         system(paste('cat ',output.directory,'dice.simulations',b,'|sed -e "s/1/1 /g" -e "s/0/0 /g" -e "s/9/9 /g" -e "s/N/9 /g" -e "s/-/9 /g" >',output.directory,'dice.sims.fsc2template',sep=''))
         con.seq.sumstats=read.big.matrix(paste(output.directory,'dice.sims.fsc2template',sep=''), sep=' ', type='integer')
        } else {
         system(paste('cat ',output.directory,'/dice.simulations',b,'|sed -e "s/1/1 /g" -e "s/0/0 /g" -e "s/9/9 /g" -e "s/N/9 /g" -e "s/-/9 /g" >',output.directory,'/dice.sims.fsc2template',sep=''))
         con.seq.sumstats=read.big.matrix(paste(output.directory,'/dice.sims.fsc2template',sep=''), sep=' ', type='integer')
        }
       }
      }
      for(d in ncol(con.seq.sumstats):1){
       if(sum(con.seq.sumstats[,d]!=9)==0){
        con.seq.sumstats=con.seq.sumstats[,-d]
       } else {
        if(max(con.seq.sumstats[,d][con.seq.sumstats[,d]!=9])==min(con.seq.sumstats[,d][con.seq.sumstats[,d]!=9])){
         con.seq.sumstats[con.seq.sumstats[,d]==9,d]=max(con.seq.sumstats[,d][con.seq.sumstats[,d]!=9])
        }
       }
      }
      con.seq.sumstats.missing=NULL
      for(d in 1:nrow(con.seq.sumstats)){
       con.seq.sumstats.missing=c(con.seq.sumstats.missing,sum(con.seq.sumstats.missing[d,]==9))
      }
      con.seq.sumstats=con.seq.sumstats[order(con.seq.sumstats.missing),]
      for(d in 1:nrow(con.seq.sumstats)){
       if(d==1){
        haplotypes=con.seq.sumstats[1,]
        haplotypes.count=1
       } else {
        terminate=0
        e=0
        while(e<nrow(haplotypes)&&terminate==0){
         e=e+1
         if(9%in%con.seq.sumstats[d,]||9%in%haplotypes[e,]){
          con.seq.sumstats.missing=unique(which(con.seq.sumstats[d,]==9),which(haplotypes[e,]==9))
          if(sum(con.seq.sumstats[d,-con.seq.sumstats.missing]==haplotypes[e,-con.seq.sumstats.missing])==length(con.seq.sumstats[d,-con.seq.sumstats.missing])){
           terminate=1
           haplotypes.count[e]=haplotypes.count[e]+1
          }
         } else {
          if(sum(con.seq.sumstats[d,]==haplotypes[e,])==length(con.seq.sumstats[d,])){
           terminate=1
           haplotypes.count[e]=haplotypes.count[e]+1
          }
         }
        }
        if(terminate==0){
         haplotypes=rbind(haplotypes,con.seq.sumstats[d,])
         haplotypes.count=c(haplotypes.count,1)
        }
       }
      }
      hapdiv=0
      for(d in 1:length(haplotypes.count)){
       hapdiv=hapdiv+((haplotypes.count[d]/sum(haplotypes.count))^2)
      }
      hapdiv=(sum(haplotypes.count)/(sum(haplotypes.count)-1))*(1-hapdiv)
      pair.combos=combn(1:nrow(haplotypes),2)
      nucdiv=0
      for(d in 1:ncol(pair.combos)){
       nucdiv=nucdiv+((haplotypes.count[pair.combos[1,d]]/sum(haplotypes.count))*(haplotypes.count[pair.combos[2,d]]/sum(haplotypes.count))*(sum(haplotypes[pair.combos[1,d],]!=haplotypes[pair.combos[2,d],])/ncol(haplotypes)))
      }
      pair.combos=combn(1:nrow(con.seq.sumstats),2)
      pwd=0
      for(d in 1:ncol(pair.combos)){
       if(9%in%con.seq.sumstats[pair.combos[1,d],]||9%in%haplotypes[pair.combos[2,d],]){
        con.seq.sumstats.missing=unique(which(con.seq.sumstats[pair.combos[1,d],]==9),which(con.seq.sumstats[pair.combos[2,d],]==9))
        pwd=pwd+sum(con.seq.sumstats[pair.combos[1,d],-con.seq.sumstats.missing]!=con.seq.sumstats[pair.combos[2,d],-con.seq.sumstats.missing])
       } else {
        pwd=pwd+sum(con.seq.sumstats[pair.combos[1,d],]!=con.seq.sumstats[pair.combos[2,d],])
       }
      }
      pwd=pwd/ncol(pair.combos)
      ess=0
      for(d in 1:ncol(con.seq.sumstats)){
       if(max(con.seq.sumstats[,d][con.seq.sumstats[,d]!=9])==min(con.seq.sumstats[,d][con.seq.sumstats[,d]!=9])){
        ess=ess+1
       }
      }
      sumstats[[b]]=rbind(sumstats[[b]],c(nrow(haplotypes),hapdiv,(2*nucdiv),((pwd-(ess/asub1))/(((esub1*ess)+(esub2*ess*(ess-1)))^.5))))
     }
    }
   }
   if(!is.null(input.directory)){
    for(a in inputdir){
     system(paste('rm ',a,'dice.sims.fsc2template',sep=''))
    }
   } else {
    if(substr(output.directory,nchar(output.directory),nchar(output.directory))=='/'){
     system(paste('rm ',output.directory,'dice.sims.fsc2template',sep=''))
    } else {
     system(paste('rm ',output.directory,'/dice.sims.fsc2template',sep=''))
    }
   }
  } else {
   if(!is.null(input.directory)){
    for(a in inputs$inputs){
     for(b in inputdir){
      sumstats[[which(inputs$inputs==a)]]=rbind(sumstats[[which(inputs$inputs==a)]],read.big.matrix(paste(b,a,sep=''), sep='\t', type='double')[])
     }
    }
   } else {
    for(a in 1:sum(numtaxa[['numtaxa']])){
     if(substr(output.directory,nchar(output.directory),nchar(output.directory))=='/'){
      sumstats[[a]]=rbind(sumstats[[a]],read.big.matrix(paste(output.directory,'dice.simulations',a,sep=''), sep='\t', type='double')[])
     } else {
      sumstats[[a]]=rbind(sumstats[[a]],read.big.matrix(paste(output.directory,'/dice.simulations',a,sep=''), sep='\t', type='double')[])
     }
    }
   }
  }
  sumstatsvectors=matrix(rep(0,(16*num.partitions*num.sims)),ncol=(16*num.partitions))
  for(a in 1:num.sims){
   for(b in 1:num.partitions){
    for(c in 1:4){
     sumstat=NULL
     for(d in (sum(numtaxa[['numtaxa']][0:(b-1)])+1):sum(numtaxa[['numtaxa']][0:b])){
      sumstat=c(sumstat,sumstats[[d]][a,c])
     }
     sumstatsvectors[a,(((b-1)*16)+((c-1)*4)+1)]=mean(sumstat)
     if(length(sumstat)>1){
      sumstatsvectors[a,(((b-1)*16)+((c-1)*4)+2)]=var(sumstat)
      if(var(sumstat)>0){
       sumstatsvectors[a,(((b-1)*16)+((c-1)*4)+3)]=skewness(sumstat, method=c('moment'))
       sumstatsvectors[a,(((b-1)*16)+((c-1)*4)+4)]=kurtosis(sumstat, method=c('moment'))
      }
     }
    }
   }
  }

  return(sumstatsvectors)

 }

}
